# Field-pilot-v2 RF catalogue

Planning baseline: 2026-09-17, receiver branch, commit ee55b737b0bc90e2a467814ddccc688a08c8a06a, initially clean tracked tree.
Status: proposed coverage and deployment gate, awaiting independent review. No RF case was executed by this reconciliation. Stable IDs RF-001 through RF-031 are allocated here; never renumber or reuse them. Deferred cases remain obligations, not passes.

The companion [deployment inventory](../../deployment_remaining.notes.md) owns non-RF implementation, evidence applicability, decisions DEC-001 through DEC-008, coverage reconciliation and the implementation order. References to DEP items below refer to its stable headings. DOC-001..DOC-006 were approved/applied on 2026-09-18, including firmware-roadmap retirement; DEC-002 is subsequently approved for operator-managed tests and the current firmware heuristic; DEC-001 now approves the selected gate/follow-up dispositions with DOC-007/DOC-008 deferred; DEC-004 also approves local-only Pi storage without an uploader or off-Pi export requirement; DEC-005..DEC-008 approve the 24-hour bench phase, physical-proof deferral, change-based evidence reuse and flexible sensor placement/post-deployment logbook record. DEC-003 now approves the documented pilot envelope and defers physical RF-018 as NOT RUN; case execution results remain separately recorded in [COVERAGE.md](COVERAGE.md). This file specifies future tests; it creates no executable suite, peer, API or Make target.

## Source and layer key

| Key | Governing source / production layer |
|---|---|
| P-WIRE | [Protocol packet, reading and PHY contract](../../protocol/protocol-v2-lora/README.md#routine-packet), including fixed profile and pilot airtime constants |
| P-ID | [Provisioning](../../protocol/protocol-v2-lora/README.md#keys-and-provisioning), [nonce](../../protocol/protocol-v2-lora/README.md#ccm-nonce), counters and destructive identity replacement |
| P-ACK | [ACK behavior](../../protocol/protocol-v2-lora/README.md#ack-behaviour), ordered receiver validation, asynchronous identity classification and pilot transmission policy |
| P-VECT | [Reviewed vectors](../../protocol/protocol-v2-lora/test-vectors/golden_vectors.json), [schema](../../protocol/protocol-v2-lora/schemas/protocol_v2_lora.json), [test independence rules](../../protocol/protocol-v2-lora/tests/README.md) |
| F-CORE | [Firmware wake/delivery contract](../../firmware/ARCHITECTURE.md#wake-cycle), [core interface](../../firmware/INTERFACE.md#node_core), production [node_core.c](../../firmware/components/node_core/node_core.c) |
| F-RAD | [Firmware radio interface](../../firmware/INTERFACE.md#sx1262_radio), [hardware requirements](../../firmware/TESTING.md#sx1262_radio-hardware-strategy); production [radio policy](../../firmware/components/sx1262_radio/sx1262_radio.c) and [ESP backend](../../firmware/components/sx1262_radio/sx1262_radio_backend_esp.c) |
| F-CLK | [Platform/shared radio clock](../../firmware/TESTING.md#platform-ports); production [platform adapter](../../firmware/components/node_platform_esp/node_platform_esp.c) |
| R-RAD | [Receiver radio access/state model](../../receiver/ARCHITECTURE.md#radio-access), [bounds](../../receiver/INTERFACE.md#radio-backend-configuration), [radio tests](../../receiver/TESTING.md#radio) |
| R-IMPL | Production [Radio](../../receiver/cura_receiver/radio.py), [Sx1262](../../receiver/cura_receiver/sx1262.py), [LinuxRadioIo](../../receiver/cura_receiver/platform/linux_radio.py), [physical port and authorization values](../../receiver/cura_receiver/ports/radio.py) |
| R-FLOW | [Critical flow](../../receiver/ARCHITECTURE.md#critical-receive-to-ack-flow), [ingress lifecycle](../../receiver/INTERFACE.md#protocol-ingress-lifecycle), [end-to-end requirements](../../receiver/TESTING.md#end-to-end-receiver-behavior) |
| R-AIR | [Durable grants](../../receiver/ARCHITECTURE.md#durable-airtime-bucket-grants), [state encoding/recovery](../../receiver/INTERFACE.md#communicatorstatev1), [airtime tests](../../receiver/TESTING.md#receiver-tx-airtime-policy) |
| R-TIME | [Time model](../../receiver/ARCHITECTURE.md#time-model), [elapsed-duration policy](../../receiver/INTERFACE.md#elapsed-duration-policy), [time tests](../../receiver/TESTING.md#time-policy-and-timestamp-analysis) |
| R-LIFE | [Deployment lifecycle](../../receiver/ARCHITECTURE.md#deployment-lifecycle), [lifecycle tests](../../receiver/TESTING.md#deployment-and-lifecycle) |
| DIAG | Firmware [common diagnostics](../../firmware/INTERFACE.md#common-diagnostic-result-model) and [radio context](../../firmware/INTERFACE.md#radio-context-v1); receiver [diagnostic catalogue](../../receiver/INTERFACE_DIAGNOSTIC.md) |
| PILOT | Sibling [field deployment record](../../../cura-agrorum-logbook/deployments/field-pilot-v2/README.md): older bench-duration/placement baseline; approved DEC-005 now requires 24 hours on the bench, then at least one field week; DEC-008 permits practical sensor placement and later logbook recording |

These are different validation layers:

- C6 component: real F-RAD and ESP hardware; raw byte patterns do not exercise node identity, ACK validation, sensors or persistence.
- C6 integrated node: real F-CORE, sensors, storage, codec/crypto, F-RAD and platform; test-only scheduling/observations must be identified. Final deployment evidence includes the production composition root and ordinary 900-second sleep.
- Pi component peer: a separate process, normally using Radio -> Sx1262 -> LinuxRadioIo. It returns radio facts, not full receiver acceptance. Radio neither authenticates nor owns durable grants or SQLite.
- Pi lower-layer peer: deliberate wrong-IQ/sync traffic uses a narrow, local test adaptation around existing Sx1262/physical operations. The fixed production profile and Radio owner cannot be credited for an intentionally altered profile. Do not create a second general SX1262 driver or assume an existing arbitrary-profile peer API.
- C6 lower-layer transmitter: RF-004's deliberate inverted-IQ transmission needs a disclosed local adaptation around the existing private sx1262_radio ESP backend, whose packet-parameter operation supports IQ selection. The public transmit_uplink operation always selects normal IQ. Credit the Pi's receiving production layer for this negative assertion, not the C6 public uplink policy; no alternative-profile public API or duplicate driver is assumed.
- The Radio owner provides one response to a copied receive occurrence. Multiple scheduled downlinks after one uplink, including invalid-then-valid ACK bursts, require a peer-local sequence using the existing Sx1262/LinuxRadioIo layer; they do not establish the production Radio owner's scheduling contract. Preserve its fixed watchdog/payload constraints and validate readiness locally.
- Receiver acceptance: the real service, communicator, ingress, time/state/airtime owners, queue and persistence worker on Pi. The service/communicator are not yet implemented. A component peer is never substituted for them in an acceptance result.

## Common fixture, scheduling and evidence requirements

Every section inherits this complete common procedure, plus its explicit differences.

**N fixture:** C6 carrier in [nominal radio state](../../firmware/test_apps/on_device/SENSOR_CARRIER.md#declared-radio-connection-states), Pi in [radio_nominal](../../receiver/hardware/TEST_CARRIER.md#manual-busy-fixture-states), both RTC fault shunts open. Use the two identified Waveshare EU868 modules and supplied antennas at fixed positions a few metres apart. Operator confirms actual modules, supply, antenna/cable, pin configuration and DUT identity before execution. C6 uses its physical UART connector, not the native USB connector; confirm its actual enumerated path. C6 radio GPIOs are 6/7/14/23/18/19/20 for SCLK/MOSI/MISO/CS/RESET/BUSY/DIO1. Pi uses SPI0 CE0 and BCM22/23/24 for RESET/DIO1/BUSY. Sensor fixtures remain nominal unless a section says otherwise. Bench sensor assertions retain their air-exposed probe conditions; RF-030 field continuation uses the explicitly documented DEP-020 field configuration, without weakening bench limits. Assembly itself is outside this plan.

**B prerequisites:** implement only the needed C6 Unity cases/configuration in firmware/test_apps/radio/, separate Pi peer in receiver/test_apps/radio_peer/, and joint scenarios/orchestration in tests/rf/. DEP-013 current non-TX Pi qualification, DEP-023 approved RF envelope and DEP-024 operator readiness apply before first emission. No such joint app/peer exists at baseline. Ordinary receiver hardware tests remain Pi-local. Run Pi device work as the configured service user, with exclusive radio access and the production service stopped for component cases. No test may silently use root to pass permissions.

The laptop runs pytest and pytest-embedded for C6 UART and SSH for Pi process control. Use explicit run/case IDs, readiness acknowledgements, bounded completion and loss-of-control handling. Arm the Pi locally before triggering C6. For timed downlinks, use the Pi's observed uplink event as its local scheduling origin. An SSH round trip is not a timing reference. On each end retain its own monotonic samples, boot/process identity and event order; never subtract a C6 timestamp from a Pi timestamp. Exact deadline equality is a host-test obligation. Physical early/late cases use a measured, generous guard and report an inconclusive timing setup if it cannot be established.

**Independent oracle:** raw pattern A is 54 bytes 00 through 35 hexadecimal; ACK-sized pattern B is 23 bytes A0 through B6. U2 is 54 bytes 80 through B5, D2 is 23 bytes C0 through D6, and X is 23 bytes E0 through F6. The length-boundary inputs are 7E (one byte), A (54 bytes) and 00 through FE (255 bytes). The invalid-payload sequence is 00, DE AD BE EF, then X. These are independently specified bytes, not protocol ACKs. For authenticated cases, use P-VECT's current_reading_all_fields_valid and accepted/retry_later/rejected_unsupported/rejected_malformed wire examples as reviewed serialization/crypto checks. Fresh provisioned test identities require separately specified header/body/status/domain and an independent crypto check; do not copy the DUT's result as expected bytes. Real sensor values use the independently observed same acquisition and established sensor evidence, not a made-up constant. Distinguish message_id from sample_id in all inputs.

**Identity safety:** authenticated runs use a dedicated group, disposable test nodes, isolated receiver storage and real production counter claims. Preserve exact frames for retries and durable backlog binding. Never erase/restore counters and resume the same identity/key. Test partition names can overlap production physical flash ranges: disclosure and destructive opt-in are required before flashing/erasure. Retire identities after destructive resets and follow P-ID's full state reset with new credentials. Do not include keys, secret headers, group files or secret-bearing process output in captures. Raw component patterns require no live credentials.

**RF envelope approval (2026-09-18):** the operator accepts the documented firmware/receiver schematics, existing source-based assessment and configured +14 dBm, trusting the SX1262 configuration, and explicitly allows autonomous wakes, retries and resets. The [retained decision](evidence/2026-09-18-envelope/README.md) closes RF-018 disposition and DEP-023 approval under the updated DEC-003. Numerical output uncertainty remains unmeasured; RF-018 physical measurement is approved deferred **NOT RUN**. This does not establish a measured compliance result or full-service/deployment acceptance. Existing fixture, bounded-episode, operator accounting and production-policy requirements remain.

**Airtime:** the [first operating envelope](../../firmware/TESTING.md#sx1262_radio-first-rf-operating-envelope) applies only to the initial exchange: at most ten attempts, one 54-byte C6 TX and at most one 23-byte Pi TX each, at least 60 seconds between TX starts at each end across cases/reruns. RF-001 fits it. All multi-packet, alternate-size, retry, fault and stress cases require a separately reviewed explicit emission budget/pacing schedule before selection; they are not implicitly authorized by this catalogue. Fixed-profile modeled times are 102,656 us per reading and 61,696 us per ACK; reserve 112,922 and 67,866 us respectively. For other lengths calculate independently from P-WIRE, including every negative-test packet.

For this first phase, the operator owns airtime accounting, admission and pacing for each physical transmitter. Keep retained manual airtime records for all band activity; a conservative batch sheet is sufficient. The harness declares maximum episode emissions, waits for operator readiness and records attempts, but no automated ledger, history parser or cross-run scheduler is required. Reserve the complete possible episode before either trigger can emit, including autonomous retries, faults and uncertain commands. Do not refund on absent peer reception. Retain through a full verified 3,600 seconds after latest possible TX end; interrupted scheduling or lost control must bound possible continuing emission or require the documented physically unpowered quiet-hour recovery. Reboot, flash, counter erasure, new process/job and changed fixture never erase operator-record history. Unknown history/time continuity fails closed. Manual test accounting does not prove production enforcement: DEC-002 defers DEP-007 and the firmware-ledger portion of RF-029; R-AIR governs production ACK allowance. No component test may initialize a fake empty receiver production ledger (or future firmware ledger) to authorize deployment traffic.

An ordinary production image can wake and transmit without a new laptop command. Its run plan must account conservatively for those scheduled wakes and unexpected resets and define how observation and operator stop remain possible; no unimplemented pre-TX host handshake is assumed. Before enabling an autonomous phase, approve its full possible-transmission envelope and operator-record continuity/uncertain-interval handling. If that cannot be bounded, the phase is not ready to run. Current node guards, receiver durable enforcement and operator test records remain separate evidence. An extra LoRa receiver can cross-check observations; ten minutes of decoded silence neither clears history nor establishes no transmission.

**Timing assertions:** C6 54-byte pre-SetTx-to-TX_DONE is 102,656..112,922 us, plus enclosing platform-clock inequalities for TX and RX. For silence called at S with deadline D, require D <= return <= D + ceil(0.15*(D-S)), zero packet fields and normal deadline outcome. Pi limits retain R-RAD's 2 s startup, 100 ms BUSY, 500 ms ordinary operation, 100 ms radio ACK watchdog, 250 ms host TX bound, 500 ms soft/2 s hard recovery and 500 ms shutdown with specified conservative elapsed conversions. Never apply C6 timing tolerance to Pi. RF-017 owns independent edge/timebase qualification and its different tolerances.

**Evidence and failure:** retain source manifests/current diffs, binary/configuration identities, fixture/operator record, selection count, exact commands and exit codes, full raw relevant UART and Pi events, independent expected/result comparisons and both operator airtime records. Acceptance additionally retains consistent SQLite/state/profiling/health/lifecycle evidence and relevant node log bytes. Decode observations independently. A missing prerequisite, mismatched fixture, zero selected cases, missed expected event, extra TX, unexplained loss, unexpected reset, violated bound or uncertain restoration fails the requested run; preserve the failure. Peer silence alone cannot prove no local SetTx or no RF emission. Use local command/certainty evidence plus the observation window; label the physical detection limit.

**Cleanup C:** stop scheduled transmissions and reap the separate peer; put C6 radio into contracted cold sleep and prove it can enter deep sleep; on Pi confirm standby, IRQ accounting/disablement and handle release. Verify no process can still transmit and retain operator reservations. Restore all modified profiles/configuration, dedicated service/time settings and nominal wiring; wiring/power changes are operator actions with power removed. Unconfirmed Pi safety aborts dependent tests; operator power removal and a fresh nominal run establish a separate restoration result, never retroactive success.

For a production node, deep sleep is not final TX inhibition: its timer can wake it again. At final test teardown the operator removes all node power/back-power paths, or explicitly hands it into the continuing, accounted RF-030/field phase. Record which occurred. Stopping SSH or the Pi peer does not stop an autonomous C6.

The selected “blocks deployment” entries and follow-up dispositions are approved under DEC-001, subject to their separately identified decision conditions. “Can follow deployment” preserves the exact assertions and revisit conditions. A shared run may establish several IDs only when each ID's prerequisites, assertions and evidence are independently recorded; it must not erase an ID or count one endpoint's success for the other.

<a id="rf-001"></a>

## RF-001 — First nominal exchange, exact bytes and shared C6 clock

- **Requirements/layer:** P-WIRE, F-RAD, F-CLK, R-RAD; real C6 radio and Pi Radio/Sx1262/LinuxRadioIo, raw component scope.
- **Initial state/prerequisites:** N, B; fresh C6 boot/UNTOUCHED, Pi initialized normal-IQ RX; operator readiness only, no intervention during exchange.
- **Actions:** Pi announces RX ready; C6 transmits A then receives inverted IQ; Pi captures A and uses its production ACK radio path to send B under runner authorization.
- **Expected/observations:** exactly A then B, no authentication claim. C6 tx_started/tx_done true, empty diagnostic, ordered nonzero timestamps within platform samples and 102,656..112,922 us; RX_PACKET has exact B, timely RX_DONE and representable RSSI/SNR. Pi copied bytes/length, actual IRQ/kernel timestamps, complete inverted-TX/normal-boosted-RX restoration and safe state. Check each end separately; no exact signal-strength threshold.
- **Cleanup/timing:** C; first-envelope ten-attempt/60-second limits, stop on first unexplained failure.
- **Status/gate:** planned, no RF evidence. **Blocks deployment:** establishes the real two-ended path; can also be evidenced by RF-020 if every component assertion is retained.

<a id="rf-002"></a>

## RF-002 — C6 payload length boundaries

- **Requirements/layer:** F-RAD public 1..255-byte payload and P-WIRE PHY; C6 radio and Pi receive component.
- **Initial state/prerequisites:** N, B, RF-001; reboot for each independent length; operator readiness, no rewiring.
- **Actions:** C6 sends distinctive literal 1-, 54- and 255-byte patterns; Pi reports exact independently expected length/bytes and rearms.
- **Expected/observations:** no truncation, overflow or stale suffix; C6 successful started/done and bounded operation. Independently calculated airtimes 25,856 / 102,656 / 399,616 us and minimum-window expectations from F-RAD; Pi only receives the long packet, avoiding its 100 ms ACK TX watchdog.
- **Cleanup/timing:** C; reserve ceil(1.10*T) for each actual size; extended envelope required.
- **Status/gate:** planned, host boundary tests exist. **Can follow deployment:** pilot uses only 54/23-byte frames, covered by RF-001/RF-020. Revisit before another payload size or radio-buffer change.

<a id="rf-003"></a>

## RF-003 — Silence and bounded C6 receive deadline

- **Requirements/layer:** F-RAD RX_DEADLINE and unchanged absolute deadline; C6 radio, Pi passive peer.
- **Initial state/prerequisites:** N, B, RF-001; one successful C6 initialization uplink; operator readiness only.
- **Actions:** Pi receives but emits nothing; C6 waits once to a declared absolute deadline.
- **Expected/observations:** success with RX_DEADLINE, all packet fields zero and the common 15% late-only bound; Pi confirms no downlink operation, C6 no fabricated packet/error or unbounded wait.
- **Cleanup/timing:** C; account for initialization TX, zero Pi TX.
- **Status/gate:** planned, deterministic host silence coverage exists. **Blocks deployment:** field outages are ordinary operating conditions; RF-025 may share its suppressed-ACK evidence if these radio assertions and Pi no-TX proof are retained.

<a id="rf-004"></a>

## RF-004 — Opposite-IQ filtering

- **Requirements/layer:** P-WIRE direction IQ, F-RAD downlink filtering, R-RAD normal-IQ receive profile and R-FLOW's distinct wrong-direction assertions for both endpoints. Parameter c6_rejects_normal uses the C6 production radio and an altered Pi lower-layer peer. Parameter pi_rejects_inverted uses production Pi Radio/Sx1262/LinuxRadioIo and a C6 lower-layer transmitter. Component outcomes alone do not close the full-service R-FLOW obligation.
- **Initial state/prerequisites:** N, B, RF-001; select each parameter explicitly. Review the corresponding endpoint-local wrong-IQ adaptation and complete emission budget before selection; neither exists yet. Require bounded receive-ready handshakes, a measured guard between nonoverlapping packets and confirmed receiving profiles. Operator readiness only.
- **Actions:** c6_rejects_normal: after normal-IQ C6 A, Pi locally sends normal-IQ X, then inverted-IQ B before the same C6 deadline. pi_rejects_inverted: first exchange normal-IQ A and inverted-IQ B, then confirm Pi has restored normal-IQ boosted RX. C6's disclosed lower-layer sequence sends inverted-IQ X during that bounded listening interval, restores its normal-IQ transmit profile and sends U2; Pi remains in the production receive path and emits no further packet in this parameter.
- **Expected/observations:** c6_rejects_normal: X is never returned as a downlink and B is returned exactly. pi_rejects_inverted: X never produces a copied PHY-valid packet at Pi, and U2 is received exactly after it; do not count later authentication rejection as PHY filtering. Retain each endpoint's profile/command/IRQ and packet evidence, including confirmed negative TX and the successful correct-profile control. Missing negative TX, overlapping packets, missing RX readiness or missing control reception cannot pass either parameter. No C6 rejection result substitutes for the Pi assertion.
- **Cleanup/timing:** C; restore both complete production profiles and perform a fresh nominal exchange after the adaptations are removed. For c6_rejects_normal reserve C6 A plus both Pi X/B; for pi_rejects_inverted reserve C6 A/X/U2 plus Pi B, as well as the final restoration exchange. A/U2 charge 112,922 us each and X/B 67,866 us each regardless of IQ or reception; reserve the entire extended sequence with generous local separation.
- **Status/gate:** planned, both physical rejection assertions unrun. **Can follow deployment under approved DEC-001:** fixed-profile host transcripts and nominal bidirectional RF establish the proposed pilot operation, but neither negative assertion is established by RF-001/RF-008/RF-020. Retain both as deferred, including their full-service application: before closing R-FLOW, exercise both rejection assertions with the complete receiver/node composition, disclosed local fault adaptations and independently specified authenticated nominal control frames under P-ID/P-VECT instead of raw A/B/U2. Capture radio-level rejection as well as service evidence; a raw component pass is insufficient. Revisit on interference/profile defects or profile changes; DEC-001 approves this deferral, not a PASS.

<a id="rf-005"></a>

## RF-005 — Sync-word filtering

- **Requirements/layer:** P-WIRE private sync word 0x1424 and F-RAD; C6 radio, Pi altered lower-layer peer.
- **Initial state/prerequisites:** N, B, RF-001; pre-reviewed alternate sync word and exact local mutation/readback procedure; operator readiness only.
- **Actions:** Pi sends X with the declared different sync word, restores 0x1424, then sends B under one C6 deadline.
- **Expected/observations:** only B returned; retain register bytes and TX outcomes, not just a success flag. No claim that sync word authenticates traffic.
- **Cleanup/timing:** C; verify restoration; charge both downlinks and initialization.
- **Status/gate:** planned. **Can follow deployment:** nominal matching word is tested before deployment; negative filtering adds confidence but does not establish identity security. Revisit on module/profile changes or unexpected demodulation.

<a id="rf-006"></a>

## RF-006 — Invalid packets do not extend RX

- **Requirements/layer:** F-RAD absolute RX deadline and snapshot/rearm; C6 radio with explicit caller rejection loop, Pi Sx1262/LinuxRadioIo peer sequence at the production PHY. Core ACK semantics are separate in RF-019.
- **Initial state/prerequisites:** N, B, RF-001; reviewed short PHY-valid patterns that are not valid ACKs; operator readiness only.
- **Actions:** Pi schedules several bounded invalid payloads locally after an uplink; C6 records each packet, rejects it in the test caller and calls receive again with the original D.
- **Expected/observations:** exact received patterns/metadata, no accumulated deadline extension, terminal normal deadline within the common bound; Pi proves the intended packets were attempted while that receive window was active. No caller-generated packet is credited as authentication evidence.
- **Cleanup/timing:** C; reserve whole burst at both ends before triggering; extended envelope.
- **Status/gate:** planned. **Blocks deployment:** establishes the real IRQ/rearm path under unwanted traffic. May share RF-019 only with separate radio deadline assertions.

<a id="rf-007"></a>

## RF-007 — Late downlink and stale-event isolation

- **Requirements/layer:** F-RAD late packet/deadline and stale IRQ/buffer contract; C6 radio, Pi component.
- **Initial state/prerequisites:** N, B, RF-001; measured local scheduling guard placing a late B clearly after D; operator readiness only.
- **Actions:** C6 completes first deadline; Pi sends late B; C6 begins a new uplink/RX episode and Pi sends D2.
- **Expected/observations:** first result is deadline; second returns only D2, never old B. Keep captured local event timelines and expected bytes; timing setup without a proven guard is inconclusive.
- **Cleanup/timing:** C; reserve both episodes and late packet; exact equality remains host coverage.
- **Status/gate:** planned; host stale/boundary coverage exists. **Can follow deployment:** nominal transitions and deadline cases are gated; this additional guarded late-arrival characterization follows unless earlier cases expose stale events.

<a id="rf-008"></a>

## RF-008 — RX/TX transitions and repeated profile restoration

- **Requirements/layer:** F-RAD and R-RAD complete profile transitions; both production radio components.
- **Initial state/prerequisites:** N, B, RF-001/RF-003; same initialized C6 boot for each sequence; operator readiness only.
- **Actions:** parameter A: C6 TX A, silent downlink window, C6 TX U2. Parameter B: C6 TX A, Pi inverted B, C6 TX U2, Pi inverted D2. No reinitialization between sequence operations.
- **Expected/observations:** both uplinks and applicable downlinks exact, no stale IRQ/buffer result; C6 armed RX -> standby -> normal TX and Pi inverted TX -> confirmed normal boosted RX before next reception. Pi timestamps and C6 timestamps remain separately ordered.
- **Cleanup/timing:** C after each sequence; extended episode budget, no uncontrolled retries.
- **Status/gate:** planned. **Blocks deployment:** directly exercises the state transitions every retry/ACK requires. RF-020/RF-021 can supply these assertions without a second duplicate run.

<a id="rf-009"></a>

## RF-009 — Untouched no-op and initialized terminal C6 radio sleep

- **Requirements/layer:** F-RAD sleep interface and F-CORE finalization; C6 production radio, Pi passive observation.
- **Initial state/prerequisites:** N, B; separate fresh boots for parameter untouched (no earlier radio operation) and parameter initialized (one successful setup TX of A, which RF-001 may supply). Operator readiness only.
- **Actions:** in each parameter C6 calls sleep twice, then attempts same-boot TX of A with a valid 54-byte payload and sufficient deadline remaining for lazy initialization/setup/completion. Pi records its bounded listening interval and sends nothing during the sleep/post-sleep sequence.
- **Expected/observations:** untouched: both sleep calls succeed without initialization/I/O and leave UNTOUCHED; the later TX lazily initializes, returns tx_started/tx_done true and Pi receives exact A. Initialized: first sleep confirms standby/cold sleep, second succeeds without further I/O; later TX returns invalid state, tx_started false and no frame at Pi. Require local lifecycle/command evidence for both parameters; peer silence alone does not prove terminal state.
- **Cleanup/timing:** C, including actual C6 deep-sleep entry. Untouched needs real cold-sleep cleanup after its successful post-sleep TX. Reserve 112,922 us for that TX and, separately, 112,922 us for the initialized parameter's setup TX; its rejected post-sleep call adds no charge only with definite pre-SetTx evidence. Pi charge is zero in standalone sequences; retain any shared RF-001 setup ACK's 67,866 us and all setup/spacing history under the common operator-record rules.
- **Status/gate:** planned, host coverage exists. **Blocks deployment:** verifies terminal cleanup of the actual module; can share RF-010.

<a id="rf-010"></a>

## RF-010 — Cold reinitialization after C6 deep sleep

- **Requirements/layer:** F-RAD, F-CLK and F-CORE normal wake; real C6 platform/radio and Pi component.
- **Initial state/prerequisites:** N, B, RF-001; operator readiness only; UART survives sleep.
- **Actions:** successful exchange, C6 cold radio sleep and actual timer deep sleep, then another exchange after wake; Pi waits boundedly across announced sleep.
- **Expected/observations:** DEEPSLEEP reset reason, new C6 boot/BSS, full lazy initialization and exact second exchange; shared clock checks are per wake. Short component sleep is labelled and does not substitute for RF-020's 900-second production sleep.
- **Cleanup/timing:** C; operator records survive C6 reset, charge both exchanges and retain spacing.
- **Status/gate:** planned. **Blocks deployment:** every production cycle crosses this boundary; can be shared with RF-020.

<a id="rf-011"></a>

## RF-011 — Extended 50–100-exchange transition stress

- **Requirements/layer:** F-RAD deferred slow stress and R-RAD profile restoration; production components.
- **Initial state/prerequisites:** N, B, RF-008/RF-010; predeclare one count in 50..100, seed, phase sequence and airtime schedule; operator setup only.
- **Actions:** C6/Pi repeat the declared TX/RX/sleep sequence, with distinctive payloads and local scheduling.
- **Expected/observations:** every selected exchange and transition has its own expected frame/outcome; no unplanned retry, hang, reset or stale packet. Retain first failure and all attempts; do not rerun until green or silently reduce count.
- **Cleanup/timing:** C; slow selection, operator record spans jobs and interruptions.
- **Status/gate:** planned. **Can follow deployment:** RF-030 supplies real production soak before deployment; this additional concentrated component stress remains useful but is not another mandatory soak. Revisit on intermittent transition faults or before component changes.

<a id="rf-012"></a>

## RF-012 — C6 DIO1 disconnected after possible TX

- **Requirements/layer:** F-RAD manual missing-DIO1 certainty/diagnostics; C6 radio and Pi receive component.
- **Initial state/prerequisites:** C6 dio1_disconnected, Pi radio_nominal; B plus operator removes power, opens JP_DIO1_N and confirms RN5 remains on MCU input. Radio remains connected and antennas fitted.
- **Actions:** C6 attempts A once; Pi listens and records A; no Pi response is needed.
- **Expected/observations:** peer receives exact A while C6 returns bounded failure with tx_started true, tx_done false, TRANSMIT/WAIT_IRQ/HARDWARE_TOUCHED diagnostic and retained full charge. Missing IRQ is not proof of no RF.
- **Cleanup/timing:** C; operator unpowered restoration to nominal, fresh RF-001. Reserve uncertain TX fully.
- **Status/gate:** planned. **Blocks deployment:** simple available fixture exposes the key uncertain-TX path at the real C6 boundary; current-node accounting observations remain RF-029; durable node-ledger proof is deferred under DEC-002.

<a id="rf-013"></a>

## RF-013 — C6 radio absent

- **Requirements/layer:** F-RAD manual absence, DIAG and F-CORE cleanup; C6 production radio/platform, Pi silent observer.
- **Initial state/prerequisites:** C6 radio_absent, Pi radio_nominal but TX inhibited; B, operator unpowered removal of all nine module connections, then MCU BUSY-to-3.3 V and MISO-to-GND ties; RN5 remains fitted.
- **Actions:** C6 attempts first transmit, handles bounded lazy-init failure and finalizes into actual deep sleep; Pi emits nothing.
- **Expected/observations:** bounded I/O/BUSY initialization error, no started TX, no hang, valid specific diagnostic and sleep progression. No claim about RF simply from silence; hardware absence and pre-SetTx evidence are separate facts.
- **Cleanup/timing:** C; operator removes both direct ties before reconnecting module, restores nominal and runs RF-001. Reserve conservatively before trigger, release only proven non-attempt under operator-record rules.
- **Status/gate:** planned. **Blocks deployment:** available deterministic fault verifies startup does not obstruct node sleep.

<a id="rf-014"></a>

## RF-014 — Additional C6 electrical command/IRQ faults

- **Requirements/layer:** F-RAD broken-SPI, forced-BUSY, unexpected IRQ and uncertain post-command outcomes; real C6 backend, Pi passive/nominal peer as appropriate.
- **Initial state/prerequisites:** no approved fixture exists for these dynamic faults; require a separately reviewed isolated mechanism, exact injection point, signal safety and restoring action. N alone does not enable them. Operator required.
- **Actions:** inject each approved fault once at its declared primitive; C6 executes the production operation; Pi records any possible frame without treating reception as command certainty.
- **Expected/observations:** exact normalized failure/context, bounded return, no same-wake local-error retry; charge every started/uncertain attempt and zero only proven pre-SetTx failures. Preserve each failure family separately.
- **Cleanup/timing:** remove power on unconfirmed state, restore fixture and RF-001; reserve worst-case emission before injection.
- **Status/gate:** host fault matrix exists; physical cases unimplemented/unrun. **Can follow deployment:** available RF-012/RF-013 cover essential real terminal paths; expanded electrical characterization retains residual untested fault risk. Revisit when fixture exists, a related failure appears, or the backend changes.

<a id="rf-015"></a>

## RF-015 — Pi manual held-BUSY startup, no TX

- **Requirements/layer:** R-RAD, DIAG, [Pi procedure](../../receiver/tests/hardware/RADIO_TESTS.md#manual-held-busy-startup-case); ordinary Pi-local Radio/Sx1262/LinuxRadioIo component case.
- **Initial state/prerequisites:** C6 unpowered, Pi radio_busy_held with RTC shunts open; operator powers down and selects JP_RADIO_BUSY 2-3, isolating the raw module output. Existing explicit Pi hardware/fixture interlocks apply.
- **Actions:** Pi runs only its held-BUSY initialization case; C6 does nothing.
- **Expected/observations:** INITIALIZATION_FAILED, fatal INITIALIZE and CLEANUP/BUSY_TIMEOUT, no SPI/RX/SetTx and released handles. Unconfirmed safe_shutdown remains a failed/aborted session even when expected-fault assertions pass.
- **Cleanup/timing:** startup 2 s plus existing 50 ms service allowance; operator power-off/selector 1-2 restoration and a fresh nominal Pi run, with command/exits retained.
- **Status/gate:** implemented; historical 277,477-us fault and restored nominal, predating current radio changes. **Can follow deployment:** current nominal requalification is DEP-013; host bounded-failure coverage and fault-free nominal fixture support deferring this extra manual rerun. Revisit before using the fault selector or after related runtime defects. No full-system/RF claim.

<a id="rf-016"></a>

## RF-016 — Pi physical soft/hard recovery

- **Requirements/layer:** R-RAD recovery/event-stream resynchronization and DIAG; Pi-local production radio, optional C6 packet only after recovery.
- **Initial state/prerequisites:** C6 TX inhibited; Pi needs the deferred SN74LVC1G32 controlled BUSY fixture and revised schematic/input, not the manual selector. Operator assembly/readiness required.
- **Actions:** use finite RX timeout to create an IRQ; hold only Pi-observed BUSY. Release before soft recovery in one case; retain through soft failure and release at actual reset assertion in another; then optionally C6 sends A.
- **Expected/observations:** one completed episode per original trigger, correct attempted levels/counters and original/last failure details, bounded confirmed normal RX including event-stream resynchronization; immediate new event preserved. Verify real reset/profile state, not only return value.
- **Cleanup/timing:** C with gate released and physical confirmation; no-TX variant charges zero but must prove no SetTx; optional proof packet charged.
- **Status/gate:** Pi cases exist but selection rejects unavailable gate; current recovery fixes have host evidence only. **Can follow deployment, subject DEC-001:** additional controlled-fault qualification, not nominal readiness. Revisit when gate exists, recovery is observed in soak, or unexplained stream gaps occur; such an observed failure blocks deployment until resolved.

<a id="rf-017"></a>

## RF-017 — Independent radio edge and timing qualification

- **Requirements/layer:** F-RAD/F-CLK instrumentation limits and R-RAD physical timing; both production radios and GPIO timestamp paths.
- **Initial state/prerequisites:** N plus an identified calibrated/characterized capture instrument, safe probes and measured quantization/timebase uncertainty; currently only AN8008 available. Operator required; no instrument model invented.
- **Actions:** capture NSS/BUSY/DIO1/RESET during nominal TX/RX, finite timeout, transitions and recovery where its fixture exists. Correlate each device's timestamps to that instrument independently.
- **Expected/observations:** use receiver TESTING's 5,000-ppm relative allowance plus measured quantization; ACK NSS-end-to-TxDone early allowance on 61,696 us and late allowance additionally 5 ms TCXO + 10 ms command/ramp. RX adds 15.625-us timer quantum/oscillator startup. Python service latency has separate 50-ms late budget. Preserve F-RAD's distinct C6 bounds; no exact timestamps inferred from DC readings.
- **Cleanup/timing:** C, remove probes unpowered as required, all possible emissions included in operator records.
- **Status/gate:** unrun, instrument absent. **Can follow deployment:** functional IRQ, local-clock and gross timing assertions remain in gated RF cases; independent edge accuracy remains unqualified. Revisit if timing margin is poor, IRQ chronology fails, instrumentation becomes available or profile/kernel changes.

<a id="rf-018"></a>

## RF-018 — RF power, carrier and emissions assessment

- **Requirements/layer:** P-WIRE and firmware first RF envelope; both transmitter/module/antenna chains, not software-only testing.
- **Initial state/prerequisites:** identified modules, antennas/cables and actual power configuration; measurement needs appropriate RF equipment, calibration and an approved uncertainty/acceptance procedure under DEP-023/DEC-003. The multimeter is insufficient.
- **Actions:** under the approved instrument procedure, C6 and Pi emit the authorized patterns separately and the operator measures each transmitter/antenna-chain quantity required by that procedure. A source-only envelope decision is not execution of this physical case.
- **Expected/observations:** compare measurements to the reviewed operating-envelope limits with instrument uncertainty and actual antenna/path data. Current nominal 13.85 dBm ERP estimate has only about 0.13 dB margin and is not measured/bounded compliance. Do not invent a frequency tolerance or spectral-mask acceptance threshold. Adequate independent source evidence may resolve DEP-023 and justify deferring this measurement; it cannot turn RF-018 into a physical PASS.
- **Cleanup/timing:** restore original antenna chain and C; charge all test emissions including instrument acquisition retries.
- **Status/gate:** **Disposition approved 2026-09-18; physical measurement deferred NOT RUN.** DEC-003 explicitly accepts the existing documented hardware/configuration and source-based assessment for the pilot at configured +14 dBm, without inventing a numerical bound or measured PASS. DEP-023 includes autonomous wakes, retries and resets. See the [retained approval and source record](evidence/2026-09-18-envelope/README.md). Revisit when suitable instruments are available, the module/antenna/path/power/PHY changes, or conflicting RF evidence appears; retain the measurement procedure and original assertions.

<a id="rf-019"></a>

## RF-019 — Production node ACK policy with controlled Pi peer

- **Requirements/layer:** P-ID/P-ACK, F-CORE/DIAG; real node_core, persistence, crypto, radio and platform; Pi component peer deliberately supplies outcomes, not full receiver. Single replies use Radio; invalid-then-valid bursts use the explicitly identified Sx1262/LinuxRadioIo local sequence.
- **Initial state/prerequisites:** N, B, DEP-008/DEP-009 and the approved DEC-002 heuristic; disposable identities and bounded pending records. Operator authorizes any destructive storage setup before the run.
- **Actions:** separate cases supply four valid statuses, a representative invalid-authentication ACK followed by valid ACK in the original window, and authenticated wrong-message/domain-status ACKs with subsequent silence. Parameterize current versus backlog rejection without mixing their stop/continue rules.
- **Expected/observations:** ACK header echoes message_id, status/domain 03/0, 04/1, 05/2 or 06/3. ACCEPTED removes known pending copy and permits newest-first backlog; RETRY_LATER retains and stops the wake; permanent current rejection attempts quarantine/removal and stops; backlog rejection continues only after successful removal and budget admission. Invalid ACK never changes persistence/delivery or extends deadline. Verify frame bytes, diagnostics, delivery start/finish and next-wake metrics.
- **Cleanup/timing:** C; reserve complete retry episode, preserve counters/bindings across wakes; firmware 8 s/30 s limits and inclusive timestamp boundary remain unchanged.
- **Status/gate:** bare-C6 cases cover parts with fake radio, not RF. **Blocks deployment for representative real ACK validation and all four statuses:** share assertions with RF-020/RF-022/RF-024 where the actual node is exercised; exhaustive malformed ACK combinations remain host coverage.

<a id="rf-020"></a>

## RF-020 — First full production reading and next scheduled wake

- **Requirements/layer:** P-WIRE/P-ID/P-ACK, F-CORE, R-FLOW/R-LIFE; production node composition and complete Pi service.
- **Initial state/prerequisites:** N, isolated deployment, implemented production paths and applicable pre-radio host/component checks from DEP-001..DEP-006 and DEP-008..DEP-015 ready (DEP-007 is approved deferred); their later RF verification closes afterward, not as a circular prerequisite to this first run. Approved identity/configuration/envelope; operator commissioning/readiness required.
- **Actions:** node samples real sensors and sends current reading; service authenticates, reserves, ACKs, finalizes and persists. Let node perform the ordinary 900-second deep sleep and next wake.
- **Expected/observations:** independently decode 32-byte body and exact 54/23-byte frames; validate configured sensor channels/flags, reset reason, independent sample/message counters and same-acquisition values. Inspect one canonical sample/transport per new reading, complete profile with real optional timestamps and final ACK result. Next wake carries previous metrics from the completed wake. ACK observation alone is not durable SQLite evidence.
- **Cleanup/timing:** C plus consistent database/node-log capture; preserve counters. No shortened test interval substitutes for the production-image result; retain timing/airtime per endpoint.
- **Status/gate:** unimplemented orchestration, unrun. **Blocks deployment:** primary production acceptance; may jointly establish RF-001/RF-008/RF-010 with their assertions explicitly recorded.

<a id="rf-021"></a>

## RF-021 — Lost accepted ACK and exact retransmission

- **Requirements/layer:** P-ACK retransmission/deterministic ACK and F-CORE retries; full service plus actual node production components with a disclosed, local missed-downlink test mechanism.
- **Initial state/prerequisites:** N, RF-020, dedicated identity/storage; reviewed mechanism to miss one ACK at node without changing receiver acceptance or tampering with live RF/counters. This mechanism is not yet implemented; operator readiness only after review.
- **Actions:** service accepts/persists first uplink and sends accepted ACK; node misses only that downlink, retransmits exact frame; service reconstructs ACK and later node accepts it.
- **Expected/observations:** exact same 54-byte frame/message/domain on retry, identical accepted ACK bytes, one canonical reading/transport and two admitted occurrence profiles, second RETRANSMISSION. Distinguish confirmed receiver TX from node receipt; durable state/log effects match actual observations.
- **Cleanup/timing:** C, remove missed-downlink adaptation and retain final unmodified-image check; charge both node attempts and both ACKs; retry starts from node TX_DONE + 600..1000 ms, not SSH latency.
- **Status/gate:** host/bare-C6 policy coverage exists, full RF unrun. **Blocks deployment:** ordinary packet loss must not corrupt identity or persistence.

<a id="rf-022"></a>

## RF-022 — Current-to-backlog identity and newest-first drainage

- **Requirements/layer:** P-ID/P-ACK and F-CORE backlog binding; real production node and complete receiver.
- **Initial state/prerequisites:** N, RF-020; isolated counters and at least two pending samples obtained through real node/storage operations, no rewritten live counter state. Operator authorizes setup.
- **Actions:** miss current acceptance at the node, retain sample across wake; later accept new current, then drain prior samples newest first. Interrupt one bound backlog episode at a controlled software reset and retry its binding next wake.
- **Expected/observations:** current and backlog of one sample have different message_id/domain but identical body; backlog frame is durably bound before TX and loaded byte-for-byte on later wakes. Matching current/backlog produces DUPLICATE_SAME_CONTENT; an exact bound retry produces RETRANSMISSION. Canonical sample unchanged; verify node removal order and receiver profiles separately.
- **Cleanup/timing:** C, preserve operator records across reset; firmware budgets and 900-second acceptance cadence apply. No physical power-loss claim.
- **Status/gate:** host/bare-C6 parts implemented, full RF unrun. **Blocks deployment:** outage recovery depends on this exact identity behavior.

<a id="rf-023"></a>

## RF-023 — Receiver authenticated rejection, silence and ordering

- **Requirements/layer:** P-ACK ordered validation and R-FLOW/DIAG; controlled C6 packet generator over production radio/crypto, full Pi service. Deliberately malformed uplinks are not claimed as normal node_core output.
- **Initial state/prerequisites:** N, RF-020; reviewed packet matrix and independently encrypted fresh test messages; operator readiness, disposable credentials only.
- **Actions:** send representative valid-but-implausible reading; authenticated unsupported control/unknown domain; malformed body/flags; valid control with downlink ACK domain; bad tag; unknown/revoked node; short header. Use new nonce for changed authenticated contents.
- **Expected/observations:** implausible representable values accepted unchanged; unsupported -> domain05/status2; malformed -> domain06/status3; WRONG_DIRECTION at direction check, bad authentication/unusable header/unknown/revoked ID -> silence. Unsupported control precedes direction check. Profiles expose only length-valid untrusted claims, sample_id only after authenticated decode. No synthetic diagnostics for normal protocol outcomes. No transport-conflict RF vector constructed by reusing a nonce with altered plaintext; conflict matrices remain host tests.
- **Cleanup/timing:** C; restart only the isolated service for allowlist/revocation change, retain historical rows. Budget all negative frames and selected responses.
- **Status/gate:** protocol/ingress host coverage exists, full RF unrun. **Blocks deployment:** representative real rejection/silence ordering; exhaustive combinations remain host.

<a id="rf-024"></a>

## RF-024 — Queue pressure, storage outage and recovery

- **Requirements/layer:** P-ACK atomic admission, R-FLOW, receiver persistence/health contracts; full node/service with isolated test control at the real worker boundary.
- **Initial state/prerequisites:** N, RF-020; dedicated database and bounded reviewed worker-stall/storage-fault mechanism, not a guessed public control API. Destructive selection for storage mutations; operator confirms dedicated paths.
- **Actions:** pause ordinary worker at a named safe boundary and fill the 500-slot queue using defined admitted test work; send real readings and rejection/silent packets. Separately close persistence admission using an isolated storage failure; restore and retry.
- **Expected/observations:** no partial pair or second reservation, response-eligible failure selects RETRY_LATER, wrong-direction/unauthenticated traffic stays silent. Node retains current/backlog and stops its wake on retry-later. Recover retained FIFO work and later acceptance; health increments exactly the original admission cells, no recursive diagnostic or queue eviction. Compare SQL state after recovery.
- **Cleanup/timing:** release every barrier, boundedly recover/drain, restore storage/mounts and service; C. Do not fill by unpaced RF; precharge all actual TX.
- **Status/gate:** components have host/Pi evidence with source limits; integrated RF unrun. **Blocks deployment:** small dedicated backpressure/outage scenarios establish retention and fail-closed admission.

<a id="rf-025"></a>

## RF-025 — Receiver ACK suppression without undoing acceptance

- **Requirements/layer:** R-AIR, P-ACK and R-FLOW; real production grant owner/ingress/service plus node.
- **Initial state/prerequisites:** N, RF-020; explicitly select backlog or current parameter. Use isolated durable state deliberately conservatively charged through validated production state operations, or legally accumulated use. Record provenance; no invented spendable grant or direct production-database edit. For backlog, retain a real durably bound pending frame and arrange global headroom of exactly one ACK charge (67,866 us), sufficient current-bucket headroom and a durably acknowledged current-process grant for that charge. Use trusted Pi-local timing to prove the grant lasts through current acceptance and no retained charge ages out or other allowance becomes available before the target backlog suppression. Current pending append/removal must succeed, and enough of the node's shared 8 s/30 s budgets must remain to reach backlog. If these prerequisites cannot be established, this parameter is not ready to run.
- **Actions:** backlog: node first sends its new current reading; Pi spends the last ACK allowance, and node must observe authenticated ACCEPTED and remove its persisted current copy before draining to the target bound frame. Pi then accepts/persists that backlog occurrence with exhausted allowance and no TX. After legal aging and a new durable grant, receive the exact bound-frame retry; in any later wake, first acknowledge/remove its new current and every newer pending sample ahead of the target, within the shared node budgets. Do not inject a backlog frame directly in place of production node_core. Current: start with exhausted allowance and pre-establish a real aging/grant-acquisition window, with a measured guard, that permits an exact current retry and ACK within the same wake's remaining budgets. Never carry an abandoned current message across reset as if it were a bound backlog frame.
- **Expected/observations:** record the current ACCEPTED/removal-before-backlog order in the backlog parameter. For the targeted suppressed occurrence, require accepted application candidate and complete profile with airtime suppression, selected exact ACK present, absent T4/T5 and confirmed T6; no SetTx and no fabricated retry-later admission failure. Later exact retry gets the deterministic selected ACK and RETRANSMISSION; node retains/removes the target only according to actual ACK observation. Missing the initial current ACK, failing its removal, or missing the suppressed target is a failed requested scenario, not backlog-suppression evidence.
- **Cleanup/timing:** C, retain conservative charges; never accelerate real elapsed aging using clock steps. Pre-reserve each complete possible node wake/retry episode and every Pi ACK, including initial/current, intervening newer backlog and eventual target ACKs. Record both grants and real aging evidence; no SSH-timed allowance transition or shortened production sleep is assumed.
- **Status/gate:** host policy/ingress coverage exists; RF unrun. **Blocks deployment:** production enforcement must coexist with data collection. Suppression can share RF-029's interval.

<a id="rf-026"></a>

## RF-026 — Online, offline and untrusted timestamp episodes

- **Requirements/layer:** R-TIME, R-FLOW and PILOT Internet outage; complete service/time/analysis and real node.
- **Initial state/prerequisites:** N, RF-020, DEP-014; isolated service/time setup with valid durable RTC provenance for holdover, plus separate absent/invalid provenance cases. Operator authorizes network/time changes and recovery.
- **Actions:** collect readings online; remove network synchronization locally under the approved fixture; collect in validated holdover, then untrusted state; restore network and qualified observations. Retain separate explicit-step integration when required by DEP-014.
- **Expected/observations:** NETWORK_SYNCED, valid RTC_HOLDOVER or UNTRUSTED from real evidence; no network startup wait, no invented UTC, no cross-instance/boot or step-gap correlation. Verify immutable monotonic profiles, eligible earliest current direct anchor, run_ms+Tair <=30,000 ms, backlog logical chain and breaks. Use bracketed independent clock evidence, never cross-device monotonic subtraction. Offline storage persists regardless of forwarding decision DEC-004.
- **Cleanup/timing:** restore exact Chrony/network configuration, RTC/provenance and device access; C. Clock steps cannot erase charges.
- **Status/gate:** source-bound time components exist; integrated RF unrun. **Blocks deployment:** offline retention/time is an explicit pilot goal.

<a id="rf-027"></a>

## RF-027 — Receiver clean/crash restart between node attempts

- **Requirements/layer:** R-LIFE, R-AIR and P-ACK; complete service and production node.
- **Initial state/prerequisites:** N, RF-020, DEP-005; isolated service/storage; operator destructive permission for process termination.
- **Actions:** separately clean-restart and kill service at declared pre/post-grant and post-acceptance boundaries; let node retry after supervised restart.
- **Expected/observations:** new receiver_instance_id, same linux_boot_id, no repeated RTC bootstrap, new sequences; clean marker only with valid prerequisites. Durable rows survive; volatile accepted-but-uncommitted loss is recorded as permitted, not called a durability pass. Loaded airtime unspendable; exact duplicate handling and normal radio rearm after restart, no cached acceptance.
- **Cleanup/timing:** restore supervisor and verify service/queue/state; C for test end. Operator records span process death; no power-loss claim.
- **Status/gate:** component restart evidence exists, full service/RF unrun. **Blocks deployment:** unattended recovery is mandatory.

<a id="rf-028"></a>

## RF-028 — Pi reboot with trusted and unavailable time

- **Requirements/layer:** R-LIFE/R-TIME/R-AIR, P-ACK; complete service with real Pi reboot and node.
- **Initial state/prerequisites:** N, RF-020, DEP-004/DEP-014; isolated boot service, retained source/configuration and node pending frame. Operator authorizes reboot and recovery.
- **Actions:** reboot between attempts once with valid trusted reconstruction and once without trusted time. Laptop waits with bounded reconnect/readiness; node retains its counters and ordinary cadence.
- **Expected/observations:** both boot/receiver identities change; one boot-scoped RTC episode, durable lifecycle order, conservative charge reconstruction or TX suppression, continued RX/admission where storage permits. Verify retry frame and SQL classification, current time provenance and no reused Pi monotonic timestamp.
- **Cleanup/timing:** verify source, services, time/device permissions and journals after each reboot; C. Missing reconnect/restoration is failure, not automatic rerun. This is not physical supply-loss qualification.
- **Status/gate:** two airtime component reboot modes historically pass; complete service/RF unrun. **Blocks deployment:** reboot is an ordinary pilot failure boundary.

<a id="rf-029"></a>

## RF-029 — Production airtime across boundaries, resets and uncertainty

- **Requirements/layer:** firmware [continuous-hour ledger](../../firmware/ARCHITECTURE.md#continuous-hour-duty-cycle-accounting), F-CORE, R-AIR; each real production transmitter's enforcement.
- **Initial state/prerequisites:** N, configured production node/full service and operator-managed test allowance; DEC-002 approved and applicable DEC-006 dispositions resolved; isolated durable identities/state and reviewed uncertainty/reset mechanism. Operator approves destructive phases. Only the deferred firmware-ledger parameter additionally requires implemented/reviewed DEP-007.
- **Actions:** legally bounded sequence spanning hour/bucket boundaries, current/backlog retries, software resets and Pi process restart. Exercise definite pre-SetTx failure, confirmed start and uncertain command outcome separately; real C6 missing-DIO1 evidence may be collected in the RF-012 manual batch. Hardware-dependent receiver post-SetTx uncertainty needs the explicit mechanism in RF-031.
- **Expected/observations:** independent continuous-window history for each transmitter remains <=36,000,000 charged us; the current node retains its 8 s/30 s guards and normal 900-second cadence, with uncertain TX charged within the wake. Record reset behavior without claiming retained firmware allowance. Pi spends only acknowledged current-process grants, never refunds uncertainty, reconciles unknown commits and suppresses without reversing acceptance. Compare durable state, local command evidence and independently observed packets; peer nonreceipt cannot authorize refund. **Deferred firmware-ledger parameter:** after DEP-007, require durable pre-SetTx reservation, reset survival and unknown-state exhaustion; these assertions remain NOT RUN, not expected of the current image.
- **Cleanup/timing:** C; collect at least one full rolling window with its preceding-history baseline, preferably inside RF-030. Reset/uncertainty cases cannot exceed operator reservations. Physical power cuts stay DEP-017/DEC-006, not inferred here.
- **Status/gate:** firmware ledger absent; receiver component evidence excludes RF. **Split gate under approved DEC-002:** current node guard/uncertainty checks, operator-recorded rolling-window observation and receiver durable enforcement remain selected blockers. Firmware durable reservations/reset-spanning enforcement are approved deferred until DEP-007 resumes; absent ledger behavior is not a current-image failure or a PASS. Hardware-dependent receiver proof is approved deferred under DEC-006/RF-031 and remains NOT RUN. Revisit deferred firmware proof on repeated/unexpected resets, changed cadence/retry budgets or independent-enforcement requirements.

<a id="rf-030"></a>

## RF-030 — Minimum bench soak, then field continuation

- **Requirements/layer:** PILOT and R-FLOW complete soak; production node at normal cadence and full receiver service.
- **Initial state/prerequisites:** N in intended pilot configuration; all preceding selected blockers resolved; DEC-005 predeclared acceptance, current identities/source, storage capacity and operator recovery plan.
- **Actions:** run at least 24 hours (approved DEC-005 duration, superseding the older logbook duration); include nominal wakes, controlled missed ACK/backlog, offline operation, clean/crash recovery and legal boundary-spanning accounting. Complete at least one verified production 900-second sleep pair. Extend after deployment to at least one week in intended field/enclosure/antenna positions, using the operator-selected practical sensor placement under DEC-008 and documenting it in the logbook after deployment. Keep bench air-probe voltage limits separate from soil expectations; exact planned sensor depths are not a pilot gate.
- **Expected/observations:** reconcile every generated sample, message/frame attempt, node ACK result, canonical row, profile and available health/diagnostic counter; classify allowed volatile loss explicitly. Require no unexplained identity/state loss, unbounded wait, unsafe recovery, airtime overrun or unresolved failure; restored controlled faults. Record reception, retries, RSSI/SNR and storage growth without inventing a target percentage. DEC-005 approves 24 hours without adding numeric link/RSSI targets. Predeclare the schedule, denominators, gaps and stop conditions under DEP-019; report observed link performance.
- **Cleanup/timing:** bench restore C with source-bound archive; field operator follow-up/stop conditions remain DEP-020. Soak pacing respects the receiver durable ledger, current node guards/cadence and operator-managed per-transmitter history; no firmware durable-ledger result is inferred.
- **Status/gate:** no integrated soak exists; 30-second persistence load soak is not this test. **Blocks deployment for 24-hour bench phase; field-week phase follows deployment by definition.** Retain both phases under this ID with distinct results; do not gate first deployment on completion of the field week.

<a id="rf-031"></a>

## RF-031 — Full receiver post-SetTx failure and bounded recovery

- **Requirements/layer:** R-FLOW failed receiver TX outcome, R-AIR certainty, DIAG; full service, production radio and node.
- **Initial state/prerequisites:** N plus an approved controllable mechanism that produces a known real post-SetTx fault. Existing static Pi held-BUSY selector cannot create/release this during an active process. No suitable synchronized fixture/interface is presently established; operator required for its eventual installation.
- **Actions:** cause one real submitted ACK's terminal outcome to become unconfirmed; preserve service operation through bounded recovery when possible; node retries and later receives an ACK. Separately validate fatal UNKNOWN_INTERRUPTED in host full-system tests.
- **Expected/observations:** charge retained regardless of peer reception, exact TX_UNCONFIRMED or confirmed terminal result preserved, original/last failure diagnostic once, complete reserved profile published before best-effort diagnostic, confirmed RX or terminal state, later successful exact retry/canonical classification.
- **Cleanup/timing:** C plus verified fault release; reserve all possible emissions and observe Pi host-TX/recovery bounds.
- **Status/gate:** host radio/airtime composition exists; full physical scenario unimplemented/unrun. **Approved deferred under DEC-001/DEC-006:** full host integration, real nominal TX, C6 uncertainty and conservative restart tests provide bounded pilot evidence, but do not prove this Pi physical path. Revisit when fixture exists, any unexplained TX outcome/recovery occurs during bench/field use, or review requires it for airtime safety. RF-029 must report this assertion NOT RUN, never complete the whole family by inference.

## Coverage and execution references

The [inventory coverage index](../../deployment_remaining.notes.md#coverage-index) maps the full contracts and every firmware fast/manual radio and receiver radio/end-to-end family to these IDs, DEP work or retained evidence. The [implementation sequence](../../deployment_remaining.notes.md#dependency-ordered-sequence) specifies which nominal cases start early, which share acceptance runs, and which fixtures are grouped later.

Proposed entries are documented there; they must select explicit RF IDs and fixture states, reject absent prerequisites/mismatch/zero selection, and separate component, acceptance, slow and destructive scopes. Existing bare-C6 targets keep their meaning. No Make entry point in this plan exists yet.

Firmware-roadmap carryover: physical sensor rail/bus waveforms and low-current measurements remain DEP-027 equipment-dependent work; physical power-cut observation remains DEP-017; dedicated-runner ordinary/slow-job acceptance remains DEP-028. These do not acquire new RF IDs or become RF passes. Their procedures/fixtures must be specified and verified before implementation/execution.
