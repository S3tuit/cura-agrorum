"""Single-owner libgpiod-v2/spidev implementation of the production radio port."""

from datetime import timedelta
import errno
import importlib
import threading

from ..ports.clocks import MonotonicClock
from ..ports.radio import (
    Dio1Edge, Error, Outcome, RadioBackendError, RadioConfiguration,
    RadioFailure, Stage, integer,
)

_MISSING = {errno.ENOENT, errno.ENODEV, errno.ENXIO, errno.ESHUTDOWN}


class LinuxRadioIo:
    def __init__(self, clock: MonotonicClock):
        self.clock = clock
        self._owner = None
        self._request = None
        self._spi = None
        self._configuration = None
        self._gpiod = None
        self._last_sequence = 0
        self._last_timestamp_ns = 0
        self._used = False

    def _claim(self):
        current = threading.get_ident()
        if self._owner is None:
            self._owner = current
        elif self._owner != current:
            raise RuntimeError("radio I/O belongs to another thread")

    @staticmethod
    def _os_call(stage, call, *, outcome=Outcome.NOT_APPLICABLE):
        try:
            return call()
        except OSError as error:
            raise RadioBackendError(RadioFailure(
                Error.IO, stage, outcome,
                os_errno=error.errno,
                hardware_touched=True,
                hardware_missing=error.errno in _MISSING,
            )) from error

    def _deadline(self, deadline, stage, *, after=False):
        integer(deadline)
        now = self.clock.now_monotonic_us()
        if now > deadline or (now == deadline and not after):
            raise RadioBackendError(RadioFailure(
                Error.DEADLINE, stage,
                Outcome.UNCERTAIN if after else Outcome.DEFINITELY_NOT_APPLIED,
                hardware_touched=after,
            ))

    def open(self, configuration, *, deadline_monotonic_us):
        self._claim()
        if type(configuration) is not RadioConfiguration:
            raise TypeError("expected RadioConfiguration")
        if self._used:
            raise RuntimeError("radio I/O resources cannot be reopened")
        self._deadline(deadline_monotonic_us, Stage.CONFIGURE_GPIO)
        self._used = True
        self._configuration = configuration
        # Missing Python dependencies are deployment errors, not fabricated errno.
        self._gpiod = importlib.import_module("gpiod")
        spidev = importlib.import_module("spidev")
        line = self._gpiod.line
        settings = self._gpiod.LineSettings
        try:
            self._request = self._os_call(Stage.CONFIGURE_GPIO, lambda: self._gpiod.request_lines(
                configuration.gpio_chip,
                consumer="cura-radio",
                event_buffer_size=64,
                config={
                    configuration.reset_line: settings(
                        direction=line.Direction.OUTPUT,
                        drive=line.Drive.OPEN_DRAIN,
                        output_value=line.Value.ACTIVE,
                        bias=line.Bias.AS_IS,
                    ),
                    configuration.busy_line: settings(
                        direction=line.Direction.INPUT, bias=line.Bias.AS_IS,
                    ),
                    configuration.dio1_line: settings(
                        direction=line.Direction.INPUT,
                        edge_detection=line.Edge.RISING,
                        event_clock=line.Clock.MONOTONIC,
                        bias=line.Bias.AS_IS,
                    ),
                },
            ))
            self._deadline(deadline_monotonic_us, Stage.CONFIGURE_SPI)
            self._spi = self._os_call(Stage.CONFIGURE_SPI, spidev.SpiDev)
            self._deadline(deadline_monotonic_us, Stage.CONFIGURE_SPI)
            self._os_call(Stage.CONFIGURE_SPI, lambda: self._spi.open_path(configuration.spi_device))
            for name, value in (
                ("mode", 0), ("max_speed_hz", configuration.spi_speed_hz),
                ("bits_per_word", 8), ("lsbfirst", False), ("no_cs", False),
                ("cshigh", False), ("threewire", False), ("loop", False),
            ):
                self._deadline(deadline_monotonic_us, Stage.CONFIGURE_SPI)
                self._os_call(Stage.CONFIGURE_SPI, lambda n=name, v=value: setattr(self._spi, n, v))
                self._deadline(deadline_monotonic_us, Stage.CONFIGURE_SPI, after=True)
        except BaseException:
            # Preserve the opening failure while trying every acquired resource.
            self._release()
            raise

    def _ready(self):
        self._claim()
        if self._request is None or self._spi is None:
            raise RuntimeError("radio I/O is not open")

    def transfer(self, data, *, deadline_monotonic_us):
        self._ready()
        if type(data) is not bytes or not 1 <= len(data) <= 260:
            raise ValueError("SPI transaction must be 1..260 immutable bytes")
        self._deadline(deadline_monotonic_us, Stage.WRITE_COMMAND)
        received = self._os_call(
            Stage.WRITE_COMMAND,
            lambda: self._spi.xfer2(list(data)),
            outcome=Outcome.UNCERTAIN,
        )
        self._deadline(deadline_monotonic_us, Stage.WRITE_COMMAND, after=True)
        if not isinstance(received, (list, bytes, bytearray)) or len(received) != len(data):
            raise RadioBackendError(RadioFailure(
                Error.MALFORMED_RESPONSE, Stage.READ_COMMAND,
                Outcome.UNCERTAIN, hardware_touched=True,
            ))
        if any(type(value) is not int or not 0 <= value <= 255 for value in received):
            raise RadioBackendError(RadioFailure(
                Error.MALFORMED_RESPONSE, Stage.READ_COMMAND,
                Outcome.UNCERTAIN, hardware_touched=True,
            ))
        return bytes(received)

    def _value(self, offset, stage):
        self._ready()
        value = self._os_call(stage, lambda: self._request.get_value(offset))
        if value is self._gpiod.line.Value.ACTIVE:
            return True
        if value is self._gpiod.line.Value.INACTIVE:
            return False
        raise RadioBackendError(RadioFailure(Error.MALFORMED_RESPONSE, stage, hardware_touched=True))

    def busy(self):
        self._ready()
        return self._value(self._configuration.busy_line, Stage.WAIT_BUSY)

    def dio1(self):
        self._ready()
        return self._value(self._configuration.dio1_line, Stage.READ_IRQ)

    def set_reset(self, *, asserted):
        self._ready()
        if type(asserted) is not bool:
            raise TypeError("reset level must be Boolean")
        value = self._gpiod.line.Value.INACTIVE if asserted else self._gpiod.line.Value.ACTIVE
        self._os_call(
            Stage.RESET, lambda: self._request.set_value(self._configuration.reset_line, value),
            outcome=Outcome.UNCERTAIN,
        )

    def wait_edge(self, *, deadline_monotonic_us):
        self._ready()
        integer(deadline_monotonic_us)
        while True:
            remaining = max(0, deadline_monotonic_us - self.clock.now_monotonic_us())
            available = self._os_call(Stage.WAIT_IRQ, lambda: self._request.wait_edge_events(
                timeout=timedelta(microseconds=min(remaining, 1_000_000)),
            ))
            if available:
                events = self._os_call(Stage.WAIT_IRQ, lambda: self._request.read_edge_events(max_events=1))
                if len(events) != 1:
                    raise RadioBackendError(RadioFailure(Error.MALFORMED_RESPONSE, Stage.WAIT_IRQ, hardware_touched=True))
                event = events[0]
                if (
                    event.event_type is not self._gpiod.EdgeEvent.Type.RISING_EDGE
                    or event.line_offset != self._configuration.dio1_line
                    or type(event.line_seqno) is not int
                    or event.line_seqno != self._last_sequence + 1
                    or type(event.timestamp_ns) is not int
                    or not self._last_timestamp_ns <= event.timestamp_ns <= (1 << 64) - 1
                ):
                    raise RadioBackendError(RadioFailure(Error.MALFORMED_RESPONSE, Stage.WAIT_IRQ, hardware_touched=True))
                self._last_sequence = event.line_seqno
                self._last_timestamp_ns = event.timestamp_ns
                return Dio1Edge(event.timestamp_ns, event.line_seqno)
            if self.clock.now_monotonic_us() >= deadline_monotonic_us:
                return None

    def _release(self):
        failure = None
        for name, method, stage in (
            ("_spi", "close", Stage.CONFIGURE_SPI),
            ("_request", "release", Stage.DETACH_IRQ),
        ):
            resource = getattr(self, name)
            setattr(self, name, None)
            if resource is not None:
                try:
                    self._os_call(stage, getattr(resource, method))
                except BaseException as error:
                    failure = failure or error
        return failure

    def close(self):
        self._claim()
        failure = self._release()
        if failure is not None:
            raise failure
