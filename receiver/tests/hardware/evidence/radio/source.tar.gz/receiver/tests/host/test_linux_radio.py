"""Production Linux adapter tested at the actual gpiod/spidev dependencies."""

from collections import deque
from enum import Enum
import errno
import json
from types import SimpleNamespace as NS
from threading import Thread

import pytest

from cura_receiver.platform import linux_clocks, linux_radio
from cura_receiver.ports.radio import (
    Error, Outcome, RadioBackendError, RadioConfiguration, Stage,
)
from tests.support.fakes.os_clock import FakeOsClock


class Value(Enum):
    ACTIVE = 1
    INACTIVE = 0


class Dependencies:
    """Only dependency calls, queued results and explicit named hooks."""

    def __init__(self, clock):
        self.clock = clock
        self.calls = []
        self.hooks = {}
        self.events = deque()
        self.received = [0, 0x24]
        self.level = Value.INACTIVE
        self.line = NS(
            Value=Value, Direction=NS(INPUT="in", OUTPUT="out"),
            Drive=NS(OPEN_DRAIN="open-drain"), Bias=NS(AS_IS="as-is"),
            Edge=NS(RISING="rising"), Clock=NS(MONOTONIC="monotonic"),
        )
        self.gpiod = NS(
            line=self.line, LineSettings=lambda **kwargs: kwargs,
            request_lines=self.request_lines,
            EdgeEvent=NS(Type=NS(RISING_EDGE="rise")),
        )
        owner = self

        class Spi:
            def __setattr__(self, name, value):
                owner.call("property", name, value)

            def open_path(self, path):
                owner.call("open_path", path)

            def xfer2(self, data):
                owner.call("xfer2", data)
                return owner.received

            def close(self):
                owner.call("close")

        self.spidev = NS(SpiDev=Spi)

    def call(self, name, *args):
        self.calls.append((name, *args))
        if name in self.hooks:
            self.hooks[name]()

    def request_lines(self, path, **kwargs):
        self.call("request_lines", path, kwargs)
        return self

    def get_value(self, offset):
        self.call("get_value", offset)
        return self.level

    def set_value(self, offset, value):
        self.call("set_value", offset, value)

    def wait_edge_events(self, *, timeout):
        self.call("wait_edge_events", timeout)
        if self.events:
            return True
        self.clock.advance_elapsed_us(int(timeout.total_seconds() * 1_000_000))
        return False

    def read_edge_events(self, *, max_events):
        self.call("read_edge_events", max_events)
        return [self.events.popleft()]

    def release(self):
        self.call("release")


@pytest.fixture
def device(monkeypatch):
    clock = FakeOsClock(monotonic_us=100)
    dependencies = Dependencies(clock)
    monkeypatch.setattr(linux_radio.importlib, "import_module", lambda name: {
        "gpiod": dependencies.gpiod, "spidev": dependencies.spidev,
    }[name])
    return linux_radio.LinuxRadioIo(clock), dependencies, clock


def failure(error):
    def raise_it():
        raise error
    return raise_it


# Open requests all lines atomically with kernel monotonic edges and fixed SPI.
def test_open_configuration_and_active_low_reset(device):
    io, deps, _ = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    config = deps.calls[0][2]
    assert config["config"] == {
        22: dict(direction="out", drive="open-drain", output_value=Value.ACTIVE, bias="as-is"),
        24: dict(direction="in", bias="as-is"),
        23: dict(direction="in", edge_detection="rising", event_clock="monotonic", bias="as-is"),
    }
    assert config["event_buffer_size"] == 64
    assert deps.calls[1:] == [
        ("open_path", "/dev/spidev0.0"), ("property", "mode", 0),
        ("property", "max_speed_hz", 1000000), ("property", "bits_per_word", 8),
        ("property", "lsbfirst", False), ("property", "no_cs", False),
        ("property", "cshigh", False), ("property", "threewire", False),
        ("property", "loop", False),
    ]
    io.set_reset(asserted=True)
    io.set_reset(asserted=False)
    assert deps.calls[-2:] == [("set_value", 22, Value.INACTIVE), ("set_value", 22, Value.ACTIVE)]
    io.close()
    io.close()
    assert deps.calls[-2:] == [("close",), ("release",)]
    with pytest.raises(RuntimeError):
        io.open(RadioConfiguration(), deadline_monotonic_us=1000)


# Run the actual manual hardware case through Linux/SX1262/owner code at the dependency seam.
@pytest.mark.parametrize("release_fails", [False, True])
def test_manual_hardware_case_keeps_fault_and_cleanup_evidence(device, tmp_path, monkeypatch, release_fails):
    from tests.hardware import test_radio as hardware_radio
    from tests.support.fakes.radio_io import Wait

    _, deps, clock = device
    deps.level = Value.ACTIVE
    if release_fails:
        deps.hooks["release"] = failure(OSError(errno.EIO, "release failed"))
    monkeypatch.setattr(clock, "wait_until_monotonic_us", Wait(clock).wait_until_monotonic_us, raising=False)
    monkeypatch.setattr(hardware_radio, "LinuxOsClock", lambda: clock)
    request = NS(node=NS(name="test_manual_busy_held_startup"))
    fixture = hardware_radio.radio_component.__wrapped__(request, (tmp_path, RadioConfiguration()))
    component = next(fixture)
    if release_fails:
        with pytest.raises(AssertionError):
            hardware_radio.test_manual_busy_held_startup(component)
        assert not (tmp_path / "held-busy-observation.json").exists()
    else:
        hardware_radio.test_manual_busy_held_startup(component)
        observation = json.loads((tmp_path / "held-busy-observation.json").read_text())
        assert observation == {
            "expected_fault_observed": True, "safe_shutdown_confirmed": False,
            "manual_restoration_required": True,
        }
    with pytest.raises(pytest.exit.Exception) as stopped:
        next(fixture)
    assert stopped.value.returncode == 1
    assert (tmp_path / "manual-restoration-required.json").exists()
    assert deps.calls[-2:] == [("close",), ("release",)]
    assert not any(call[0] == "xfer2" for call in deps.calls)
    assert deps.calls[0][2]["config"][24]["direction"] == "in"


# Each failed acquisition preserves errno and releases exactly acquired resources.
@pytest.mark.parametrize("point,cleanup", [
    ("request_lines", []), ("open_path", [("close",), ("release",)]),
    ("property", [("close",), ("release",)]),
])
@pytest.mark.parametrize("number,missing", [(errno.EACCES, False), (errno.ENOENT, True), (errno.EIO, False)])
def test_partial_acquisition_failure(device, point, cleanup, number, missing):
    io, deps, _ = device
    deps.hooks[point] = failure(OSError(number, "injected"))
    with pytest.raises(RadioBackendError) as caught:
        io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    assert caught.value.failure.os_errno == number
    assert caught.value.failure.hardware_missing is missing
    assert [call for call in deps.calls if call[0] in ("close", "release")] == cleanup


# A cleanup exception cannot prevent the second resource's release or invent status.
@pytest.mark.parametrize("error", [OSError(errno.EIO, "close"), RuntimeError("implementation")])
def test_close_attempts_both_resources(device, error):
    io, deps, _ = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    deps.hooks["close"] = failure(error)
    with pytest.raises(RadioBackendError if isinstance(error, OSError) else RuntimeError):
        io.close()
    assert deps.calls[-2:] == [("close",), ("release",)]
    io.close()


# xfer2 holds CS for one transaction and returned storage is copied immediately.
def test_spi_transaction_and_copy(device):
    io, deps, _ = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    result = io.transfer(b"\xc0\x00", deadline_monotonic_us=1000)
    deps.received[1] = 255
    assert result == b"\x00\x24"
    assert deps.calls[-1] == ("xfer2", [192, 0])


# Invalid dependency responses cannot become apparently valid status bytes.
@pytest.mark.parametrize("response", [None, (), [], [0], [0, 256], [0, True], [0, -1]])
def test_malformed_spi_response(device, response):
    io, deps, _ = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    deps.received = response
    with pytest.raises(RadioBackendError) as caught:
        io.transfer(b"\xc0\x00", deadline_monotonic_us=1000)
    assert caught.value.failure.code is Error.MALFORMED_RESPONSE
    assert caught.value.failure.outcome is Outcome.UNCERTAIN


# A pre-call deadline forbids submission; an overrun or ioctl error is uncertain.
@pytest.mark.parametrize("fault", ["before", "after", "io"])
def test_transfer_certainty(device, fault):
    io, deps, clock = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    if fault == "after":
        deps.hooks["xfer2"] = lambda: clock.advance_elapsed_us(901)
    elif fault == "io":
        deps.hooks["xfer2"] = failure(OSError(errno.EIO, "transfer"))
    with pytest.raises(RadioBackendError) as caught:
        io.transfer(b"\x83\x00", deadline_monotonic_us=100 if fault == "before" else 1000)
    assert caught.value.failure.outcome is (Outcome.DEFINITELY_NOT_APPLIED if fault == "before" else Outcome.UNCERTAIN)
    assert (deps.calls[-1][0] == "xfer2") is (fault != "before")


# Queued edges preserve nanoseconds even when their timestamps exceed the bound.
def test_edge_timestamp_and_bounded_idle_wait(device):
    io, deps, clock = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    deps.events.append(NS(event_type="rise", line_offset=23, line_seqno=1, timestamp_ns=1000001))
    edge = io.wait_edge(deadline_monotonic_us=1000)
    assert (edge.timestamp_ns, edge.monotonic_us, edge.sequence) == (1000001, 1000, 1)
    assert io.wait_edge(deadline_monotonic_us=2000100) is None
    assert clock.now_monotonic_us() == 2000100
    assert all(call[1].total_seconds() <= 1 for call in deps.calls if call[0] == "wait_edge_events")


# Wrong lines, edge kinds, lost events and invalid timestamps invalidate evidence.
@pytest.mark.parametrize("change", [
    {"line_offset": 24}, {"event_type": "fall"}, {"line_seqno": 2},
    {"line_seqno": True}, {"timestamp_ns": -1}, {"timestamp_ns": True},
])
def test_edge_validation(device, change):
    io, deps, _ = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    fields = dict(event_type="rise", line_offset=23, line_seqno=1, timestamp_ns=101000)
    deps.events.append(NS(**(fields | change)))
    with pytest.raises(RadioBackendError) as caught:
        io.wait_edge(deadline_monotonic_us=1000)
    assert (caught.value.failure.code, caught.value.failure.stage) == (Error.MALFORMED_RESPONSE, Stage.WAIT_IRQ)


# A setter reaching the exact bound prevents the next hardware configuration call.
def test_configuration_deadline_between_calls(device):
    io, deps, clock = device
    deps.hooks["property"] = lambda: clock.advance_elapsed_us(900)
    with pytest.raises(RadioBackendError):
        io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    assert [c for c in deps.calls if c[0] == "property"] == [("property", "mode", 0)]
    assert deps.calls[-2:] == [("close",), ("release",)]


# The real wait adapter rechecks early wakeups, without sleeping in this host test.
def test_linux_wait_rechecks_absolute_deadline(monkeypatch):
    clock = linux_clocks.LinuxOsClock()
    observed = iter([100000, 120000, 150000])
    sleeps = []
    monkeypatch.setattr(linux_clocks.time, "clock_gettime_ns", lambda _: next(observed))
    monkeypatch.setattr(linux_clocks.time, "sleep", sleeps.append)
    clock.wait_until_monotonic_us(150)
    assert sleeps == [0.00005, 0.00003]


# A different thread is rejected before it can access either hardware dependency.
def test_single_owner(device):
    io, deps, _ = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    before = deps.calls.copy()
    errors = []

    def contender():
        try:
            io.busy()
        except BaseException as error:
            errors.append(error)

    worker = Thread(target=contender)
    worker.start()
    worker.join(5)
    assert not worker.is_alive()
    assert len(errors) == 1 and type(errors[0]) is RuntimeError
    assert deps.calls == before


# Every GPIO dependency failure preserves its primitive and the exact host errno.
@pytest.mark.parametrize("method,point,stage", [
    ("busy", "get_value", Stage.WAIT_BUSY),
    ("dio1", "get_value", Stage.READ_IRQ),
    ("wait_edge", "wait_edge_events", Stage.WAIT_IRQ),
    ("set_reset", "set_value", Stage.RESET),
])
def test_gpio_errno(device, method, point, stage):
    io, deps, _ = device
    io.open(RadioConfiguration(), deadline_monotonic_us=1000)
    deps.hooks[point] = failure(OSError(errno.ENODEV, "disconnected"))
    kwargs = {"deadline_monotonic_us": 1000} if method == "wait_edge" else {"asserted": True} if method == "set_reset" else {}
    with pytest.raises(RadioBackendError) as caught:
        getattr(io, method)(**kwargs)
    assert caught.value.failure.stage is stage
    assert caught.value.failure.os_errno == errno.ENODEV
    assert caught.value.failure.hardware_missing
