# Joint RF verification

This directory is for field-pilot-v2 scenarios involving the C6 node and Pi
receiver. The [RF catalogue](test_suite.notes.md) defines stable scenarios and
their component or full-system scope; the [deployment inventory](../../deployment_remaining.notes.md)
maps coverage, dependencies and proposed pilot gates. Both .notes files are
ignored local planning documents.

Laptop pytest coordinates pytest-embedded through the C6's actual UART
connector and SSH control of a separate Pi process. The C6 Unity app and
ESP-IDF configuration belong in firmware/test_apps/radio/; the Pi component
peer belongs in receiver/test_apps/radio_peer/ and reuses production radio
components. The component apps and guarded runner now implement
RF-001/003/006/008/009/010/012/013. Physical outcomes and remaining obligations
are recorded separately in [COVERAGE.md](COVERAGE.md).

Receiver production code and hardware operations run on Pi. Ordinary Pi-local
tests remain in receiver/tests/hardware/; protocol verification remains in
protocol/protocol-v2-lora/tests/. A component peer does not establish full
receiver acceptance.

Future runs require explicit cases, fixture readiness, isolated identities and
storage, bounded local scheduling and airtime accounting at both transmitters.
SSH coordinates readiness; independent endpoint clocks are not synchronized.
Keep helpers local until a second real use justifies sharing.

For the first test phase, the operator owns per-transmitter airtime accounting,
admission and pacing using retained manual records. The harness declares
bounded episodes, waits for operator readiness and records attempts; automated
airtime ledgers and cross-run scheduling are not prerequisites. An additional
receiver is a cross-check, not a fresh-allowance test based on silence.
DEC-002 accepts the current firmware wake-budget/sleep heuristic for this pilot
and defers DEP-007 plus RF-029's firmware-ledger assertions. The receiver's
durable airtime policy remains unchanged.

## Run a selected component case

Read [EPISODES.md](EPISODES.md) for the simple packet/charge table, local timing
and bounded cleanup. The operator handles admission and pacing. Keep the manual
sheet across cases, resets and reruns.

1. Build in the configured ESP-IDF environment with `make test-rf-build`, then
   run `make test-rf-host`. The seal hashes actual compiler dependencies, ELF,
   configuration and flash files. Rebuild/reseal when those inputs change.
2. Copy [fixture.example.json](fixture.example.json) to a run input outside the
   source tree. Confirm each actual device/fixture field; the example's false
   fields intentionally cannot authorize hardware. Use nominal C6, nominal Pi
   and open RTC shunts. Select fault wiring only with power removed; DIO1 open
   needs RN5, and complete module absence needs both specified BUSY/MISO ties.
3. Keep a simple [operator record](operator-record.example.txt) for both physical
   transmitters. Supply its path, the exact cases/parameters, a new run ID and a
   new evidence directory. The runner prompts before each episode. Supplying
   `--ready-run` with the exact run ID explicitly admits the entire selected
   batch; use it only when its complete schedule is already operator-approved.
4. Supply SSH authentication at runtime through your agent or
   `CURA_PI_PASSWORD`. SSH/scp use `-F /dev/null`. The runner stages and verifies
   the current selected source tree in a unique `/var/tmp/cura-rf-<run>` directory.
   It never executes an old Pi checkout. Pi `python3` needs the production radio
   dependencies in `receiver/requirements-radio.txt`; select an isolated environment
   with `--peer-python /absolute/path/to/venv/bin/python`. The peer checks dependency
   versions and required APIs before opening radio devices. When using an IP
   address, `--host-key-alias cura-receiver` retains the existing SSH host identity.

Example first exchange (replace paths/run ID with the actual operator inputs):

```sh
make test-rf-component-nominal RF_ARGS='--fixture /tmp/rf-fixture.json --cases RF-001.exchange --run 0123456789abcdef0123456789abcdef --output /tmp/rf-run-01 --manual-record /tmp/rf-airtime.txt --confirm-flash'
```

`--confirm-flash` acknowledges replacement of the factory app. The runner checks
the actual flash ranges and binds the factory MAC with a no-reset probe before
requesting the DUT; the identity probe leaves the MCU in its bootloader and cannot
start an old autonomous image. The runner rejects erase-all, NVS erase,
forced/encrypted/alternate-port flashing and stale builds.
See the [app's storage disclosure](../../firmware/test_apps/radio/README.md).

The remaining nominal parameters are `RF-003.silence`, `RF-006.invalid`,
`RF-008.silence`, `RF-008.exchange`, `RF-009.untouched`,
`RF-009.initialized`, `RF-010.wake`. Comma-separated selection is explicit;
there is no automatic retry or implicit “all.” RF-001 must precede dependent
cases, and RF-003 must precede RF-008. Alternatively, `--prior /path/to/run`
accepts a verified passing archive with matching source/build. The two
`test-rf-component-dio1_disconnected` / `test-rf-component-radio_absent` targets
select only `RF-012.disconnected` / `RF-013.absent`, respectively, with matching
manual fixture confirmation and prior nominal evidence. Run fresh RF-001 after
restoring nominal wiring; a fault result never establishes restoration.

If the source manifest changed but the prerequisite remains applicable, supply
`--prior-applicability /path/to/review.json` alongside `--prior`. The original
archive is reverified and remains untouched. Both device identities and the
complete firmware build must still match. Before either device is accessed,
the review must bind the exact prior archive/source/build and current
source/build, and enumerate every added, removed or changed source file with
its old/new hash and a nonempty applicability rationale. Unreviewed, extra or
stale entries fail closed; documentation and verifier files are not implicitly
excluded. A review is an explicit acceptance decision, not an automatic proof
that a changed file cannot affect the prerequisite.

The JSON fields are `schema: 1`, `reviewer`, `decision`, `prior`, `current`, and
`changes`. `prior` contains `run`, `source`, `elf`, `archive` (SHA256SUMS.json
hash) and `build` (build.json hash); `current` contains `source`, `elf`, `build`.
`changes` maps each changed source path to `before`, `after`, `reason`; use null
for the absent side of an added/removed file. Keep this run input outside the
manifested source tree. The new archive retains the review and prior manifest;
the standalone verifier checks those bindings again. Changed firmware builds
require new nominal evidence. Relevant changes to peer behavior or case
expectations likewise require rerunning affected prerequisites under DEC-007.

## Evidence and failures

Each run retains the source archive/manifest/diff, actual build dependency and
binary hashes, fixture, operator sheet/readiness, declared episodes, raw
pytest-embedded UART logs, Pi SPI/IRQ/process records, per-parameter comparisons,
JUnit, exit codes and checksums. Verify a completed archive with:

```sh
.venv/bin/python tests/rf/verify.py /path/to/run
```

The verifier rechecks bytes/outcomes/timestamps, complete Pi direction-profile
commands and cleanup/handle release, and distinct endpoint assertions;
it imports neither DUT implementation. A failed Python/peer/cleanup result
cannot be replaced by a passing Unity subcase. First failure stops the selected
batch. Keep failed attempts. Missing prerequisites, zero selection, unexpected
events/reset, unconfirmed teardown and absent required evidence cannot pass.

The component app enters real short deep sleep after its bounded command and
wakes into a non-transmitting wait. RF-010's second wake requires a fresh host
command. After an interrupted run, issue no new trigger and confirm endpoint
termination/safety or remove all power/back-power paths; retain possible charges.
An ordinary production image has different autonomous-wake requirements.

RF-019 and full-service acceptance remain pending their production dependencies.
No complete-service, durable-airtime-enforcement, electrical timing, output-power
measurement or production 900-second-sleep result follows from this component suite.
