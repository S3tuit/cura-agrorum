# Radio component coverage map

This is the implementation map for the required
[Radio families](../TESTING.md#radio), not a report of passing tests.
The production physical port, Linux adapter, SX1262 command backend, radio
owner and diagnostic codec/factory are implemented. Host coverage lives in:

- `host/test_linux_radio.py` and `host/test_sx1262.py`: physical dependency
  failures, exact transactions/profiles, bounded BUSY/reset and certainty;
- `host/test_radio.py`: state, IRQ, ACK, recovery, shutdown, every reviewed TX
  setup/confirmation transaction, and real airtime settlement;
- `host/test_radio_diagnostics.py`: the complete catalogue matrix, literal
  context bytes, validation and bounded episode completion;
- `host/test_radio_ingress_contract.py`: copied bytes through real ingress,
  queue and SQLite, plus approved failure-result persistence;
- `host/test_radio_model.py`: reviewed independent examples and generated
  valid/faulted histories; and
- `host/test_radio_fixture.py`: fixture input and collection interlocks.

These are component tests; they do not claim communicator orchestration or
physical acceptance. Non-peer hardware cases are implemented in
`hardware/test_radio.py`, with the procedure in
[hardware/RADIO_TESTS.md](hardware/RADIO_TESTS.md). The first operator-run
nominal attempt on 2026-09-17 failed during initialization on post-reset status
0x2A, before a test body ran. Its source hashes and raw evidence were verified;
it provides no nominal acceptance. The fixture records wiring/power checks,
but no numeric powered measurements. A fresh staged run after those fixes
passed device/GPIO configuration and initialization/readback, but failed the
finite RX-timeout/rearm case on status 0x26 alongside IRQ 0x0200. All three
teardowns confirmed safety. The complete nominal suite remains failing;
the approved runtime status/IRQ correction is implemented and host-validated,
with its fresh Pi rerun pending.

Host validation on 2026-09-17 after the approved runtime status/IRQ
correction: `make test-receiver-host` passed 3,142 cases; the focused
backend/owner/model/ingress/diagnostic/Linux/fixture selection passed 657. Hardware-file compilation and diff checks passed.
Earlier backend validation passed 258 protocol cases and both generators'
validation/freshness checks; the manual fixture revision changes no protocol
or schema production code. These results do not satisfy any physical acceptance
row.

## Host families

| Required family | Implementation boundary |
|---|---|
| Initialization profile | Production command/profile backend transcript and owner state |
| Initialization terminals | Normalized device errors and bounded owner initialization |
| Post-reset status | Captured 0x2A, fresh command confirmation and exact startup/post-calibration error masks |
| Failed-startup cleanup | Retained safety/release result and distinct original/cleanup diagnostics through terminal shutdown |
| RX event classification | IRQ snapshot, packet-copy result, clear/rearm transcript |
| Correlated event confirmation | Captured 0x26/0x0200, immutable status/IRQ/errors, immediate-edge retention, chronology/mode/error conflicts and strict subsequent commands |
| Pi-owned packet snapshot | Copied backend bytes through real ingress and queue publication |
| Response-free RX rearm | Owner rearm operation after caller-selected silent/suppressed handling |
| ACK profile transition | Prepared bytes, external allowance handoff, backend profile/SetTx transcript |
| Definite pre-SetTx failure | Command certainty, optional T4, external refund facts, RX restoration |
| Started or uncertain SetTx | TX_ACTIVE only after SetTx; charge retention and TX_UNCONFIRMED |
| Missing or delayed TxDone | Injected monotonic deadline and timestamped IRQ events |
| BUSY and SPI failures | Existing production port with precise primitive fault injection |
| Soft and hard recovery | Owner recovery transitions, counters, one immutable episode |
| Event immediately after recovery | New DIO1 event preserved across confirmed SetRx |
| Diagnostic catalogue enforcement | Handwritten context codec/factory and generated receiver enums |
| Controlled radio shutdown | Owner shutdown and production backend resource lifecycle |
| Interrupted recovery accounting | Owner shutdown at soft/hard primitive boundaries and diagnostic builder tests |
| Radio state-machine properties | Independent primitive model after reviewed deterministic examples |

The physical-port fake is shared by backend and owner tests after both
established its real boundary.
No reference model may derive its expected behavior from production profile
builders, command encoders, or state transitions.

## Hardware families

| Required family | Evidence boundary |
|---|---|
| Device and permission probe | Configured devices opened as the intended service user |
| Real initialization | Attached board, production SPI/GPIO, confirmed profile/mode |
| Manual held-BUSY startup | Isolated Pi input tied high, bounded fatal startup, no SPI/RX/TX, unconfirmed cleanup retained; separate nominal restoration run |
| Real BUSY behavior | Raw radio BUSY waveform and bounded production waits |
| DIO1 timestamp path | Controlled radio IRQ, kernel monotonic edge, matching observations |
| Normal-IQ uplink reception | Independent component peer and reviewed exact payload |
| Inverted-IQ ACK transmission | Independent peer with matching and opposite IQ settings |
| Profile restoration | Alternating peer RX/TX evidence after each rearm |
| Radio timing characterization | Raw command/edge samples and independent timing reference |
| Hardware reset recovery | Controllable physical fault, real reset/profile restoration |
| Safe-state teardown | Confirmed configured safe state; failure stops dependent cases |

The [carrier proposal](../hardware/TEST_CARRIER.md#proposed-sx1262-extension)
defines connections and fault states. Selected missing hardware fails; there
is no runtime skip or host result that satisfies a physical obligation.
The operator has deferred the RF peer until a real-node strategy is agreed;
waveform and timing acceptance also await an instrument beyond the available
multimeter. No peer placeholder or RF acceptance is provided.
The unavailable SN74LVC1G32 gate and its synchronized physical soft/hard
recovery execution are also operator-deferred. Nominal non-peer cases remain
independent of that gate. The manual held-BUSY startup case is implemented,
but has not run on hardware and cannot satisfy the runtime recovery obligation.
Its unconfirmed cleanup terminates the session nonzero even when the expected
fault is observed; powered-off selector restoration and a fresh nominal run
remain required. The source manifest includes the shared rail/selector
schematic and operator procedure.

## Radio diagnostics and orchestration boundary

The [required diagnostic tests](../INTERFACE_DIAGNOSTIC.md#required-radio-diagnostic-tests)
map to the context/factory tests for exact bytes and catalogue rejection, and
to owner tests for direct anomalies, recovery episode cardinality, severity,
original/last failure evidence, correlations, certainty and normal IRQ outcomes.
Generator freshness and receiver/firmware independence remain host checks.

The radio returns an immutable completed episode. Host tests cover safe behavior
after the caller discards that result without performing diagnostic admission. Its safe-state result,
transmission facts and counters are fixed before the caller can discard the
episode, assign a diagnostic identity or attempt admission. Component tests
cover that independence and do not manufacture a communicator to claim the
following later orchestration obligations:

- publishing an already reserved profile before attempting diagnostic admission;
- preserving that publication when the diagnostic reservation fails;
- top-level communicator crash/exception and persistence-unavailability handling.

These obligations remain with the production communicator's tests. The
packet-snapshot test may compose existing real ingress and queue components to
verify byte ownership; that limited composition is not receiver end-to-end
coverage. Durable grant acquisition/settlement and protocol selection retain
their existing production owners.
