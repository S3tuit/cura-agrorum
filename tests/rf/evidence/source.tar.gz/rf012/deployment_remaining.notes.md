# Field-pilot-v2 deployment inventory and coverage reconciliation

Status: proposed minimum pilot gate and retained follow-up obligations, for independent review. This document does not authorize deployment, waive a contract, or report new hardware execution. The user approved DOC-001..DOC-006 on 2026-09-18, with DOC-006 replaced by retirement of the stale firmware roadmap after obligation reconciliation. DEC-002 was subsequently resolved on 2026-09-18: operator-managed test airtime and approved pilot deferral of DEP-007/reset-spanning firmware-ledger verification. DEC-001 is now approved with DOC-007 and DOC-008 deferred. DEC-005..DEC-008 are approved below. DEC-003 is approved for the documented pilot hardware/configuration; numerical uncertainty remains unmeasured and RF-018 physical measurement is deferred NOT RUN; approvals do not mark pending implementation/tests as passed. Stable DEP-001 through DEP-030 and decision IDs DEC-001 through DEC-008 must never be renumbered or reused.

Scope: one field-pilot-v2 node and its powered Pi receiver, communications/measurement collection before a custom PCB. Physical assembly implementation is excluded; fixture readiness, operator actions and verification after assembly are prerequisites. Custom PCB design, autonomous solar/battery operation and architectural wish lists do not automatically enter this gate.

The [RF catalogue](tests/rf/test_suite.notes.md) owns RF-001 through RF-031 and their exact scenarios. This inventory references those milestones without duplicating their procedures. Proposed classifications mean:

- **Blocks deployment:** required production behavior, configuration or selected evidence for this pilot remains incomplete.
- **Can follow deployment:** a specific retained obligation is proposed for later completion, with evidence, consequence and revisit condition. It is not passed or deleted.
- **Needs decision:** unresolved scope, design or evidence sufficiency; not counted as safe deferral. An applicable unresolved decision prevents gate closure.

## Source baseline and evidence applicability

Reconciliation date 2026-09-17. Production repository: branch receiver, commit ee55b737b0bc90e2a467814ddccc688a08c8a06a, initially clean tracked tree. Sibling logbook: commit e77f4b62d819f756288cc41b5dda570312ad26fa; its deployment README was unmodified, SHA256 86459139643b025caaf1b146a7ad8bc07595f32d4e58160b305d8ae3b99340c4. These identify the reviewed documents, not future deployed images.

All user-listed governing/procedural sources were present. The three requested deliverables were absent before this task; no prior RF/DEP IDs were replaced. The renamed .notes.md paths are ignored by .gitignore's *.notes.* rule; the workplan is separately ignored. No other workplan was read.

Authority:

- [Firmware architecture](firmware/ARCHITECTURE.md) and [interface including diagnostics](firmware/INTERFACE.md) define wake, storage, radio, sensors, identity and platform behavior.
- [Receiver architecture](receiver/ARCHITECTURE.md), [interface](receiver/INTERFACE.md) and [diagnostic interface](receiver/INTERFACE_DIAGNOSTIC.md) define runtime ownership, exact encodings and closed diagnostic catalogs.
- [Protocol README](protocol/protocol-v2-lora/README.md), [schema](protocol/protocol-v2-lora/schemas/protocol_v2_lora.json), [generated C header](firmware/components/protocol_v2_lora/include/protocol_v2_lora_schema_generated.h), [generated C implementation](firmware/components/protocol_v2_lora/protocol_v2_lora_schema_generated.c), [generated Python](receiver/cura_receiver/generated/protocol_v2_lora_generated.py), [reviewed vectors](protocol/protocol-v2-lora/test-vectors/golden_vectors.json) and [protocol test rules](protocol/protocol-v2-lora/tests/README.md) define interoperable/provisioned identity behavior; generated artifacts do not create policy.
- [Firmware testing](firmware/TESTING.md), [bare-C6 README](firmware/test_apps/on_device/README.md), [sensor carrier circuit](firmware/test_apps/on_device/SENSOR_CARRIER.md), [sensor procedures](firmware/test_apps/sensor_carrier/README.md), [sensor coverage](firmware/test_apps/sensor_carrier/COVERAGE.md), [receiver testing](receiver/TESTING.md), [support rules](receiver/tests/support/README.md), [Pi carrier](receiver/hardware/TEST_CARRIER.md), [DS3231 installation](receiver/hardware/ds3231/README.md), [operator tests](receiver/hardware/ds3231/OPERATOR_TESTS.md), [radio procedure](receiver/tests/hardware/RADIO_TESTS.md), [RTC faults](receiver/tests/hardware/RTC_FAULT_TESTS.md) and [radio coverage](receiver/tests/RADIO_COVERAGE.md) own coverage/procedure/evidence obligations.
- [Execution checklist](todo_list.notes.md) and [receiver sequencing](receiver/implementation_plan.notes) guide ordering only. The stale firmware roadmap was reconciled and removed under DOC-006. “Complete” is a lead, not proof. [Pilot deployment record](../cura-agrorum-logbook/deployments/field-pilot-v2/README.md) defines the specific field experiment.

Evidence identifiers below name existing records, not new pass claims:

| Evidence | Existing result and current applicability |
|---|---|
| E-SENSOR | [Sensor coverage/catalogue](firmware/test_apps/sensor_carrier/COVERAGE.md): all 26 linked original-file hashes verified locally. Historical nominal/missing sensor, ADC A/B, DS identity A/B, cleanup/reset/deep-sleep DC, BME mode and one 100-acquisition run. Duplicate repeat filenames are one run. Reading evidence's 168-path manifest has two changed test-app sources and 36 absent local paths (35 managed dependency files plus sdkconfig); current checkout is not a complete sealed-image match. Existing available production reading/sensor paths match. The September 17 hold-order and erase-warning changes have host/build evidence only; no current hardware run. A-only/incomplete and software-only outcomes retain their labels. |
| E-RADIO | [Curated Pi radio](receiver/tests/hardware/evidence/radio/README.md), [manifest](receiver/tests/hardware/evidence/radio/source-manifest.json), [coverage](receiver/tests/RADIO_COVERAGE.md): three nominal cases and restoration passed, no SetTx; held BUSY was observed but safe_shutdown=false aborted its session. Missing held/restored commands/exits remain missing. Current manifest comparison: 175 matching/14 changed/0 absent entries; changed production paths are platform/linux_radio.py, ports/radio.py, radio.py and sx1262.py. Later reset timing, release-failure preservation and stream resynchronization have host evidence only. Report says operator-declared Pi 3B+ while other target records identify Model B Rev 1.2; resolve actual deployment hardware under DEP-022. |
| E-AIR | [Airtime report](receiver/tests/hardware/evidence/tx_airtime/README.md) and [manifest](receiver/tests/hardware/evidence/tx_airtime/source-manifest.json): 17 Pi component cases, grant-lifetime samples, same-boot restart and both actual reboot modes. Source recoverable at 4779361ff04180d34f846ea8942c9387092cc8cc. Current comparison 301 matching/21 changed/5 absent entries; changed production dependencies include generated enums, Linux clocks, ingress and quarantine evidence. Linux clock diff adds bounded waiting rather than changing the existing clock read; do not invalidate the rate measurement merely for a file hash change, but qualify new radio scheduling. Fixture used root and 10,000-ppb network skew ceiling, not a production service-user/default-policy pass. No RF/physical power loss; deleted databases cannot be re-audited. |
| E-TIME | [Runtime report](receiver/tests/hardware/evidence/runtime_time/README.md): independently referenced positive/negative maximum slew, OSF/cold boot, four SCL/SDA read/write faults and nominal restoration. Slew manifest 250 matching/34 changed/2 absent; OSF 251/34/2; controller 179/35/0. Runtime time/observation/state paths changed, and later writer-audit/offline-startup/scheduling/step/uncertain-commit corrections lack Pi requalification. Original slew observations remain valid for their kernel/configuration; not full service or trusted-holdover proof. [Stock-driver limitation](receiver/hardware/ds3231/LIMITATION.md) preserves the qualified bounded-read recovery and deferred controller abort/NACK mechanism. |
| E-RTC | [RTC results](receiver/hardware/ds3231/results/README.md): September 12 RTC-01..05 passed; the later RTC-06 report completed September 14 and records functional retention PASS over about 37 h 42 min between reference samples. No resolved drift and no calibrated accuracy/holdover claim. Physical outage interval/action provenance is operator-reported, not exact independent power timing. Do not carry forward older RTC-06 NOT RUN labels as the latest result. |
| E-PERSIST | [Persistence report](receiver/tests/hardware/evidence/persistence_worker/README.md), [manifest](receiver/tests/hardware/evidence/persistence_worker/source-manifest.json): 29 Pi component cases, three storage-fault cases and a 30-second loaded soak. Current comparison 251 matching/72 changed/0 absent, including state/control/SQLite/ingress/generated paths. Original snapshot/crash databases were never retained here; do not claim reproducibility beyond retained source identity/results. No full-service or physical power-loss proof. |
| E-HOST | Source inspection finds implemented protocol generation/golden/crypto/property/sanitizer/fuzz tests; firmware native matrices; receiver queue/ingress/storage/worker/time/airtime/radio matrices. [Radio coverage](receiver/tests/RADIO_COVERAGE.md) records 3,229 receiver and 744 focused radio tests after later review fixes. Those are recorded outcomes, not reruns in this task. Test existence is not a current green result. DEP-011/DEP-003 require relevant final-tree validation. |
| E-BARE | [On-device app](firmware/test_apps/on_device/README.md) and actual [core cases](firmware/test_apps/on_device/main/test_node_core_on_device.c), [persistence cases](firmware/test_apps/on_device/main/test_node_persistence_on_device.c), [platform cases](firmware/test_apps/on_device/main/test_node_platform_esp_on_device.c): implemented real PSA/NVS/LittleFS/RTC/reset/sleep with fake sensors/radio for core. No source-bound retained bare-board execution archive is linked by that README; roadmap “done” alone does not close current-image verification. |
| E-CAL | Pilot record's ../../sensor_capacitive_soil_moisture/clones/soil_sensor_curve_fitting_experiment.md link is missing. A current candidate is [calibration experiment](../cura-agrorum-logbook/experiments/2026-08-soil-calibration-v1/README.md) and [analysis](../cura-agrorum-logbook/experiments/2026-08-soil-calibration-v1/analysis/REPORT.md), using DF16..DF20 and older pinned acquisition code. Its shared curve fails the stated 3-point maximum GWC error target; it does not identify the selected field pair/depths. Repair provenance and confirm selection, not “calibration done => field accuracy proven.” |

All receiver archive checksums and the existing offline radio, airtime and exact-rational slew verifiers passed during this documentation task. This checks retained artifacts only. Absent paths in older receiver manifests are curated/renamed evidence reports/manifests, not absent production implementation; the replacement curated topic reports above describe what survives. No missing source or deleted original is reconstructed. No target connection, hardware test, flash, RF emission or production test-suite run occurred.

<a id="dep-001"></a>

## DEP-001 — Receiver communicator composition

- **Requirement/current source:** [communicator](receiver/ARCHITECTURE.md#communicator-thread), [critical flow](receiver/ARCHITECTURE.md#critical-receive-to-ack-flow), [ingress lifecycle](receiver/INTERFACE.md#protocol-ingress-lifecycle); existing [ingress](receiver/cura_receiver/protocol_ingress.py), [radio](receiver/cura_receiver/radio.py), [time](receiver/cura_receiver/runtime_time.py), [airtime](receiver/cura_receiver/tx_airtime.py), [complete-state owner](receiver/cura_receiver/communicator_state_owner.py), [worker](receiver/cura_receiver/persistence_worker.py).
- **Implementation:** components present; production communicator/event loop absent. **Verification:** component host/historical Pi only.
- **Remaining/evidence:** compose single owners; prioritize radio deadlines over health, precharge outside ACK path, no disk/network/ordinary-persistence wait on that path; preserve atomic admission, terminal immutable publication, immediate new events, time-boundary FIFO and shutdown intent. Require complete host flow and RF-020..RF-029 selected acceptance evidence.
- **Dependencies/actor:** component contracts and DEP-003/DEP-006/DEP-010; agent.
- **Classification:** **Blocks deployment.** No complete receiver exists without this; component peer cannot substitute.

<a id="dep-002"></a>

## DEP-002 — Required observability and diagnostics

- **Requirement/current source:** [telemetry](receiver/ARCHITECTURE.md#telemetry), [diagnostics](receiver/ARCHITECTURE.md#diagnostics), [closed catalogue](receiver/INTERFACE_DIAGNOSTIC.md); [radio factory](receiver/cura_receiver/radio_diagnostics.py), [time factory](receiver/cura_receiver/time_diagnostics.py), generated entities and persistence enrichment already exist.
- **Implementation:** radio/time contexts and persistence projections implemented; communicator identity allocation, health producer and persistence-control/CORE construction/admission absent. **Verification:** component codec/episode coverage only.
- **Remaining/evidence:** exact T0..T6 presence/order, copied frames, one-minute plus initialization health, per-instance sequences/admission matrix, radio/time/control counters and two sampling times; all defined 64/80-byte contexts, cross-domain root selection, one episode per trigger, no recursion and best-effort loss semantics. Full host tests must show profile publication survives later diagnostic-admission failure and UNKNOWN_INTERRUPTED is finalized only when safe.
- **Dependencies/actor:** DEP-001/DEP-003; agent.
- **Classification:** **Blocks deployment.** Pilot link/fault diagnosis requires these authoritative records; optional durable outage fallback is DEP-026.

<a id="dep-003"></a>

## DEP-003 — Complete application host coverage

- **Requirement/current source:** [receiver testing](receiver/TESTING.md#end-to-end-receiver-behavior), concurrency/protocol ingress/lifecycle sections and every diagnostic “Required ... tests” section; current receiver/tests/host contains component tests, not a complete service test.
- **Implementation:** extensive component/model/real SQLite tests exist; integration cases await DEP-001/DEP-002/DEP-004/DEP-005. **Verification:** E-HOST, not current integrated acceptance.
- **Remaining/evidence:** deterministic full valid/duplicate/lost/failed ACK, current/backlog, storage/admission, grants/uncertainty, time boundaries, poison/FIFO/control scheduling, clean/crash lifecycle and top-level failures. Retain all normative distinct host assertions, reviewed independent models and true production composition; no surrogate communicator in tests. Run generators, protocol and affected host suites on final source.
- **Dependencies/actor:** grows with owning implementation rather than one late monolithic harness; agent.
- **Classification:** **Blocks deployment.** Deterministic integration closes otherwise untested ownership boundaries without requiring all future physical instruments.

<a id="dep-004"></a>

## DEP-004 — Process entry point, boot service and RTC bootstrap

- **Requirement/current source:** [deployment lifecycle](receiver/ARCHITECTURE.md#deployment-lifecycle), [lifecycle tests](receiver/TESTING.md#deployment-and-lifecycle); [startup](receiver/cura_receiver/receiver_startup.py) currently handles configuration/database/durable instance start only. No packaged complete receiver entry point/unit/bootstrap was found.
- **Implementation:** partial startup primitives; service/composition/bootstrap absent. **Verification:** component lifecycle rows do not establish systemd behavior.
- **Remaining/evidence:** enable at boot after required mounts and bounded RTC-bootstrap completion, exactly once per Linux boot; permit bootstrap failure/untrusted offline startup; prevent late bootstrap overwrite of synchronized time. No network-online dependency. Service UID, delayed/rate-limited restart, stop timeout and suspend prevention. Record exact paths/timeouts/permissions; host static/startup tests and actual isolated Pi boot/offline/missing-device/restart checks.
- **Dependencies/actor:** DEP-001/DEP-006/DEP-010; both.
- **Classification:** **Blocks deployment.** Unattended service semantics are explicitly first-pilot requirements.

<a id="dep-005"></a>

## DEP-005 — Controlled stop and restart correctness

- **Requirement/current source:** [controlled shutdown](receiver/ARCHITECTURE.md#controlled-shutdown), [clean-stop contract](receiver/INTERFACE.md#receiver-clean-stop-control), [worker](receiver/cura_receiver/persistence_worker.py) and [control operations](receiver/cura_receiver/persistence_control_operations.py).
- **Implementation:** lower worker/control clean-stop machinery exists; top-level ordered lifecycle missing. **Verification:** host/Pi component process kills, not full service/reboot.
- **Remaining/evidence:** inhibit TX, confirm radio safety, settle state, bounded drain, exact idempotent clean marker, checkpoint/close; no false marker on unmet prerequisites, exact reconciliation after unknown commit. Preserve marker meaning if later checkpoint/close fails. Kill without hooks at lifecycle boundaries; RF-027/RF-028 prove real identities/recovery.
- **Dependencies/actor:** DEP-001/DEP-004; both.
- **Classification:** **Blocks deployment.** Correctness cannot depend on graceful shutdown.

<a id="dep-006"></a>

## DEP-006 — Production time configuration and privilege installation

- **Requirement/current source:** [Chrony contract](receiver/ARCHITECTURE.md#chrony-integration), [Linux RTC boundary](receiver/INTERFACE.md#pilot-linux-backend-and-privilege-boundary), [installation guide](receiver/hardware/ds3231/README.md); [Chrony validator](receiver/tools/check_chrony.py) and time adapters exist.
- **Implementation:** adapters and validation present; installed final service-user permissions/native helper/device alias and boot integration not established by local sources. **Verification:** E-TIME/E-RTC; historical root tests do not qualify receiver UID.
- **Remaining/evidence:** choose reviewed TimePolicy values, including network-skew and RTC drift bounds; do not promote the E-AIR 10,000-ppb bench setting silently. Validate actual Chrony ExecStartPre/ExecStart and MainPID arguments, 3500-ppm slew/3700-ppm elapsed bound, no automatic step/RTC writer/competing service, local socket only. Receiver has no CAP_SYS_TIME; bounded fixed helper/RTC permissions, no arbitrary commands, trusted config ownership.
- **Dependencies/actor:** DEP-004/DEP-010/DEP-014 and operator installed-kernel selection; both.
- **Classification:** **Blocks deployment.** Incorrect time ownership invalidates timestamp and airtime assumptions. Historical beta-kernel version is evidence, not a permanent package recommendation.

<a id="dep-007"></a>

## DEP-007 — Firmware durable airtime across resets

- **Requirement/current source:** [continuous-hour duty cycle](firmware/ARCHITECTURE.md#continuous-hour-duty-cycle-accounting), [node_core.c](firmware/components/node_core/node_core.c) initializes cycle metrics to zero and charges after returned tx_started; [core constants](firmware/components/node_core/include/node_core.h) retain 8 s and 900 s.
- **Implementation:** reset-spanning production ledger absent; existing 8-second per-wake guard and 900-second sleep remain unchanged. **Verification:** operator reports 30 days of prior testing as the basis for accepting this pilot heuristic. No source/configuration-bound report or reset history was supplied with that decision; this is not proof of rolling-hour enforcement across resets.
- **Remaining/evidence:** retained future work: choose the smallest justified reset-spanning design when resumed, with durable per-band reservations before SetTx, conservative elapsed time, unknown-state exhaustion and uncertain-TX retention. Keep 8 s/30 s guards. Then qualify the independent host model, storage/reset boundaries, target persistence and deferred firmware-ledger RF-029 assertions; decide any associated physical proof under DEC-006. No dedicated allowance-owner design is selected now.
- **Dependencies/actor:** future resumption/design decision, firmware persistence/time boundaries and applicable DEP-011 evidence; agent implementation, both verification.
- **Classification:** **Can follow deployment — explicitly approved under DEC-002 on 2026-09-18.** Reason: operator accepts the existing heuristic for this limited pilot based on the reported 30-day experience. Consequence: repeated resets can replenish the per-wake budget; reset-safe hourly enforcement remains absent. Revisit on repeated/unexpected resets, changed cadence/retry budgets, an independent-enforcement requirement or resumed ledger work. Manual test accounting does not close this deferred production obligation.

<a id="dep-008"></a>

## DEP-008 — Final production firmware build and board configuration

- **Requirement/current source:** [app_main](firmware/main/app_main.c), [defaults](firmware/sdkconfig.defaults), [radio Kconfig](firmware/components/sx1262_radio/Kconfig), [sensor Kconfig](firmware/components/node_sensors/Kconfig), [fixture pins](firmware/INTERFACE.md#selected-radio-fixture-pins).
- **Implementation:** production composition exists; checked-in defaults are not the approved assembled fixture. Radio MISO/CS defaults 10/11 versus 14/23; sensor SDA/SCL defaults 4/5 versus 21/22; both DS ROM defaults are zero. **Verification:** no final pilot build/config/source identity established.
- **Remaining/evidence:** explicit reproducible pilot configuration, selected logical ROM/channel mapping, real dependency pins and clean build, partition/flash identity, unchanged PHY/cadence, real platform cleanup/crypto/persistence. Validate resolved configuration, not only defaults. Missing private identity headers block provisioning/build; never fabricate credentials or replace app_main to bypass that prerequisite. Capture ELF/binary/config/source hashes without private header bytes; RF-020 with the configured production image under the approved DEC-002 heuristic; DEP-007 implementation is deferred.
- **Dependencies/actor:** DEP-009/DEP-012/DEP-022 and the approved DEC-002 disposition; both.
- **Classification:** **Blocks deployment.** A successful sensor test image is not a configured production image.

<a id="dep-009"></a>

## DEP-009 — Test and production identity provisioning

- **Requirement/current source:** [keys, revocation and replacement](protocol/protocol-v2-lora/README.md#keys-and-provisioning), [provision tools](protocol/protocol-v2-lora/tools/provision_node.py), [strict group loader](protocol/protocol-v2-lora/python/cura_protocol_v2_lora/receiver_group.py), [destructive test storage](firmware/test_apps/sensor_carrier/README.md#destructive-test-storage).
- **Implementation:** tools/loader/counter logic implemented; no reviewed deployment identity lifecycle/configuration record supplied. **Verification:** protocol/host tests and isolated firmware tests; live credentials were not read.
- **Remaining/evidence:** stage dedicated test groups/identities and separate production provisioning, UID/0600/no-symlink parent checks, public-ID allowlist/group binding/revocation, receiver restart on changes. Preserve counters on normal rebuild; replacement uses new ID/key and full NVS/LittleFS/RTC reset before TX, no old backlog migration. Record public IDs and operation outcomes only. Verify lost/exhausted/erased counter procedure never resumes a live identity.
- **Dependencies/actor:** DEP-008/DEP-010/DEP-024; both, operator owns identity transition.
- **Classification:** **Blocks deployment.** Automatic recovery is explicitly deferred DEP-025; safe manual provisioning is mandatory.

<a id="dep-010"></a>

## DEP-010 — Receiver package, configuration and storage deployment

- **Requirement/current source:** [configuration](receiver/ARCHITECTURE.md#receiver-configuration), [SQLite contract](receiver/INTERFACE.md#sqlite-schema-contract), [database operations](receiver/db/README.md), [initializer](receiver/cura_receiver/database_initializer.py), generated [schema](receiver/db/schema.sql) and [schema manifest](receiver/schemas/receiver_entities.json).
- **Implementation:** runtime package/components and offline initializer present; install/composition and final parameter set missing. **Verification:** host/historical Pi per E-PERSIST.
- **Remaining/evidence:** stage/package current receiver plus protocol-owned Python loader and required schema/dependencies; no repository-local or tests dependency in production. Fresh offline database with exact generated version/fingerprint/group; archive incompatible old epoch, never silently migrate. Validate all required mounts/temporary SQLite paths, WAL/FULL/foreign keys/busy timeout, preventive free-space threshold, queue 500, worker flush/checkpoint policy, exact radio/time configuration and capacity for bench+field collection. Test read-only/missing/wrong-group/schema rejection and operator backup/restore boundary.
- **Dependencies/actor:** DEP-004/DEP-009/DEP-015; both.
- **Classification:** **Blocks deployment.** Correct libraries alone do not establish a writable, correctly bound deployed instance.

<a id="dep-011"></a>

## DEP-011 — Current host/protocol and bare-C6 baseline evidence

- **Requirement/current source:** [firmware testing](firmware/TESTING.md), [bare-C6 app](firmware/test_apps/on_device/README.md), [protocol test contract](protocol/protocol-v2-lora/tests/README.md); source matrices include core/persistence/sensors/radio/platform and generated C/Python/crypto/provisioning.
- **Implementation:** existing baseline tests present; current integration regressions still needed; new ledger regressions follow deferred DEP-007. **Verification:** E-HOST/E-BARE, no rerun here.
- **Remaining/evidence:** final-tree generator freshness, reviewed golden/crypto/interoperability, structural/provisioning/property/sanitizer/fuzz baseline; affected firmware native matrices and actual bare-C6 PSA/counter/restart/RTC/persistence/platform cases with provenance. Include counter committed-success/exhaustion/independence, binding exactness, tails/quotas/compaction and finalization. Recover an attributable existing target record if available; otherwise requalify affected cases. Preserve bare-C6 Make target semantics; no blanket retest of unchanged unrelated physical suites.
- **Dependencies/actor:** current source/toolchain/build identity; agent host checks, both target checks.
- **Classification:** **Blocks deployment for relevant regression/current identity evidence.** Optional extra fuzz time or duplicated stress does not automatically gate deployment; listed deterministic obligations remain visible in coverage.

<a id="dep-012"></a>

## DEP-012 — Sensor applicability and assembled-node verification

- **Requirement/current source:** [sensor coverage](firmware/test_apps/sensor_carrier/COVERAGE.md), [procedures](firmware/test_apps/sensor_carrier/README.md), [carrier](firmware/test_apps/on_device/SENSOR_CARRIER.md), production sensor/core files named there.
- **Implementation:** all listed component/mapping cases implemented, including later test-order correction. **Verification:** E-SENSOR historical, no current changed-image hardware result.
- **Remaining/evidence:** seal current dependencies/configuration, review source deltas, confirm selected ROMs/ADC mapping/R12/pull-up arrangement and nominal acquisition/reading/final cleanup on final assembly. Reuse unchanged, source-supported missing-DS/BME/ADC/identity claims with explicit scope; rerun if relevant source/circuit/probe changed. Changed hold-order branch needs its focused regression/current procedure check, not relabelled old electrical evidence. Missing local managed files/sdkconfig prevent asserting a complete historical build match.
- **Dependencies/actor:** DEP-008/DEP-022; both, operator owns multimeter and rewiring.
- **Classification:** **Blocks deployment for final nominal readiness and evidence applicability.** Repetition of every unchanged manual fixture is not an unconditional gate. RF-020 validates actual sensor-to-receiver integration.

<a id="dep-013"></a>

## DEP-013 — Current Pi radio component qualification

- **Requirement/current source:** [radio coverage](receiver/tests/RADIO_COVERAGE.md), [Pi procedure](receiver/tests/hardware/RADIO_TESTS.md), production radio/port/backend/Linux adapter.
- **Implementation:** production stack and three nominal non-TX cases present; revised reset/lifecycle/event-stream paths implemented. **Verification:** E-RADIO predates those fixes.
- **Remaining/evidence:** requalify nominal device/permissions, initialization/profile readback, real timeout/rearm and safe teardown on current staged source as actual receiver UID. Retain source/fixture/kernel/command/exits. Host composed adapter/owner tests establish fault logic; RF-001/RF-008 establish peer TX/RX. Physical gated recovery and independent timing remain RF-016/RF-017.
- **Dependencies/actor:** DEP-022/DEP-024 and exclusive devices; both.
- **Classification:** **Blocks deployment and first component RF.** Reusing old nominal evidence unqualified would conceal changes to exercised paths.

<a id="dep-014"></a>

## DEP-014 — Current runtime time and offline-service verification

- **Requirement/current source:** [time tests](receiver/TESTING.md#time-policy-and-timestamp-analysis), [runtime_time](receiver/cura_receiver/runtime_time.py), [time observations](receiver/cura_receiver/time_observations.py), [RTC faults](receiver/tests/hardware/RTC_FAULT_TESTS.md), E-TIME/E-RTC.
- **Implementation:** policy/adapters/fault tests present; service integration missing and later fixes only host-validated. **Verification:** historical functional/physical evidence, not current full runtime.
- **Remaining/evidence:** affected Pi real Chrony/adjtimex/RTC read/write/provenance, online/offline/unproven startup, writer audit and forward/back step boundary tests; verify old provenance invalidated before write, unknown result not retried blindly, bounded read recovery/INVALID handling, trust expiry and scheduling. Reuse independent maximum-slew and RTC retention evidence only after kernel/config/source applicability review; rerun if those assumptions change. RF-026/RF-028 close service/RF scope.
- **Dependencies/actor:** DEP-004/DEP-006, separate declared destructive/time fixtures; both.
- **Classification:** **Blocks deployment for changed runtime/deployment paths.** Do not automatically repeat all original long/manual captures, and do not treat RTC-06 as calibration.

<a id="dep-015"></a>

## DEP-015 — Current persistence, state and recovery qualification

- **Requirement/current source:** [persistence tests](receiver/TESTING.md#persistence), [state/grants](receiver/TESTING.md#receiver-tx-airtime-policy), actual SQLite/worker/control/state implementations and E-PERSIST/E-AIR.
- **Implementation:** components and host/target cases present. **Verification:** current changes to dependencies beyond retained Pi snapshots.
- **Remaining/evidence:** trace actual changed paths and qualify final schema/projections, new ACK outcome preservation, exact commit reconciliation, durable generations, queue ownership, poison boundaries, shared recovery and grant spending/settlement. Current Pi safe component/permission and affected isolated storage faults; real SQLite, not mocks. Loaded grant baseline never spendable. Reuse unaffected sample/measurement evidence only with explicit source reasoning; RF-025/RF-027..RF-029 close radio/service consequences.
- **Dependencies/actor:** DEP-010/DEP-003, final storage/kernel stack; both.
- **Classification:** **Blocks deployment for affected paths.** Retained FULL/NORMAL benchmarks are characterization, not a demand to benchmark again or permission to use NORMAL.

<a id="dep-016"></a>

## DEP-016 — Independent radio instrumentation and extended faults

- **Requirement/current source:** firmware/receiver hardware timing and fault sections; E-RADIO/E-SENSOR limitations; RF-014..RF-017 own scenarios.
- **Implementation:** host faults and some guarded Pi cases exist; independent instrumented capture/extra C6 fixture absent. **Verification:** no waveform/edge accuracy or physical runtime recovery pass.
- **Remaining/evidence:** approved mechanisms/instruments/uncertainty and source-bound RF-014/RF-016/RF-017 results; retain RF-015's historical abort separately.
- **Dependencies/actor:** actual available fixture/instrument and reviewed procedure, both.
- **Classification:** **Can follow deployment under DEC-001.** Functional IRQ/transition/cleanup and current host recovery remain gated. Consequence: electrical fault/timestamp margins unqualified. Revisit on equipment availability, changed timing stack, any related observed fault or review finding; cannot use this deferral to excuse a failing nominal test.

<a id="dep-017"></a>

## DEP-017 — Physical supply-interruption durability qualification

- **Requirement/current source:** [firmware deferred hardware](firmware/TESTING.md#deferred-or-unresolved-hardware-test-details), persistence restart contracts, receiver WAL/FULL assumptions, E-PERSIST/E-AIR explicitly exclude physical power loss.
- **Implementation:** software-reset, process-kill, storage corruption/tail and commit-boundary tests exist; external all-supply/back-power isolation rig absent. **Verification:** no physical interruption proof for either storage stack.
- **Remaining/evidence:** Approved DEC-006 accepts documented guarantees plus applicable existing fault tests and new reset/commit-boundary tests for this pilot; execute the new tests and retain their results. New node-ledger-specific physical proof follows deferred DEP-007 when that work resumes. Retain two obligations: C6 NVS/LittleFS/ledger interruption at durable reservation/binding/compaction; Pi SD/WAL/state interruption with preserved database/WAL/SHM and conservative restart. Design the external fixture, timing/observation and acceptance before implementation, no invented switch. Verify all supply/back-power isolation and actual rail disappearance; cover in-progress and acknowledged-success boundaries without erasing state between cut and recovery. A missed cut window is not a pass. Retain cut/restore and raw storage evidence, then restore the fixture and rerun affected nominal checks.
- **Dependencies/actor:** actual power fixture, disposable identities and operator destructive authority; DEP-007 design only for the future node-ledger parameter; both.
- **Classification:** **Approved deferred under DEC-006.** Physical interruption proof remains NOT RUN. Existing applicable fault evidence and new reset/commit-boundary tests support the pilot; physical campaigns resume with suitable fixtures, later qualification scope or observed storage/TX recovery failures.

<a id="dep-018"></a>

## DEP-018 — RF readiness milestone

- **Requirement/current source:** [RF catalogue](tests/rf/test_suite.notes.md), firmware/receiver RF sections, current absence of joint apps/peer/orchestration.
- **Implementation:** underlying radios exist; joint suites and complete acceptance absent. **Verification:** no retained RF result.
- **Remaining/evidence:** implement reviewed minimal cases with explicit fixture/selection guards, independent expectations, source manifests, operator-owned per-transmitter airtime records and separation from production enforcement. The first-phase harness declares bounded episodes and waits for operator readiness; automated cross-run accounting/scheduling is not required. Proposed gate set and dependencies are below; component results stay separate from full service acceptance.
- **Dependencies/actor:** DEP-013/DEP-023 for early nominal; DEP-001..DEP-006 and DEP-008..DEP-015 applicable blockers for production acceptance (DEP-007 is approved deferred); both.
- **Classification:** **Blocks deployment.** Deferral of other IDs does not weaken any required assertion of a selected case.

<a id="dep-019"></a>

## DEP-019 — Bench outage/recovery soak and acceptance criteria

- **Requirement/current source:** [pilot record](../cura-agrorum-logbook/deployments/field-pilot-v2/README.md#work-before-the-custom-pcb), receiver end-to-end testing; RF-030 owns the test.
- **Implementation:** full soak absent; persistence's 30-second load test is a different layer. **Verification:** no full node/service soak.
- **Remaining/evidence:** DEC-005 predeclares minimum 24-hour bench duration, legal normal-cadence/current-backlog mix, offline/time-disruption and bounded fault/recovery phases, reconciliation and stop criteria. Fix misleading power-bank-auto-off requirement for selected LiFePO4 supply while still verifying actual supply continuity. Define permitted observation gaps/link success targets if required by pilot owner; never select pass thresholds after results.
- **Dependencies/actor:** selected RF blockers, DEP-022/DEP-024; both.
- **Classification:** **Blocks deployment.** Use the approved 24-hour bench duration; the field week is DEP-020, not a prerequisite to start deployment.

<a id="dep-020"></a>

## DEP-020 — Field commissioning and at least one week of collection

- **Requirement/current source:** [pilot goals/progression](../cura-agrorum-logbook/deployments/field-pilot-v2/README.md), RF-030 field phase.
- **Implementation:** operational experiment not executed by this task. **Verification:** no v2 field evidence inspected.
- **Remaining/evidence:** at installation verify intended enclosure/antenna positions, actual power/fixture configuration, one nominal accepted/persisted sample and source/public identity; collect at least one week, link/retry/RSSI/SNR/weather context, channel labels, actual placement/depths if used and maintenance episodes; document the chosen setup in the logbook after deployment under DEC-008. Weak/obstructed-location repetition is conditional on insufficient margin, not automatically a predeployment campaign. Keep bench air-exposed soil-probe voltage assertions separate from an explicitly documented field configuration for probes in soil; field operation must not silently weaken the bench limits.
- **Dependencies/actor:** approved minimum gate, DEP-022/DEP-024/DEP-030; operator with agent evidence support.
- **Classification:** **Can follow deployment; commissioning checks occur at deployment.** Field results cannot precede installation. Revisit throughout week, after location changes and immediately on stop-condition breach; pilot completion is distinct from permission to deploy.

<a id="dep-021"></a>

## DEP-021 — Offline retention versus later forwarding

- **Requirement/current source:** approved DEC-004 and [root README](README.md): no Internet access; readings/files remain on the Pi. [Communicator responsibilities](receiver/ARCHITECTURE.md#responsibilities) continue to prohibit network requests. The stale Wi-Fi v1 server has been removed.
- **Implementation:** local SQLite retention and timestamp analysis components exist; no uploader is required. **Verification:** final local-retention/recovery evidence remains due; removal of legacy code is not a test PASS.
- **Remaining/evidence:** verify durable local collection, offline startup/operation, readable retained records and existing capacity/retention/recovery controls on the Pi. Consistent local snapshots can support acceptance/analysis; off-Pi export is not a pilot gate. Retain future forwarding design and outage/backfill/security/retry/idempotence verification only if automatic transfer is requested later.
- **Dependencies/actor:** approved DEC-004, DEP-010/DEP-024; both.
- **Classification:** **Blocks deployment for local-retention verification only; automatic forwarding can follow deployment if future scope requires it.** Revisit forwarding when Internet/destination requirements change; define ownership and acceptance before implementation.

<a id="dep-022"></a>

## DEP-022 — Final pilot metadata, fixture and power readiness

- **Requirement/current source:** [pilot selected design/open decisions](../cura-agrorum-logbook/deployments/field-pilot-v2/README.md), both carrier documents, E-CAL/E-SENSOR/E-RADIO.
- **Implementation:** assembly is external; production metadata/configuration selection remains incomplete. **Verification:** historical circuit observations do not establish present wiring or supply.
- **Remaining/evidence:** operator chooses the quickest supported working assembly, including actual Pi, radio/antenna chains and power sources. Resolve wiring and ROM/channel inputs used by the build; exact sensor pair/depths are flexible. Record actual placement, detailed metadata and calibration provenance/limits in the logbook after deployment; no calibrated-moisture claim is made. Verify ready assembled fixture/power under actual load and final nominal checks; no invented instruments/tolerances.
- **Dependencies/actor:** DEC-008 and selected hardware; operator, agent records.
- **Classification:** **Configuration policy approved under DEC-008; actual assembly readiness blocks deployment.** Measurement calibration perfection/custom-PCB selection is not required for raw-mV pilot collection, but false calibrated-moisture claims and unknown power source are unacceptable.

<a id="dep-023"></a>

## DEP-023 — Approved RF operating envelope

- **Requirement/current source:** [firmware first RF envelope](firmware/TESTING.md#sx1262_radio-first-rf-operating-envelope), protocol PHY; RF-018 and DEC-003.
- **Implementation/evidence accepted 2026-09-18:** the documented firmware and receiver schematics, configured +14 dBm/pilot PHY, existing source-based antenna/power estimate and the operator's stated trust in the SX1262 configuration. The [retained approval](tests/rf/evidence/2026-09-18-envelope/README.md) identifies the exact source basis. No new numerical uncertainty bound or physical measurement is claimed.
- **Allowed operation:** declared component episodes and autonomous wakes, retries and resets with the documented hardware/configuration and existing protocol/DEC-002 policies. Operator-owned per-transmitter test records/admission/pacing and receiver production enforcement remain unchanged; no automated harness ledger/scheduler is required.
- **Remaining/evidence:** RF-018 physical power/carrier/emissions measurement is deferred **NOT RUN**. Revisit on suitable instrument availability, changed module/antenna/path/power/PHY, or conflicting RF evidence. This records pilot acceptance, not a fresh regulatory-compliance determination or full-service/deployment acceptance.
- **Dependencies/actor:** operator approval and DEC-003 recorded; both.
- **Classification:** **Approved operating envelope for the documented pilot configuration.** Aggregate deployment acceptance and every required test retain their separate gates.

<a id="dep-024"></a>

## DEP-024 — Operator deployment, monitoring and recovery runbook

- **Requirement/current source:** [service lifecycle](receiver/ARCHITECTURE.md#deployment-lifecycle), [operator restoration](receiver/db/README.md#last-resort-operator-restoration), P-ID, physical fixture procedures.
- **Implementation:** component procedures exist; complete pilot installation/handover/runbook absent. **Verification:** no complete operational rehearsal.
- **Remaining/evidence:** reproducible install/start/stop, source/public identity/config inventory, stable UART/RTC/SPI selection, separate test/live roots, exclusive device ownership, local backup/snapshot retention, storage capacity/health checks and operator check cadence. Escalate invalid RTC, full/corrupt node logs, missing radio, recurring recovery or uncertain TX; preserve evidence, stop/reprovision when required, never erase live counters or auto-restore stale database. Rehearse stop/preserve/restore/new-instance steps on isolated data and confirm final rollback/restoration.
- **Dependencies/actor:** DEP-004..DEP-010, DEP-021/DEP-022 decisions; both.
- **Classification:** **Blocks deployment.** This is the minimum operational response; automated health-management enhancements remain deferred.

<a id="dep-025"></a>

## DEP-025 — Automatic node counter recovery

- **Requirement/current source:** [known pilot limitation](protocol/protocol-v2-lora/README.md#known-pilot-limitation-and-deferred-counter-recovery) and firmware persistence boundaries.
- **Implementation:** intentionally absent; missing NVS key is treated as fresh provisioning. **Verification:** current tests establish monotonic normal claims, not erased-state detection.
- **Remaining/evidence:** coordinated protocol/node/receiver revision with fresh challenge, durable never-reused epoch or disjoint ranges for both IDs, nonce-safe retries and fail-closed allocation recovery.
- **Dependencies/actor:** explicit future protocol decision; agent implementation, operator rollout.
- **Classification:** **Can follow deployment, already contract-deferred.** Consequence: any counter loss/rollback requires new identity/key and destructive node-state reset, never “greatest received ID” recovery. Revisit when unattended counter recovery becomes required or repeated physical corruption occurs.

<a id="dep-026"></a>

## DEP-026 — Stronger durability and diagnostic guarantees

- **Requirement/current source:** [receiver deferred work](receiver/ARCHITECTURE.md#deferred-work), firmware [RTC-state lifecycle](firmware/ARCHITECTURE.md#rtc-state-lifecycle).
- **Implementation:** intentionally absent stronger features; existing conservative pilot behavior implemented in components.
- **Verification:** no claim of durable-before-ACK, durable outage diagnostics or CRC-protected RTC metrics.
- **Remaining/evidence:** retain distinct follow-ups: (a) durable queue/journal before ACK; (b) durable structured fallback during persistence outage; (c) deterministic-encoding RTC CRC; (d) automatic watchdog/health-management beyond supervisor. Each needs its own requirements/design/tests before adoption; no shared test result closes all four.
- **Dependencies/actor:** future scope/design approval; agent, operator migration as needed.
- **Classification:** **Can follow deployment, explicit existing limitations.** Accepted ACK may be lost before commit; outage facts and semantically valid RTC bit errors may be unobservable. Revisit if those losses become unacceptable, pilot evidence exposes them, or unattended service needs exceed supervisor coverage.

<a id="dep-027"></a>

## DEP-027 — Sensor waveforms, state-energy measurements and future power budget

- **Requirement/current source:** [pilot goals/work before PCB](../cura-agrorum-logbook/deployments/field-pilot-v2/README.md); sensor/radio instrumentation limits.
- **Implementation:** measurement campaign absent here. **Verification:** DC rail and BME mode results are not current/energy evidence.
- **Remaining/evidence:** characterize C6 J5, radio and sensors separately with actual suitable current/time instruments, include regulator/path contributions and field retry distribution, then derive six-month budget with uncertainty. Retain the distinct sensor electrical waveform branch: settling/shutdown, reset/deep-sleep glitches and bus waveforms, with actual probe locations, characterized timebase/uncertainty and component-derived acceptance. Specify/review the procedure, verify the real fixture, implement only supported cases, retain raw traces/settings and restore/recheck nominal. DC/mode observations do not close waveform or low-current claims.
- **Dependencies/actor:** real instruments and final assembly for measurements; DEP-020 retry data for the derived energy budget, not for starting sensor waveform measurements; operator measurements, agent implementation/analysis.
- **Classification:** **Can follow deployment.** Sensor waveform/low-current claims remain unqualified; revisit on suitable equipment, related electrical faults or circuit/timing changes. Pilot explicitly is not an autonomy test; temporary-power continuity remains DEP-022/DEP-019. Revisit before battery/solar/custom-PCB power choices; those designs themselves are outside this inventory's implementation scope.

<a id="dep-028"></a>

## DEP-028 — Dedicated runner automation

- **Requirement/current source:** [firmware deferred hardware details](firmware/TESTING.md#deferred-or-unresolved-hardware-test-details), support local-helper rule.
- **Implementation:** dedicated port assignment/scheduling absent by design. **Verification:** no unattended-runner reliability evidence.
- **Remaining/evidence:** when a real runner exists, configure persistent DUT identities/ports, exclusive access, declared fixtures, fail-fast selection and across-job airtime/identity preservation; automate only actions the fixture physically supports. Document interrupted-run recovery and artifact retention; execute an ordinary job plus an explicitly selected slow job on the actual runner, inspect both artifacts and prove unavailable/mismatched fixtures fail rather than producing a green empty run.
- **Dependencies/actor:** actual dedicated runner/scheduling need; both.
- **Classification:** **Can follow deployment.** Manual declared runs suffice now; automatic slow/destructive/RF reruns risk violating current assumptions. Revisit when a second real use or dedicated runner justifies shared helpers/automation.

<a id="dep-029"></a>

## DEP-029 — Future node log maintenance/recovery design

- **Requirement/current source:** [open persistence decisions](firmware/INTERFACE.md#open-persistence-interface-decisions), [retention](firmware/ARCHITECTURE.md#retention-and-compaction); existing node persistence methods/tests.
- **Implementation:** bounded pending-pressure compaction and full-log rejection/preservation behavior implemented; reclamation of full non-pending logs and unprovable-tail physical repair intentionally undefined.
- **Verification:** host and implemented on-device injected-tail/quota tests; no arbitrary physical corruption recovery guarantee.
- **Remaining/evidence:** maintain diagnostic/quarantine/delivery quota monitoring and operator stop/preserve/reprovision boundary in DEP-024; later define any repair/reclamation with identity-safe migration and independent corruption/power-loss tests.
- **Dependencies/actor:** observed need or explicit recovery design; both.
- **Classification:** **Can follow deployment for new recovery algorithms.** Full best-effort logs can stop retaining diagnostics while sensing continues; preserve bytes and do not autoformat. Revisit on quota forecast, corrupt unprovable tail or a reliability requirement change.

<a id="dep-030"></a>

## DEP-030 — Pilot analysis and reporting

- **Requirement/current source:** pilot reception/retry/RSSI/SNR goals, [logical timestamps](receiver/cura_receiver/logical_timestamps.py), [clock correlation](receiver/cura_receiver/clock_correlation.py), protocol timestamp/log contracts.
- **Implementation:** pure correlation/anchor analysis functions exist; completed pilot report/export analysis absent. **Verification:** host model/anchor tests, no field dataset.
- **Remaining/evidence:** reproducible nonmutating analysis of source-bound SQLite/node observations, distinct transport/sample identities, attempted/received/accepted/durable counts, retry and latency distributions, link positions and uncertainty, allowed missing UTC and lost volatile records. DEP-019 still needs minimal reconciliation checks before declaring bench pass; detailed field analysis follows data collection.
- **Dependencies/actor:** DEP-019/DEP-020 and approved DEC-004 local-storage scope; agent with operator field context.
- **Classification:** **Can follow deployment for final reporting.** Raw records/configuration must already be captured; postpone analysis, not data retention. Revisit during field week, before pilot-completion review and before power/link-design decisions.

## Decisions awaiting review

Creation of this document did not approve these decisions. DEC-002 is now explicitly approved as recorded below; other decisions retain their unresolved status. Keep the selected resolution and its evidence with the final pilot record. Any changed behavior/encoding/timing/identity rule requires its own explicit contract decision.

| ID | Choice, recommendation and unresolved acceptance |
|---|---|
| DEC-001 | **Approved — pilot gate and retained deferrals.** The user approves the selected blocker set and proposed follow-up work, subject to the separately identified DEC-003..DEC-008 conditions. DOC-001..DOC-006 are applied. DOC-007 is explicitly deferred and is no longer a prerequisite to using this order or closing the pilot gate; retain its later documentation obligation. DOC-008 is also explicitly deferred; the user corrected DOC-009 to DOC-008. This postpones the documentation update, not the DEC-004 scope choice. Source-bound acceptance, readiness versus field completion, soak criteria and hardware metadata remain required in the existing checklist/evidence. Independent review may elevate a specific deferred item with reasons. Approval is not a test PASS or deployment authorization. |
| DEC-002 | **Resolved/approved 2026-09-18 — existing firmware heuristic and operator-managed test airtime.** Keep the existing 8-second charged-TX wake budget, 30-second radio window and normal 900-second sleep. The operator accepts this for the limited pilot, citing 30 days of prior testing; no source/configuration-bound report/reset history was supplied here, so this is operator-reported experience, not a reset-safe compliance result. Defer DEP-007 and RF-029's firmware durable-reservation/reset-survival assertions. Do not select or implement a more elaborate allowance owner now. For the first test phase the operator handles separate per-transmitter accounting/admission/pacing using retained manual records; no automated runner ledger/scheduler is required. Existing episode bounds, conservative uncertainty charging and unknown-history fallback remain. An extra receiver is a cross-check, not a silence-based allowance reset. Receiver durable airtime, other gate decisions and counter safety are unchanged. Revisit firmware deferral on repeated/unexpected resets, changed cadence/retry budgets, independent-enforcement requirements or resumed ledger work. |
| DEC-003 | **Resolved/approved 2026-09-18 — documented pilot envelope; physical RF-018 deferred NOT RUN.** The operator accepts the existing source/configuration assessment and configured +14 dBm, trusting SX1262, and approves the hardware/configuration in firmware/test_apps/on_device/SENSOR_CARRIER.md and receiver/hardware/TEST_CARRIER.md, including autonomous wakes, retries and resets. The [retained decision and source record](tests/rf/evidence/2026-09-18-envelope/README.md) close RF-018 disposition and DEP-023 approval. This explicit acceptance supersedes the previous numerical-uncertainty prerequisite for this pilot; no new bound, measured result or independent compliance determination is asserted. Keep the existing PHY/power, DEC-002 firmware policy, receiver production enforcement and operator-owned test accounting. Physical power/carrier/emissions measurement remains NOT RUN; revisit when suitable equipment is available, hardware/RF configuration changes or conflicting evidence appears. Full-service and aggregate deployment acceptance remain separate. |
| DEC-004 | **Approved — local-only Pi storage.** There is no Internet access; collected files/readings stay on the Pi. No uploader, remote server, automatic forwarding or mandatory off-Pi export is required for this pilot. Verify durable local collection, offline operation, readable retained data and the existing storage/recovery/retention controls. Local consistent snapshots may support acceptance/analysis without transferring data off the Pi. Retire the stale legacy server. DEP-021 retains automatic forwarding only as future work if the product later requires it; no destination or transfer contract is selected now. DOC-007/DOC-008 deployment-record publication remains deferred; the root README now reflects this explicit scope decision. |
| DEC-005 | **Approved — 24 hours on the bench.** This replaces the previous 48–72-hour bench requirement. Keep production cadence, selected bounded fault/recovery phases, reconciliation and no unexplained contract failures; the existing field week follows deployment. DEP-019 records the run schedule, denominators, observation gaps and stop criteria before execution. No new numeric reception/RSSI target is imposed or inferred from this approval. Actual selected supply continuity remains a fixture check. |
| DEC-006 | **Approved — documented guarantees and source-bound fault/reset evidence suffice for this limited pilot.** Accept documented NVS/LittleFS/SD guarantees, existing applicable fault tests and new reset/commit-boundary tests. The new tests still need execution and passing evidence. Defer DEP-017 physical power-cut campaigns and RF-031 physical post-SetTx uncertainty proof; retain both as NOT RUN, not physical durability passes. Improve later when suitable fixtures are available, scope changes or observed storage/TX recovery failures require investigation. Firmware-ledger-specific work remains deferred with DEP-007 under DEC-002. |
| DEC-007 | **Approved — rerun evidence when relevant components change.** Rerun a measurement when its relevant schematic/circuit changes; rerun software evidence when its exercised hardware or relevant code changes. Include configuration, dependencies and fixture changes that affect the same observation or behavior; unrelated tree changes or a newer date alone do not require a rerun. Record applicability against the actual source/hardware and retain unchanged evidence with its original limits. Reuse is not a new PASS, and missing provenance cannot establish unchanged applicability. |
| DEC-008 | **Approved — fastest supported LoRa-protocol pilot configuration.** The operator chooses practical available sensors and placement; exact planned sensor pairs/depths are not deployment requirements. Document the actual setup in the logbook after deployment, alongside deferred DOC-007/DOC-008 updates. Before running, retain only configuration inputs needed to build, operate and interpret the selected setup (actual wiring/power, channel/ROM mapping where used, source and radio settings); this is not a new predeployment logbook requirement. Calibration/probe-selection documentation is follow-up work, not a calibrated-moisture claim. Material hardware/code changes trigger relevant DEC-007 reruns; existing protocol and selected RF assertions remain. |

## Precise documentation changes proposed

DOC-001..DOC-006 were explicitly approved and applied on 2026-09-18. DOC-007 and DOC-008 are approved deferred. DEC-004 now approves local-only Pi storage; DOC-008 eventual content must reflect that choice. The sibling deployment record remains unchanged; the root README reflects the subsequently approved local-only goal. No DEP/RF result or DEC disposition is approved by these documentation edits. Existing behavior, required assertions, evidence retention and permission/interlock rules remain. References to an approved gate mean a durable pilot deployment record listing the reviewed IDs/dispositions and source-bound acceptance results; ignored .notes do not become runtime configuration or a second behavior specification.

### DOC-001 — Receiver purpose gate and runner placement

**Approved and applied 2026-09-18.** The following records the authorized change.

In [receiver/TESTING.md](receiver/TESTING.md#purpose-and-authority), replace the paragraph beginning “The complete end-to-end RF suite is deliberately deferred until all receiver production code and every other host and hardware test...” with:

> Field-pilot-v2 deployment and full-system acceptance use the explicitly reviewed pilot-readiness gate, with selected requirement and test IDs, dependencies and required source-bound evidence recorded in the deployment record. Every production behavior needed by that pilot and every selected gate obligation must be implemented and verified. Other required coverage remains identified as deferred, with its reason, consequence and revisit condition; deferred is neither passed nor deleted. Component RF tests may run when their own prerequisites pass, before complete receiver service readiness. Full-system RF tests require the real production service and the relevant integration/lifecycle prerequisites, not automatic completion of all unrelated deferred physical tests. Any change to behavior, protocol, identity/counters, timing or evidence standards still requires an explicit decision.

In that section's Hardware-tests bullet, replace the blanket placement sentence with:

> Ordinary receiver hardware tests run locally on the target Pi. Joint C6/Pi scenarios are coordinated by laptop pytest in tests/rf/: pytest-embedded controls the C6 over its actual UART connector, and SSH controls a separate Pi process. Receiver production code and hardware operations execute on Pi.

In “Framework and organization,” replace the paragraph beginning “Both automated suites use pytest” through its pytest-embedded placement sentence with:

> Receiver host and Pi-local component suites use pytest, with Hypothesis for suitable independent policy/model exploration. Joint RF scenarios use laptop pytest and pytest-embedded for the C6; Pi-local pytest/component or service processes still execute on Pi. The C6 Unity app/configuration lives in firmware/test_apps/radio/, the separate Pi component peer in receiver/test_apps/radio_peer/, and joint scenarios/local orchestration in tests/rf/. Protocol verification remains in protocol/protocol-v2-lora/tests/.

Also correct the introductory status to distinguish implemented runtime-time/radio components from absent communicator and complete service. Retain ordinary hardware targets excluding rf_peer and strict zero-selection/prerequisite/interlock rules.

### DOC-002 — Receiver end-to-end gate

**Approved and applied 2026-09-18.** The following records the authorized change.

In [receiver/TESTING.md, End-to-end / Hardware tests](receiver/TESTING.md#end-to-end-receiver-behavior), replace the paragraph beginning “All tests in this section are deferred until every receiver production component...” including “pytest runs on the Pi” with:

> These scenarios run the production receiver service on Pi and a separately controlled real C6 node. Laptop pytest coordinates them as described under Framework and organization. Each selected scenario requires the implemented production paths and applicable current host, component and deployment evidence listed by the approved pilot gate. Unselected scenarios remain explicit required deferred coverage with IDs and revisit conditions. A component peer result cannot establish complete receiver acceptance.

Keep all twelve current hardware bullets, including failed receiver TX, separate restart/reboot and complete soak; attach RF-020, RF-021, RF-031, RF-022, RF-023, RF-024, RF-025, RF-008 plus RF-004, RF-026, RF-027, RF-028 and RF-030 respectively. For profile interoperability, RF-008/RF-020 map positive transitions and stale-content assertions; RF-004 retains two distinct negative assertions: C6 rejects normal IQ during downlink RX and Pi rejects inverted IQ during normal uplink RX. Both negatives remain proposed deferred coverage, including full-service verification; component results cannot close that end-to-end scope. Add a note that shared executions must retain every distinct assertion and that the field-week phase follows first deployment.

### DOC-003 — Current receiver radio peer strategy

**Approved and applied 2026-09-18.** The following records the authorized change.

Replace only the “operator has deferred component RF-peer implementation until a real-node strategy is defined” sentences in [receiver/TESTING.md, Radio](receiver/TESTING.md#radio), [RADIO_TESTS.md introduction](receiver/tests/hardware/RADIO_TESTS.md) and [RADIO_COVERAGE.md hardware families](receiver/tests/RADIO_COVERAGE.md) with:

> The approved peer is the real C6 radio application, coordinated from laptop tests/rf/ with a separate Pi component process in receiver/test_apps/radio_peer/. Reuse the production Pi radio components where their fixed profile and state contract applies; deliberate alternative-profile cases identify the lower layer they exercise. Peer implementation and RF execution are still pending. Independent waveform/timestamp qualification and controlled BUSY-gate recovery retain their separate deferred status.

Keep Pi-local non-peer procedures, source-staging and manual BUSY safe-teardown rules unchanged. Closure of the earlier implementation stage is not current RF qualification.

### DOC-004 — Firmware strategy and placement

**Approved and applied 2026-09-18.** The following records the authorized change.

In [firmware/TESTING.md, sx1262_radio hardware strategy](firmware/TESTING.md#sx1262_radio-hardware-strategy), replace the paragraph beginning “If the receiver is a Raspberry Pi...” with:

> For field-pilot-v2, laptop pytest in tests/rf/ coordinates pytest-embedded over the C6 UART connector and SSH control of the separate Pi process. The C6 Unity application/configuration lives in firmware/test_apps/radio/ and the Pi component peer in receiver/test_apps/radio_peer/. Use production Pi Radio/Sx1262/LinuxRadioIo where applicable, keeping helpers local until a second real use warrants sharing. Readiness handshakes, local event-based scheduling and bounded waits are mandatory; SSH is not precise RF timing, and endpoint monotonic clocks are independent. Ordinary receiver hardware tests remain Pi-local.

Change the earlier peer “can” list to required future peer behaviors, not capabilities already present. Keep raw/component versus complete node/service acceptance, hardware timing tolerances, manual wiring and first-envelope journal rules unchanged. Replace “all executable tests ... remain deferred” with a factual implemented/planned status when each corresponding RF ID is implemented; do not label them implemented by this planning task.

### DOC-005 — Receiver sequencing plan

**Approved and applied 2026-09-18.** The following records the authorized change.

In [receiver/implementation_plan.notes](receiver/implementation_plan.notes), replace opening blanket “only after the preceding section has been accepted” with “after its actual reviewed dependencies have been accepted; independent work may proceed.”

Update section 11 status to implemented production components plus source-bound non-TX evidence/current-source qualification limits, retaining RF/instrument/fault gaps. Sections 12/13 remain required production work, with service prerequisites of selected full-system cases; change the “Do not implement or run rf_peer” scope instruction only to distinguish that stage's ownership from independently authorized component work.

Replace section 14's “every host, component-hardware and deployment obligation that precedes...” gate and section 15's “every production component and every preceding host and hardware obligation passes” stop condition with:

> Reconcile the approved field-pilot-v2 gate by stable IDs. Require current evidence for the production dependencies and selected host/component/deployment obligations of each full-system scenario. Preserve unselected physical/stress obligations with their approved deferral and revisit conditions. Component RF work may proceed independently under its own gate. Do not infer readiness from old stage completion or waive a required behavior.

Rename section 15 “RF acceptance and retained follow-up coverage,” and point organization/placement to revised receiver/TESTING.md. Do not change IDs/order merely to make the old serial roadmap appear complete.

### DOC-006 — Firmware sequencing plan

**Approved and completed 2026-09-18:** at the user's direction, delete the stale `firmware/implementation_plan.notes` instead of rewriting its sequence. All 33 stages were compared against this inventory, [the execution checklist](todo_list.notes.md) and [the RF catalogue](tests/rf/test_suite.notes.md) before deletion. Existing IDs/classifications remain; historical “done” labels are not new passes.

| Retired stages | Preserved obligations |
|---|---|
| 01 | DEP-011/DEP-012/DEP-022: attributable baseline, fixture restoration and source-bound electrical evidence. |
| 02–05 | DEP-012 and sensor coverage index: discovery/mapping, fresh acquisition, 100 repetitions, ADC A/B, identity swap, cleanup/reset/sleep observations. |
| 06–07 | DEP-012: missing DS0/DS1, partial diagnostics, rail observations and nominal restoration. |
| 08–09 | DEP-011/DEP-012: current Bosch dependency/driver host boundaries, BME sleep mode/absence and restoration; no reopening of the completed driver selection. |
| 10–11 | DEP-012/RF-020: real same-acquisition sensor-to-body/storage mapping and source-bound coverage closure. |
| 12–13 | DEP-022/DEP-023/DEP-024: actual radio fixtures, modules/pins/supply, static preflight and operator readiness; RF-012/RF-013 own manual states. |
| 14–15 | DEP-018; RF-001/RF-003: first exchanges, clocks, independent oracles, readiness and per-transmitter journals. |
| 16–17 | RF-002/RF-004..RF-010/RF-012/RF-013: remaining component/filter/transition/sleep/manual assertions and restoration. |
| 18–19 | RF-011: fixed 50–100-exchange slow stress, pacing, count and failure retention. |
| 20 | DEP-001..DEP-015/DEP-024: applicable service/build/identity/configuration and pre-radio evidence. |
| 21–22 | RF-020: real production reading, persistence and ordinary scheduled wake. |
| 23–24 | RF-021..RF-031/DEP-019/DEP-020/DEP-030: selected full-system cases, bench acceptance then field continuation and reconciliation. Bench air-probe limits versus documented field configuration are now explicit under DEP-020/RF-030. |
| 25–29 | DEP-016/DEP-017/DEP-027; RF-014..RF-018/RF-031: equipment-dependent specification, approved physical fixture, implementation, observed execution and nominal restoration. Sensor rail/bus settling, shutdown and reset/sleep waveform work is now explicit under DEP-027; physical-cut observation/isolation details remain explicit under DEP-017. |
| 30–31 | DEP-028: dedicated runner, guarded scheduling/identity/history and interrupted-run recovery; ordinary plus selected slow job execution/artifact checks are now explicit. |
| 32–33 | DEP-007/RF-029/DEP-017 and DEP-018 gate reconciliation: durable production airtime, selected interruption proof, actual completion boundary and retained failures/deferrals. |

The common premise's production-layer/independent-oracle, local-helper, actual-UART, configuration/linkage, counter-safety and evidence rules remain in the governing test documents and RF common requirements. Missing private provisioning material remains a DEP-008/DEP-009 prerequisite, never a reason to fabricate an identity. Deferred equipment branches still require a concrete specification/procedure, verified fixture, focused implementation and observed execution before closure.

### DOC-007 — Pilot readiness versus pilot completion

**Approved deferred by the user.** Apply this documentation update later when updating the deployment record; it does not block the selected pilot gate. Preserve readiness/field-completion separation and record the bench criteria and actual operating inputs in acceptance evidence; detailed configuration goes in the logbook after deployment under DEC-008.

Add “Readiness gate” to the sibling [field-pilot-v2 deployment record](../cura-agrorum-logbook/deployments/field-pilot-v2/README.md), containing the independently approved RF/DEP selection, source/configuration-bound outcomes and deferred IDs with reasons/revisit conditions. Proposed introductory text:

> Deployment may begin after the reviewed minimum pilot-readiness gate passes and applicable decisions are resolved. Gate closure does not mean every planned test is complete. The 24-hour bench phase precedes deployment; the at-least-one-week field phase begins at deployment. Retained deferred coverage remains required under its stated revisit conditions. Protocol, identity/counter, timing and evidence contracts are unchanged.

In “Work before the custom PCB,” step 3, replace “including power-bank auto-off” with “including verification of the actual selected temporary supply's continuity” after DEC-005; selected LiFePO4 already says no automatic shutdown. Record actual probes/depths/receiver power/hardware revision and repair the stale calibration link after DEC-008. Do not turn failed curve accuracy into a pass.

### DOC-008 — Conditional forwarding-goal change

**Publication remains deferred by the user (DOC-009 was a typo).** DEC-004 now approves local-only Pi storage. The root README was updated with that explicit decision; update the sibling deployment record later to replace its forwarding expectation with:

> Retain timestamped readings and files locally on the Pi. This pilot has no Internet access and requires no uploader or off-Pi export. Verify local retention, readability and recovery. Automatic forwarding remains future work only if a later scope decision requires it.

Keep DEP-021's local verification and retained future forwarding obligation distinct. DOC-007/DOC-008 publication is not a deployment prerequisite.

## Coverage index

This is a routing index, not a compressed replacement specification. Each cited source subsection's distinct bullets, boundary cases and assertions remain authoritative; listing a cohesive family in one row does not merge its tests or reduce its expected outcomes. E-* means only the scoped evidence above. “Host present” means source inspected, not executed here. An RF mapping identifies only that scenario's stated production layer. All DEP and RF IDs retain separate implementation/verification dispositions.

### Protocol and firmware obligations

| Obligation / source section | Existing evidence and limits | Remaining mapping |
|---|---|---|
| Protocol schema/generator freshness, literal header/nonce/body/ACK bytes, C/Python agreement, memory safety/property/fuzz tests — protocol tests README | Reviewed P-VECT; test source present, no new run | DEP-011; exact on-air pilot frames RF-001/RF-020 |
| HKDF/provisioning, strict secret paths/ownership, allowlist/revocation, destructive identity/group rotation — protocol Keys and provisioning | Protocol tooling/tests present | DEP-009; RF-023 revocation; DEC-004 does not waive identity |
| Message vs sample identity, exact retry, durable current-to-backlog binding, counter claim/failure/exhaustion — protocol Counters/nonce | E-BARE implementation, host source | DEP-009/DEP-011; RF-019/RF-021/RF-022/RF-029; recovery DEP-025 |
| Ordered PHY/header/node/auth/control/domain/body/admission/ACK validation; wrong-direction silence even under failed profile admission | Receiver ingress/protocol host source, source-limited Pi component results | DEP-003/DEP-015; RF-023/RF-024 |
| Structural reading values, invalid-zero flags, reset/deep-sleep relation, previous metrics and acceptance of implausible representable values | Reviewed vectors, host source, E-SENSOR same-acquisition mapping | DEP-011/DEP-012; RF-020/RF-023 |
| Canonical transport retransmission / same-ID changed-frame conflict / changed-sample conflict; canonical reading matching and conflicting current/backlog; atomic profile/classification effects | Real SQLite/independent-model host source, E-PERSIST with changed paths | DEP-003/DEP-015; legal exact retry RF-021 and sample duplicate RF-022. Deliberate nonce-reuse conflict cases stay isolated host tests, not live RF |
| Wake initialization, RTC consumption, sensor/body construction, run_ms truncation/saturation/deadline — firmware TESTING node_core first subsection | Host present; E-BARE/E-SENSOR scoped | DEP-008/DEP-011/DEP-012; RF-020 |
| Node ACK validity, retry jitter/timestamp boundary, invalid ACK diagnostic/no mutation — firmware TESTING ACKs and retries | Host exact boundaries, receiver-free core tests | DEP-011; RF-006/RF-019/RF-021; late physical addition RF-007 |
| Independent 8 s charged TX /30 s radio window, pre-SetTx fit/watchdog and uncertain-start charge — firmware TESTING Airtime and wall-clock budgets | Host present; no hour-spanning ledger | DEP-007/DEP-011, DEC-002/DEC-006; RF-012/RF-029 |
| Current/backlog order, RAM-only append failure, binding/quarantine/removal failures and bounded drainage — firmware TESTING Current and backlog transitions | Host matrix, E-BARE real-storage/fake-radio cases | DEP-003/DEP-011; RF-019/RF-022/RF-024 |
| DELIVERY_STARTED/FINISHED durability, diagnostic forwarding/identity/context, nonrecursive logging — firmware TESTING Delivery and diagnostic events; INTERFACE common/persistence/radio/sensor/core contexts | Host source and on-device record assertions; no new target run | DEP-011; RF-019/RF-020/RF-029, monitoring DEP-024 |
| Previous-cycle metrics, representability, RTC final marker, single sync and sleep ordering — firmware TESTING Metrics, RTC and finalization | Host source; E-BARE implementation | DEP-011; RF-010/RF-020; RTC CRC future DEP-026 |
| Persistence host method/error/context matrix, record framing/CRC/semantic validation, compaction quota/crash boundaries — firmware TESTING node_persistence; ARCHITECTURE Persistence boundaries | Host present, no physical-cut proof | DEP-011/DEP-017/DEP-029 |
| All real receiver-free core cases — firmware TESTING On-device node_core integration | E-BARE: real PSA/NVS/LittleFS/RTC with fake sensor/radio | DEP-011; never substitutes for RF-020..RF-029 |
| RTC committed/consumed/replaced records, non-deep-sleep invalidation, consecutive sample continuity, exactly 20 slow round trips | Implemented bare-C6 multi-stage cases, no linked retained baseline archive | DEP-011; physical radio cold restart RF-010; future CRC DEP-026 |
| Real NVS independent sample/message monotonic commit/restart/exhaustion and lazy initialization | E-BARE implementation | DEP-009/DEP-011; approved deferred ledger target DEP-007 |
| Real pending roundtrip, exact bound frame/restart, newest-first selection, mismatched removal and no resurrection | E-BARE implementation | DEP-011; RF-022 |
| Other real record families, durable start/finish, diagnostic sync and VFS lifetime | E-BARE implementation | DEP-011; RF-019/RF-020 |
| Real injected torn/CRC/unsupported/semantic tails, two-call repair, unprovable-byte preservation, append ordering | E-BARE implementation; not electrical power failure | DEP-011/DEP-017/DEP-029 |
| Real reduced-quota newest-half compaction, stale compact rejection, full non-pending rejection, deterministic churn | E-BARE slow cases implemented; not every firmware change requires repeating whole stress | DEP-011 applicable regression, DEP-029 operations, DEP-017 physical proof |
| Sensor host validity groups/zero/failures/diagnostic slots/cleanup/power/identity parsing and GPIO order; Bosch driver/adapter budget/transport/allocation/recovery matrix | Native production-layer tests; E-SENSOR current test-source limitations | DEP-011/DEP-012 |
| Sensor nominal/missing DS0/missing DS1/whole missing BME, exact flags/body, actual Bosch channel compensation and low-power mode, 100 repetitions | E-SENSOR original bytes; whole BME absence probe=261, repeat counted once, BME mode not current draw | DEP-012 applicability and final nominal; RF-020 integrated sample |
| Sensor ADC independent reference A/B, ROM identity across connector swap, same-acquisition core/storage/plaintext mapping | E-SENSOR A+B required, mixed original source/configuration scopes | DEP-012/DEP-022; no new physical action inferred |
| Gate on/off, untouched post-sample holds, final cleanup, intentional restart, held reset, deep sleep/back-power DC criteria | E-SENSOR operator observations, not waveform/current/default-off for every reset | DEP-012 final-assembly applicability; later waveform/energy DEP-027 |
| Platform monotonic/random/reset/timer smoke and 60 s sleep tolerance; shared core/radio clock | E-BARE tests; shared radio clock not physically exercised | DEP-011; RF-001/RF-010/RF-020 (per-end clocks only) |
| Firmware radio host lazy init, profile/PA/workarounds/status, buffer bounds, certainty, IRQ/deadline boundaries, diagnostics and sleep state | Native radio tests present; no real-radio proof | DEP-011; each physical row below |
| First exact TX; 54-byte asymmetric airtime; inverted-IQ RX and shared timestamp brackets | None RF | RF-001 (may share RF-020), blocks |
| Payload 1/54/255 boundaries | Host present, no physical | RF-002 deferred beyond gated 54-byte assertion |
| Silent receive deadline and zero outputs | Host present | RF-003, blocks |
| C6 rejects normal-IQ traffic during inverted-IQ downlink RX | Fixed-profile host transcripts only; no physical negative result | RF-004 c6_rejects_normal proposed deferred; Pi rejection is separate; security remains RF-023 |
| Sync-word filtering | Host profile only | RF-005 deferred |
| Same absolute deadline through invalid packets | Host present | RF-006, blocks; production core behavior RF-019 |
| Late packet does not become stale | Host exact boundary present | RF-007 deferred |
| RX-to-TX and TX/RX/TX-with-ACK, both endpoints' restoration | Host present | RF-008, blocks; shared RF-020/RF-021 possible |
| Untouched sleep twice stays no-op and permits lazy TX; initialized sleep twice is terminal; cold reinitialize after real deep sleep | Host radio + real bare C6 sleep are separate facts | RF-009 separates both lifecycle/charge parameters; RF-010 cold wake; both block |
| C6 DIO1 missing, bounded uncertainty, real peer receives | None physical | RF-012, blocks |
| C6 radio absent, deterministic defined inputs, cleanup reaches sleep | Fixture specified, no executed radio case | RF-013, blocks |
| Slow 50–100 RF transition stress | None | RF-011 deferred with exact count/failure policy retained |
| Extended C6 electrical faults, edge/waveform/current and RF power/frequency | No suitable instruments/controlled fixture | RF-014/RF-017, DEP-016/DEP-027 deferred; RF-018 physical measurement approved deferred NOT RUN under DEC-003; DEP-023 documented pilot envelope approved |

### Receiver and deployment obligations

| Obligation / source section | Existing evidence and limits | Remaining mapping |
|---|---|---|
| Receiver generated enums/entities/schema exact grammar, lifecycle exceptional tables, signed SQLite bounds, queue object ownership vs encoding | Host source, current schema; E-PERSIST predates changes | DEP-003/DEP-010/DEP-011/DEP-015 |
| All Protocol ingress host/Pi families: validation ordering, independent claims/auth/body fields, atomic reservation, active-handle ownership, stable candidate/ACK, terminal completion/profile optional timestamps | Host and component tests, no complete communicator | DEP-001/DEP-003/DEP-015; RF-020/RF-023/RF-024/RF-025 |
| PersistQueue full matrix: fixed 500 slots, admission generations/cells, reservation publication/cancellation, FIFO lease/durable prefix, wake/close and nonrecursive errors | Host source and E-PERSIST component scope | DEP-003/DEP-015; RF-024, health DEP-002 |
| Persistence schema/config/group/read-only preflight, WAL/FULL, startup identities, free-space/storage failure classification | E-PERSIST and host, source changes | DEP-004/DEP-009/DEP-010/DEP-015 |
| Ordinary persistence canonical classification, exact replay/ambiguous commit, corruption preservation, immutable health enrichment and quarantine semantics | Real SQLite host/model and E-PERSIST; missing original databases | DEP-003/DEP-015; RF-021/RF-022/RF-024 |
| Poison isolation exact complete units, boundary observation never bypassed, quarantine commit reconciliation/failure and raw neutral evidence | Host source, E-PERSIST limits | DEP-003/DEP-015; no invented RF substitute |
| Concurrency/control scheduling, bounded deadlines/cancellation, control fairness, shared wakeup, checkpoint/recovery backoff and no lost ownership | Worker host/barrier/crash/model and E-PERSIST load soak | DEP-001/DEP-003/DEP-005/DEP-015 |
| Storage benchmark FULL/NORMAL and real capacity/access/read-only/corruption recovery; operator stop/preserve/restore/new instance | Existing benchmark reports/source-specific evidence; E-PERSIST | DEP-015 current affected correctness; DEP-024 runbook; no change to FULL and no automatic restoration |
| Radio host initialization/profile/terminal/status/cleanup/lifecycle failure evidence | E-HOST revised code, older E-RADIO hardware | DEP-013 current nominal; DEP-003 service failures |
| Radio host RX IRQ/event snapshots/immediate completion/stream gaps/resynchronization, copied bytes, response-free rearm and new event after recovery | Current composed adapter/backend/owner host cases | DEP-003/DEP-013; RF-001/RF-008 real nominal; RF-016 deferred fault proof |
| Radio host ACK transitions, each pre-SetTx/uncertain/missing/late/timeout outcome, BUSY/SPI matrices, soft/hard/exhausted recovery and terminal shutdown | Current host source including real grant settlement | DEP-003/DEP-015; RF-029 selected proof, RF-031 deferred physical uncertainty |
| Radio diagnostic full enum/context byte matrix, episode cardinality/severity/root/last failure, absent/present correlations and interrupted recovery | Existing factory/owner tests, no communicator admission | DEP-002/DEP-003; all radio cases preserve DIAG |
| Pi device/service-user probe, real initialization and finite timeout/rearm | E-RADIO old-source nominal | DEP-013 blocking requalification |
| Pi held-BUSY startup | E-RADIO expected fault, aborted unsafe cleanup, restored nominal | RF-015 deferred additional current-source manual run; preserve failed session |
| Pi real BUSY waveform and independent DIO1/kernel timestamp correspondence | Functional timeout only, no independent waveform | RF-017/DEP-016 deferred; RF-001 retains functional timestamps |
| Pi normal uplink, inverted ACK, restored normal boosted RX; rejection of inverted-IQ traffic during normal RX | No RF; positive exchanges alone cannot prove rejection | RF-001/RF-008 blocking positive assertions; RF-004 pi_rejects_inverted separately proposed deferred, with correct-profile control and explicit receiving-layer evidence |
| Pi independent physical timing with asymmetric bounds | No instrument, software samples not qualification | RF-017 deferred; tolerances unchanged |
| Pi controlled physical soft/hard reset recovery | Gate unavailable, guarded cases reject selection | RF-016 deferred; never replace with RF-015 separate boots |
| Pi safe teardown from RX/idle/TX-adjacent/recovery | E-RADIO nominal only, old source | DEP-013 and common RF cleanup / RF-008 for TX-adjacent; RF-016 recovery case deferred |
| Pure time trust/error/rate checked arithmetic, bounds/equality/hysteresis, observations/step gaps/instance correlation, earliest direct anchors/logical chains and independent properties | Host source, E-TIME hardware subset | DEP-003/DEP-014; RF-026 exact derived timestamp semantics |
| Time runtime scheduling, fresh trusted samples, provenance invalidation before write, read-back/unknown-write generation, deadline/step publication and recovery episodes | Host source; later corrections not qualified by old Pi | DEP-006/DEP-014 blocking affected paths |
| Linux boot identity and monotonic behavior across process/reboot | E-AIR/E-TIME component evidence | DEP-004/DEP-005; RF-027/RF-028 service scope |
| Real Chrony local-socket parsing and adjtimex brackets including expected STA_UNSYNC/TIME_ERROR | E-TIME, root/fixture limits | DEP-006/DEP-014 |
| DS3231 read validity/brackets, missing/invalid/I/O bounds; OSF rejection/recovery, RTC-01..06 | E-RTC/E-TIME; functional retention not drift/holdover | DEP-014 applicability; DEP-006 installed device/helper identity |
| Offline holdover startup, plausible but unproven RTC, network-qualified write/read-back/durable provenance | E-TIME components and host fixes | DEP-004/DEP-006/DEP-014, RF-026/RF-028 |
| Maximum positive/negative slew versus independent reference, 3700-ppm bound | E-TIME verifiers passed locally; old but directly measured kernel/config evidence | DEC-007 applicability; DEP-014 rerun only if measured assumptions change |
| Four SCL/SDA read/write controller faults, in-flight helper termination, released GPIO vs recovered bus and nominal restoration | E-TIME and LIMITATION qualified stock-driver workaround | DEP-014 targeted applicability, DEP-024 invalid-RTC recovery; controller abort/NACK redesign remains deferred, not required new driver |
| Real forward/back explicit steps, FIFO boundary before command, permanent correlation gap, time-writer deployment audit | E-TIME predates later writer-audit/runtime fixes | DEP-006/DEP-014; RF-026 |
| Time diagnostic exact 80-byte encoding, normal-status silence, episode deduplication/reset, no policy impact of failed diagnostic admission | Factory host source, no communicator coverage | DEP-002/DEP-003; runtime assertions DEP-014 |
| Durable-state ordered primary validation, missing/corrupt synthetic history, unknown-version/policy wait, exact generation/blob reconciliation | Host/SQLite and E-AIR with source limits | DEP-003/DEP-015; DEP-002 exact control diagnostics |
| Airtime bucket aging/per-bucket immutable deadlines, cached total/grid/headroom, no admission scans, correlation loss and conservative UTC guard | Host model and eight-hour availability regression; E-AIR measurements | DEP-015 current applicable tests; RF-029 production emission observation |
| Eight-hour healthy policy availability: <=14 s deferral and <=74 s successful ACK gap | Existing test_tx_airtime_availability.py independent SQLite regression; not RF latency guarantee | DEP-011/DEP-015 affected regression, keep separate from RF-030 link metrics |
| Grant spend/settle/reclaim certainty, crash before/after commit, repeated crash, unknown settlement and unavailable history | Host/real SQLite/crash and E-AIR target subset | DEP-001/DEP-003/DEP-015; RF-025/RF-027..RF-029, physical uncertainty RF-031 |
| Target monotonic grant lifetime and same-boot unspendable restart baseline | E-AIR source-bound/root/10000-ppb fixture | DEP-015/DEC-007; service integration RF-027 |
| Actual reboot trusted/unavailable-time reconstruction | E-AIR both modes, no RF/service | RF-028 and DEP-006/DEP-015 |
| Real-radio definite/confirmed/uncertain charge and continuous-hour attempted-TX observation | None RF; peer receipt cannot decide certainty | RF-029 blocking selected subset, RF-031 approved deferred physical subcase under DEC-006 |
| Startup ordering/storage prerequisite, initial time observation, sequences, exact clean marker/crash semantics/static supervisor/no-pilot-data isolation | Component startup/worker present, full host/service missing | DEP-003/DEP-004/DEP-005/DEP-010 |
| Pi boot service, failed bootstrap continuation and once-per-boot behavior | Historical kernel RTC bootstrap not full service | DEP-004/DEP-014; RF-028 |
| Pi receiver-user privileges, automatic crash restart, clean restart/unclean stop, Pi boot identities | E-PERSIST/E-AIR component only, root limits | DEP-004/DEP-005/DEP-006; RF-027/RF-028 |
| Pi suspend prevention and missing-device supervisor rate limiting/restoration | No service evidence | DEP-004/DEP-005/DEP-024 |
| Persistence-control/CORE exact contexts, impossible-source rejection, one diagnostic across reconciliation, queue-safe exception behavior and no recursive failures | Operational results exist, top-level construction missing | DEP-002/DEP-003 |
| Health periodic producer/priority, exact admission matrix/self-inclusion, immutable enrichment, counters/FIFO and persistence-unavailable loss limit | Generated/enrichment host tests, producer absent | DEP-001/DEP-002/DEP-003; RF-024/RF-030 |
| Full-system host valid/lost/failed ACK, current/backlog, persistence unavailable, airtime suppressed, clock boundary and clean/crash restart | Component analogues, not complete production application | DEP-003: keep all eight named host families |
| First full RF reading | None | RF-020 |
| Lost accepted ACK | None | RF-021 |
| Failed real receiver TX outcome | Host-only component paths | RF-031 approved deferred, DEC-006 |
| Current/backlog RF identity | Bare-C6 fake-radio evidence only | RF-022 |
| Authenticated rejection and silence | Host/protocol evidence | RF-023 |
| Queue/persistence backpressure | Component E-PERSIST only | RF-024 |
| Airtime-suppressed RF acceptance | Host component semantics only | RF-025 |
| Direction profile transition interoperability, including neither endpoint receiving wrong-direction IQ | Host profiles only; no full-service negative evidence | RF-008/RF-020 positive transitions/stale-content assertions; RF-004 C6 and Pi rejection assertions separately proposed deferred, including full-service scope; component passes do not close the end-to-end obligation |
| Clock/timestamp RF evidence | Time components only | RF-026 |
| Receiver process restart | E-AIR same-boot component only | RF-027 |
| Pi reboot | E-AIR component only | RF-028 |
| Complete pilot soak with accounting/health/checkpoints/recoverable faults | 30-second worker soak only | RF-030 bench/field separate, RF-029 rolling observation; DEP-019/DEP-020 |
| Pilot later forwarding | No v2 implementation/contract owner | DEP-021/DEC-004 |
| Installed fixture, actual source/configuration/provisioning, safe maintenance and assembly verification | E-SENSOR/E-RADIO historical; unresolved actual metadata | DEP-008..DEP-015/DEP-022/DEP-024, DEC-007/DEC-008 |
| Later energy, dedicated runner, RTC CRC/durable ACK/outage fallback/counter recovery and undefined log repair | Explicit current deferrals, no upgraded guarantees | DEP-025..DEP-030; no custom-PCB/autonomy implementation gate |

No obligation was removed or weakened during reconciliation. Proposed deferrals change **when coverage gates deployment**, not what a pass means. DEC-004 approves the local-only product scope; DOC-008 retains its deferred publication update. DEC-002 now records the approved pilot heuristic/manual test accounting and defers firmware ledger design/proof. DEC-004 resolves forwarding as outside this local-only pilot. DEC-005..DEC-008 are approved; DEC-003 is approved for the documented pilot hardware/configuration; numerical uncertainty remains unmeasured and RF-018 physical measurement is deferred NOT RUN; no pass conditions are invented.

## Dependency-ordered sequence

DEC-001 approves this order in place of blanket serial-roadmap prerequisites. DOC-001..DOC-006 are applied; DOC-007 is approved deferred. Other task-specific decisions remain due before their dependent work. “Ready to begin a test” requires its implementation/configuration and relevant earlier evidence, not completion of another DEP item's later RF verification; this distinction avoids circular gates. DEP-003 tests grow with their owning implementation. Gate closure remains later than test entry.

| Phase | Work and actual dependencies | Exit/evidence |
|---|---|---|
| 1. Review decisions and preserve sources | Carry forward approved DEC-001 gate and deferred DOC-007; carry forward DEC-003 approval of the documented first/expanded/autonomous pilot envelopes; carry forward approved DEC-002 pilot deferral/manual test ownership and approved DEC-004 local-only Pi storage. Apply approved DEC-005 24-hour bench duration, DEC-006 physical-proof deferral and DEC-007 change-based evidence reuse. DEC-008 permits flexible sensors/depths and post-deployment logbook documentation; actual operating inputs remain necessary. Apply DOC proposals only after agreement. | Approved decisions and exact retained deferral list, no readiness declaration. |
| 2. Early nominal work | DEP-013 current Pi non-TX qualification; configure the C6 radio image/actual UART and minimal peer/orchestrator. Implement RF-001 and then RF-003/RF-006/RF-008/RF-009/RF-010 with explicit source/layer scopes. Raw first exchanges use the existing first envelope; expanded episodes wait for their budgets. | Nominal real-component facts and journals. Full communicator/firmware durable ledger is not a prerequisite for raw component work under the separate runner envelope. |
| 3. Independent production work | Firmware DEP-008/DEP-011 under approved DEC-002; DEP-007 remains deferred; receiver DEP-001/DEP-002/DEP-003 and then DEP-004/DEP-005; deployment DEP-006/DEP-009/DEP-010/DEP-024. Operator resolves DEP-022; applicability/requalification DEP-012/DEP-014/DEP-015. These streams may proceed independently where components exist; no sub-agent or parallel implementation is requested by this plan itself. | Reviewed behavior implementation, current host results, installed isolated service/configuration and targeted component evidence. No component test promoted to service acceptance. |
| 4. Finish available manual C6 batches | Once nominal is known, operator selects dio1_disconnected for RF-012 and any reviewed real-node RF-029 uncertainty assertion; restores nominal. Then radio_absent for RF-013; restore both absence ties before refitting module, then nominal RF-001. Pi stays radio_nominal with RTC shunts open. | Distinct fault outcomes and nominal restoration, per-end charges retained across power/fixture changes. Do not combine two incompatible fixtures into one run. |
| 5. Nominal production acceptance | With actual node/service implementation and pre-radio checks ready, implement/run RF-019 and RF-020 first. Then RF-021/RF-022, RF-023/RF-024/RF-025, RF-026, RF-027/RF-028 and RF-029 remaining nominal assertions. RF-019 may start with a controlled peer independently of complete service. Destructive phases use dedicated identities/storage and explicit interlocks. | Full contract/packet/state evidence. RF-020 can also establish RF-001/RF-008/RF-010 assertions; RF-021 can establish RF-008; RF-025 can establish RF-003 with its no-TX proof; RF-019 can share RF-006. Each ID retains its own recorded result and no omitted assertion is inferred. |
| 6. Minimum bench gate | RF-030 at least 24 hours, including one complete rolling-window RF-029 observation and selected outage/recovery phases. Reuse passing source-identical scenario assertions inside this run instead of executing duplicate suites. Use approved DEC-005 and predeclare the run schedule. | Source-bound reconciliation, receiver production enforcement, current node guards and operator-managed test accounting, restored fixtures, no unexplained failure; independent review closes or rejects gate. |
| 7. Deploy and continue | After gate acceptance, DEP-020 commissioning and one field week; DEP-030 analysis, approved DEP-021 local-retention workflow. Follow up deferred cases according to triggers, not a blanket promise never to run them. | Deployment record and later pilot-completion decision are distinct. |
| 8. Deferred manual/equipment batches | Nominal extra lengths/IQ/sync/late cases RF-002/RF-004/RF-005/RF-007; separate slow RF-011. Pi manual selector RF-015 isolated, then restore; controlled BUSY gate RF-016 only after actual revised fixture, then restore; RF-014/RF-031 only with their real mechanisms. Instrumented RF-017/RF-018, physical cuts DEP-017 and energy DEP-027 require approved equipment/evidence conditions. | Every retained ID remains visible. If a revisit trigger or DEC-006 elevates a case, move that work before phase 6 rather than silently deploying around it. |

### Proposed minimum gate

The proposed deployment-blocking inventory is DEP-001 through DEP-006 and DEP-008 through DEP-015, DEP-018, DEP-019 and DEP-024 **for their stated pilot scope and relevant evidence**, not all tests ever mentioned in those source documents. Final configuration/readiness in DEP-022 and adequate RF envelope DEP-023 must also be resolved. DEP-017 and DEP-021 cannot be called safely deferred while their decisions remain open.

Required RF assertion sets: RF-001, RF-003, RF-006, RF-008, RF-009, RF-010, RF-012, RF-013, RF-019, RF-020, RF-021, RF-022, RF-023, RF-024, RF-025, RF-026, RF-027, RF-028, selected RF-029 current-node/receiver/manual-observation assertions (excluding the deferred firmware-ledger assertions) and RF-030's bench phase. Twenty IDs do not imply twenty separate long runs: the nominal/core/acceptance groupings above deliberately share execution while retaining independently checkable assertions. The already required 24-hour bench interval supplies the rolling-hour observation; no extra 50–100-exchange component stress is added to this gate.

DEC-001-approved later RF obligations (separate DEC conditions still apply): RF-002, RF-004, RF-005, RF-007, RF-011, RF-014, RF-015, RF-016, RF-017 and RF-031, plus RF-030's field phase after deployment. RF-018 physical measurement is approved deferred NOT RUN under DEC-003; its evidence disposition and DEP-023 approval are complete for the documented configuration. RF-029's real Pi post-SetTx-uncertainty assertion remains approved deferred under DEC-006 and must be explicitly recorded NOT RUN.

Approved later work: DEP-007 and RF-029's firmware-ledger assertions under DEC-002. DEC-001-approved later non-RF work: DEP-016, DEP-020, DEP-025..DEP-030 within their stated scopes. DEP-021 automatic forwarding is excluded from this pilot under DEC-004 and retained for a future scope change. DEP-017 physical power cuts and RF-031 physical uncertainty proof are approved deferred under DEC-006. Evidence freshness does not require rerunning every old test: DEP-012..DEP-015 define the specific current-source/fixture applicability checks.

Gate acceptance requires independent review of: exact deployed source/configuration/public identities; all selected results and source limits; unresolved failures; counter/airtime/reset safety; approved deferral/revisit records; manual restoration; operational readiness; and resolution of all applicable DEC items. No passing gate is claimed now.

### Planned Make entry points and selection semantics

Names below are proposals, not targets created by this task. Introduce each only with real cases and its real fixture. A requested run must name an explicit RF-ID set and phase/parameter set applicable to its selected scope; missing or unknown selection fails. No “all fixtures” convenience target and no implicit host-only fallback.

| Proposed entry point | Explicit applicable selection and fixture |
|---|---|
| make test-rf-component-nominal | N; component RF-001..RF-010 and controlled-node RF-019, restricted to implemented cases and approved envelopes. RF-019 must additionally select authenticated/destructive-storage prerequisites; pure radio selection cannot silently include it. This target does not run the full service. |
| make test-rf-component-dio1_disconnected | C6 dio1_disconnected / Pi radio_nominal; RF-012 only, manual wiring confirmation, one possible C6 transmission. |
| make test-rf-component-radio_absent | C6 radio_absent / Pi silent radio_nominal; RF-013 only, removal and direct-tie confirmations, no valid TX expected. |
| make test-rf-component-slow-nominal | N; RF-011 only, explicit 50..100 count and legal schedule. Slow is additional to component scope, not shorthand for acceptance. |
| make test-rf-acceptance-nominal | N; named non-destructive phases of RF-020..RF-026 and RF-029 only after full-service prerequisites. Any actual storage erase, time/network mutation, process kill or reboot instead requires the explicit destructive path. |
| make test-rf-acceptance-destructive-nominal | N; specified destructive phases of RF-020..RF-029 only where scope is full acceptance, including storage/backpressure/time/service/reboot changes; dedicated service/group/database/root and applicable time/reboot interlocks. RF-019 controlled-peer scope stays on its component entry with its own destructive opt-in, never mislabeled full acceptance. |
| make test-rf-acceptance-dio1_disconnected | C6 dio1_disconnected / Pi radio_nominal, the RF-029 current-node uncertainty parameter under DEC-002; deferred durable-ledger assertions additionally need future DEP-007; explicit destructive/manual interlocks. RF-012 can share physical setup with its separate component result. |
| make test-rf-acceptance-slow-nominal | RF-030 bench and explicitly listed embedded RF assertions, predeclared duration/mix, slow opt-in; its destructive phases require the same explicit destructive controls, even during soak. No automatic destructive inclusion. |
| Existing Pi-local hardware entry points, selected explicitly | DEP-013 nominal non-peer and RF-015 held-BUSY use receiver/tests/hardware and its existing fixture/selection rules. RF-015 runs alone with no C6 requirement. RF-016 selection remains rejected until its controlled gate exists; laptop orchestration does not move these tests off Pi. |

Every entry must validate before device access: nonempty exact case selection, supported parameters, source/build seal, actual UART DUT, exact C6/Pi fixture, operator readiness, available peer/service and production layer, device exclusivity, isolated identities/storage, operator confirmation of per-end manual airtime allowance and bounded episode, and applicable slow/destructive confirmations. Collection must fail on missing prerequisites, mismatched fixture or zero selected tests; skipped/ignored required cases cannot yield a requested-run pass. Capture the selected case count and actual outcomes.

Peer/startup readiness carries run/case identity, endpoint boot/process identity and local state; bounded completion and teardown are required. Lost SSH/UART control stops further triggers, reaps possible transmitters or obtains operator power-off, and conservatively retains possible airtime. Schedule precisely only on the appropriate endpoint. Keep orchestration/fixtures local until a second real consumer establishes sharing; do not add a speculative protocol, command daemon, API or reusable harness in advance.

All existing make test-hardware, test-hardware-slow and test-hardware-all meanings remain the receiver-free bare-C6 application. Ordinary receiver hardware targets remain Pi-local and exclude joint rf_peer cases. No instrument-specific or unavailable-fault target is created merely to advertise deferred coverage.

## Reconciliation checks

Completed locally on the stated baseline:

- 31 unique sequential RF definitions, 30 unique sequential DEP definitions, stable explicit anchors, eight defined review decisions and eight documentation-change proposals; no undefined RF/DEP/DEC references.
- Every RF section has all six required field groups; every DEP entry has requirements/current source, separate implementation/verification, remaining evidence, actor/dependencies and classification.
- All 182 local Markdown file/fragment links across the three deliverables resolve. Whitespace checks pass, including ignored/untracked files.
- Existing offline radio, airtime and slew evidence verifiers pass; receiver evidence SHA256SUMS and all 26 sensor-catalogue original-file hashes pass. Manifest drift and missing historical inputs remain explicitly recorded above.
- Production HEAD is still ee55b737b0bc90e2a467814ddccc688a08c8a06a; no tracked production/governing file was modified. Both .notes files and the owned workplan are ignored and untracked; tests/rf/README.md is untracked. Nothing was staged or committed.

These are documentation and retained-evidence checks, not host-suite reruns or new hardware qualification. Independent review, acceptance of deferrals and deployment gate closure remain pending.

## DOC-001..DOC-006 execution record — 2026-09-18

Applied the authorized documentation changes and retired the firmware roadmap after the 33-stage reconciliation above. All existing DEP/RF IDs, classifications and unresolved decisions remain. No production code, hardware execution, DOC-007/DOC-008 change or commit is part of this update. Completed DEP/RF tasks have not been removed; any later pruning must retain their acceptance provenance. The earlier reconciliation checks remain a dated baseline, not a claim that this update executed tests.

## DEC-002 execution record — 2026-09-18

The user explicitly chose operator-managed test airtime and accepted the existing firmware cadence/budget heuristic based on operator-reported 30-day testing. DEP-007 is removed from this pilot's implementation gate and retained as approved deferred work. RF-029 separates current node/receiver observations from future firmware-ledger proof. No new test result, general deployment approval, receiver-policy waiver or ten-minute-silence allowance was inferred. Prior DOC execution records describe the earlier state; this decision supersedes their unchanged-classification statement for DEP-007 and the affected RF-029 scope only.

### DEC-001 / DEC-003 / DEC-004 clarification record

DEC-001 approval retains all task IDs, assertions and revisit conditions. DOC-007 and DOC-008 are deferred; the user corrected the DOC-009 reference to DOC-008. DEC-004 was a separate scope choice, now resolved below. DEC-003 now records explicit acceptance of the existing documented configuration/source-based assessment, approval of autonomous wakes/retries/resets, and physical RF-018 deferred NOT RUN; no numerical bound or measured PASS is invented. DEC-004 was subsequently approved as local-only Pi storage; the decision row above supersedes the earlier choice discussion.

### DEC-004 local-only execution record

Recorded no Internet access and data remaining on the Pi, without inferring mandatory manual export. Removed the stale server and its README listing; the legacy v1 generator no longer emits server files by default. Historical source manifests remain unchanged. No hardware run, local-retention PASS or commit is claimed.

### DEC-005..DEC-008 approval record

The user selected a 24-hour bench phase, accepted documented storage guarantees plus applicable fault/reset/commit-boundary evidence for this limited pilot, approved change-based evidence reuse, and chose flexible sensor placement with logbook documentation after deployment. These decisions do not execute the pending reset tests, pass physical campaigns or shorten the later field week. DEP-020 owns post-deployment configuration/logbook recording; DEP-022 retains only actual assembly/readiness inputs before deployment.
