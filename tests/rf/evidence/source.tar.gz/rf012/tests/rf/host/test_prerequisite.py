"""Host-only prerequisite archives: admission and retained-review corruption."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from evidence import digest, qualify_prior, write_json
from verify import verify_run
import pytest_radio

spec = importlib.util.spec_from_file_location("reviewed_rf_record", Path(__file__).with_name("test_verifier.py"))
records = importlib.util.module_from_spec(spec)
spec.loader.exec_module(records)


def seal(root):
    write_json(root / "SHA256SUMS.json", {str(p.relative_to(root)): digest(p)
               for p in root.rglob("*") if p.is_file() and p.name != "SHA256SUMS.json"})


@pytest.fixture
def archive(tmp_path):
    root = tmp_path / "prior"; root.mkdir()
    manifest = dict(schema=1, head="old", files={"doc.md": "a" * 64, "peer.py": "b" * 64})
    write_json(root / "source-manifest.json", manifest)
    write_json(root / "build.json", dict(elf="image", dependency="unchanged"))
    (root / "source.tar.gz").write_bytes(b"host-only archive placeholder")
    (root / "operator-airtime-record.txt").write_text("host-only record; no device access")
    (root / "junit.xml").write_text('<testsuites><testsuite><testcase name="host"/></testsuite></testsuites>')
    events, peer = records.record()
    case = root / "RF-001.exchange"; case.mkdir()
    write_json(case / "c6-events.json", events)
    for name in ("episode", "operator-ready", "uart-identity"):
        write_json(case / (name + ".json"), {})
    write_json(case / "peer-exit.json", dict(exit=0))
    identity = dict(pid=1, boot="pi-boot", source=digest(root / "source-manifest.json"),
                    run="a" * 32, case="RF-001.exchange")
    peer.update(identity)
    (case / "pi.jsonl").write_text("\n".join(json.dumps(v) for v in
        [dict(kind="ready", **identity), dict(kind="armed", **identity), peer]) + "\n")
    run = dict(run="a" * 32, source=identity["source"], elf="image", pytest_exit=0, failures=[],
               status="PASS", selected=["RF-001.exchange"], results=[dict(case="RF-001.exchange")],
               fixture=dict(c6_dut="cc8da2fc0224", pi_board_id="board"))
    write_json(root / "run.json", run); seal(root)
    assert verify_run(root) == run
    return root


def inputs(archive, tmp_path):
    manifest = json.loads((archive / "source-manifest.json").read_text())
    manifest["files"]["doc.md"] = "c" * 64
    write_json(tmp_path / "current-source.json", manifest)
    run = json.loads((archive / "run.json").read_text())
    run["run"] = "b" * 32; run["source"] = digest(tmp_path / "current-source.json")
    old = json.loads((archive / "run.json").read_text())
    review = dict(schema=1, reviewer="host test", decision="unaffected prerequisite reviewed",
                  prior=dict(run=old["run"], source=old["source"], elf=old["elf"],
                             archive=digest(archive / "SHA256SUMS.json"), build=digest(archive / "build.json")),
                  current=dict(source=run["source"], elf=run["elf"], build=digest(archive / "build.json")),
                  changes={"doc.md": dict(before="a" * 64, after="c" * 64, reason="results documentation only")})
    return manifest, run, review


def test_identical_source_needs_no_exception(archive):
    old = verify_run(archive)
    accepted, reference, review = qualify_prior(archive,
        json.loads((archive / "source-manifest.json").read_text()), old, archive / "build.json")
    assert accepted == old and review is None
    assert reference["identity"]["archive"] == digest(archive / "SHA256SUMS.json")


@pytest.mark.parametrize("change", ["none", "missing", "extra", "before", "after", "reason",
                                  "prior", "current", "archive", "reviewer", "schema", "unreviewed", "null"])
def test_missing_stale_or_incomplete_review_rejected(archive, tmp_path, change):
    manifest, run, review = inputs(archive, tmp_path)
    if change == "missing": review["changes"].clear()
    elif change == "extra": review["changes"]["peer.py"] = deepcopy(review["changes"]["doc.md"])
    elif change in {"before", "after", "reason"}: review["changes"]["doc.md"][change] = ""
    elif change in {"prior", "current"}: review[change]["source"] = "d" * 64
    elif change == "archive": review["prior"]["archive"] = "d" * 64
    elif change == "reviewer": review["reviewer"] = " "
    elif change == "schema": review["schema"] = True
    elif change == "unreviewed": manifest["files"]["peer.py"] = "d" * 64
    elif change == "null": review = None
    path = tmp_path / "review.json"; write_json(path, review)
    with pytest.raises(ValueError):
        qualify_prior(archive, manifest, run, archive / "build.json", None if change == "none" else path)


@pytest.mark.parametrize("change", ["elf", "build", "c6_dut", "pi_board_id", "corrupt_prior"])
def test_review_cannot_override_changed_build_device_or_failed_prior(archive, tmp_path, change):
    manifest, run, review = inputs(archive, tmp_path)
    build = tmp_path / "build.json"; build.write_bytes((archive / "build.json").read_bytes())
    if change == "elf": run["elf"] = "different"; review["current"]["elf"] = "different"
    elif change == "build":
        write_json(build, dict(elf="image", dependency="changed")); review["current"]["build"] = digest(build)
    elif change == "corrupt_prior": (archive / "junit.xml").write_text("corrupted")
    else: run["fixture"][change] = "different"
    path = tmp_path / "review.json"; write_json(path, review)
    with pytest.raises(ValueError):
        qualify_prior(archive, manifest, run, build, path)


@pytest.mark.parametrize("kind", ["add", "remove"])
def test_explicit_added_and_removed_file_review(archive, tmp_path, kind):
    manifest, run, review = inputs(archive, tmp_path)
    if kind == "add": manifest["files"]["new.md"] = "e" * 64
    else: del manifest["files"]["peer.py"]
    write_json(tmp_path / "current-source.json", manifest)
    run["source"] = review["current"]["source"] = digest(tmp_path / "current-source.json")
    name = "new.md" if kind == "add" else "peer.py"
    review["changes"][name] = dict(before=None if kind == "add" else "b" * 64,
                                   after="e" * 64 if kind == "add" else None, reason="explicitly reviewed delta")
    path = tmp_path / "review.json"; write_json(path, review)
    assert qualify_prior(archive, manifest, run, archive / "build.json", path)[2] == review


def test_rejection_precedes_remote_staging_and_any_dut_fixture(archive, tmp_path, monkeypatch):
    manifest, run, review = inputs(archive, tmp_path)
    root = tmp_path / "new-run"; root.mkdir()
    ctx = dict(output=root, seal=json.loads((archive / "build.json").read_text()),
               manual=archive / "operator-airtime-record.txt", fixture=run["fixture"],
               episodes=[SimpleNamespace(name="RF-012.disconnected")])
    ctx["seal"]["files"] = {"cura_radio_component.elf": "image"}
    write_json(archive / "build.json", ctx["seal"]); seal(archive)
    options = dict(rf_prior=str(archive), rf_run=run["run"])
    config = SimpleNamespace(_rf_context=ctx, getoption=options.get)
    monkeypatch.setattr(pytest_radio, "source_manifest", lambda: manifest)
    monkeypatch.setattr(pytest_radio, "subprocess", SimpleNamespace(run=lambda *a, **k: SimpleNamespace(stdout=b"")))
    def forbidden(*args, **kwargs):
        pytest.fail("device/staging reached before prerequisite acceptance")
    monkeypatch.setattr(pytest_radio, "Remote", forbidden)
    session = pytest_radio.joint_run.__wrapped__(SimpleNamespace(config=config, getfixturevalue=forbidden))
    with pytest.raises(ValueError, match="explicit reviewed applicability"):
        next(session)


def test_retained_verifier_rejects_review_tampering_even_after_resealing(archive, tmp_path):
    manifest, run, review = inputs(archive, tmp_path)
    original = (archive / "source-manifest.json").read_bytes()
    (archive / "prior-source-manifest.json").write_bytes(original)
    write_json(archive / "prior.json", dict(identity=review["prior"]))
    write_json(archive / "prior-applicability.json", review)
    write_json(archive / "source-manifest.json", manifest)
    run["prerequisite"] = dict(identity=review["prior"], applicability=True)
    # Keep synthetic C6 run IDs intact; this fixture exercises source reuse only.
    run["run"] = "a" * 32
    write_json(archive / "run.json", run)
    peer_file = archive / "RF-001.exchange/pi.jsonl"
    records = [json.loads(line) for line in peer_file.read_text().splitlines()]
    for record in records: record["source"] = run["source"]
    peer_file.write_text("\n".join(json.dumps(v) for v in records) + "\n")
    seal(archive)
    assert verify_run(archive)["prerequisite"]["applicability"] is True
    review["changes"]["doc.md"]["after"] = "d" * 64
    write_json(archive / "prior-applicability.json", review); seal(archive)
    with pytest.raises(ValueError, match="mismatched applicability review"):
        verify_run(archive)
