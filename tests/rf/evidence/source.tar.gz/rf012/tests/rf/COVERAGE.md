# Component RF implementation coverage

Scope approved 2026-09-18: RF-001/003/006/008/009/010/012/013.
All listed case code is implemented. **143 harness/peer host checks pass**,
including explicit prerequisite-applicability validation.
After operator correction of the C6 board, all eight nominal parameters passed
in [source-bound component RF runs](evidence/2026-09-18-nominal/README.md).
RF-012 first manual attempt **FAIL**: unexpected READ_IRQ/IRQ=0; the operator reported RN5 missing or misplaced and restoration is pending confirmation. See the [retained failure and cleanup](evidence/2026-09-18-rf012/README.md). RF-013 remains **NOT RUN** pending its separately confirmed manual fixture.
Earlier [startup/command failures](evidence/2026-09-18-initial/README.md) and the
[failed nominal TxDone attempt](evidence/2026-09-18-framing/README.md) remain
retained independently. No production radio behavior or expectation was changed
to pass the restored runs. These results do not establish full-service acceptance.

| ID / parameters | Required production path and independent observation | Fixture | Physical result |
|---|---|---|---|
| RF-001 / exchange | C6 `transmit_uplink` / `receive_downlink_until`, real platform clock; Pi `Radio` receive/prepare/start/finish ACK; exact A/B, timestamps, profile restoration | nominal | PASS |
| RF-003 / silence | Same initialization TX; unchanged absolute C6 RX deadline, zero packet fields; Pi receives A with zero SetTx calls | nominal | PASS |
| RF-006 / invalid | C6 caller rejects `00`, `deadbeef`, X and reuses its original deadline; Pi production receive plus disclosed local `Sx1262` burst | nominal | PASS |
| RF-008 / silence, exchange | Same initialized C6 boot: A then U2; silence parameter retains armed RX until TX; exchange parameter receives B then D2; Pi full normal RX restoration | nominal | Both PASS |
| RF-009 / untouched, initialized | Two sleep calls, later valid-deadline TX; untouched lazily initializes and sends A; initialized rejects before SetTx; passive backend observations establish no-op/terminal behavior | nominal | Both PASS |
| RF-010 / wake | Real cold radio sleep and ESP timer deep sleep; new boot/BSS, DEEPSLEEP reset, full lazy initialization and A/B then U2/D2; clocks checked within each wake | nominal | PASS |
| RF-012 / disconnected | C6 single attempted A, `tx_started` true / `tx_done` false, TRANSMIT/WAIT_IRQ/HARDWARE_TOUCHED; Pi receives exact A | dio1_disconnected | FAIL; RN5 correction/readiness pending |
| RF-013 / absent | C6 lazy-init BUSY failure before SetTx, diagnostic retained, actual deep-sleep progression; Pi silent observation | radio_absent | NOT RUN |

Each independent parameter starts from a reset C6 singleton. RF-008 remains in
one boot; RF-010 deliberately crosses deep sleep. Radio observation wrappers
forward calls unchanged and buffer evidence until the timed sequence ends.
The Pi owns its own schedule, measured from its observed uplink. No assertion
subtracts a Pi timestamp from a C6 timestamp. Neither raw A/B exchange nor a
passing harness regression establishes authentication or full-service behavior.

RF-019 remains pending production-node configuration/provisioning and controlled
authenticated outcomes. Selected RF-020..RF-030 assertions remain pending the
real service and their catalogue dependencies. RF-029's firmware-ledger and Pi
physical uncertainty assertions retain their approved deferrals. RF-030 bench
and field remain separate. RF-002/004/005/007/011/014..018/031 retain the exact
requirements, dispositions, consequences and revisit conditions in the
[catalogue](test_suite.notes.md); no unimplemented selection is silently skipped.
RF-004 still requires both endpoints' negative IQ assertions.

The [firmware hardware contract](../../firmware/TESTING.md#sx1262_radio-hardware-strategy),
[receiver radio contract](../../receiver/TESTING.md#radio) and each selected
[catalogue scenario](test_suite.notes.md) supply the oracles. RF-009 follows the
current untouched-versus-initialized distinction. The production 900-second
sleep remains RF-020, not RF-010's short component sleep.
