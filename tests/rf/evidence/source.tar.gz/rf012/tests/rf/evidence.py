"""Source/build sealing and immutable run inputs for this RF harness only."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path(__file__).resolve().parents[2]
APP = REPO / "firmware/test_apps/radio"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def tree_sources():
    paths = []
    for name in ("firmware/components", "firmware/test_apps/radio/main", "receiver/cura_receiver",
                 "receiver/test_apps/radio_peer", "receiver/tests", "receiver/schemas", "receiver/db",
                 "protocol/protocol-v2-lora/python", "tests/rf"):
        paths.extend(p for p in (REPO / name).rglob("*") if p.is_file() and
                     not any(part in {"__pycache__", "runs", ".pytest_cache", "evidence"} for part in p.parts) and
                     p.suffix in {".c", ".h", ".py", ".md", ".txt", ".cmake", ".yml", ".json", ".ini", ".sql"} and
                     not p.name.startswith(("WORKPLAN", "REVIEW")))
    paths.extend(APP / name for name in ("CMakeLists.txt", "sdkconfig.defaults", "partitions.csv", "dependencies.lock"))
    paths.extend(REPO / name for name in ("Makefile", "firmware/TESTING.md", "firmware/INTERFACE.md",
        "firmware/ARCHITECTURE.md", "receiver/ARCHITECTURE.md", "receiver/INTERFACE.md", "receiver/TESTING.md",
        "receiver/INTERFACE_DIAGNOSTIC.md", "receiver/requirements-radio.txt", "receiver/requirements-test.txt", "receiver/pytest.ini",
        "receiver/hardware/TEST_CARRIER.md", "receiver/tests/hardware/RADIO_TESTS.md",
        "protocol/protocol-v2-lora/README.md", "deployment_remaining.notes.md"))
    return {str(p.relative_to(REPO)): digest(p) for p in sorted(set(paths))}


def firmware_sources(build):
    """Hash the actual compiler dependencies, including IDF and fetched headers."""
    result = subprocess.run(["ninja", "-C", str(build), "-t", "deps"], check=True,
                            capture_output=True, text=True)
    files = set()
    for line in result.stdout.splitlines():
        if line.startswith("    "):
            path = Path(line.strip())
            path = path if path.is_absolute() else build / path
            if path.is_file():
                files.add(path.resolve())
    commands = json.loads((build / "compile_commands.json").read_text())
    files.update(Path(entry["file"]).resolve() for entry in commands)
    files.update(APP / name for name in ("CMakeLists.txt", "main/CMakeLists.txt", "sdkconfig",
                 "sdkconfig.defaults", "partitions.csv", "dependencies.lock"))
    if APP / "main/radio_app.c" not in files or len(files) < 100:
        raise ValueError("missing actual build dependency records")
    return {str(p): digest(p) for p in sorted(files)}


def check_flash(build):
    args = json.loads((build / "flasher_args.json").read_text())
    expected = {"0x0": "bootloader/bootloader.bin", "0x8000": "partition_table/partition-table.bin",
                "0x10000": "cura_radio_component.bin"}
    if args["flash_files"] != expected or args["extra_esptool_args"]["chip"] != "esp32c6":
        raise ValueError("unapproved flash files or target")
    limits = {"0x0": 0x8000, "0x8000": 0x1000, "0x10000": 0x100000}
    for offset, name in expected.items():
        if not 0 < (build / name).stat().st_size <= limits[offset]:
            raise ValueError("flash file overlaps retained storage")
    # Check the actual binary partition table, not only its source labels.
    import struct
    data = (build / expected["0x8000"]).read_bytes()
    partitions = []
    for offset in range(0, len(data), 32):
        block = data[offset:offset + 32]
        if len(block) != 32 or block[:2] != b"\xaa\x50":
            break
        _, kind, subtype, start, size, label, flags = struct.unpack("<HBBII16sI", block)
        partitions.append((kind, subtype, start, size, label.rstrip(b"\0").decode(), flags))
    if partitions != [(1, 2, 0x9000, 0x6000, "nvs", 0), (1, 1, 0xf000, 0x1000, "phy_init", 0),
                      (0, 0, 0x10000, 0x100000, "factory", 0), (1, 131, 0x110000, 0x2e0000, "storage", 0)]:
        raise ValueError("binary partition table differs from reviewed physical layout")
    config = json.loads((build / "config/sdkconfig.json").read_text())
    pins = dict(SCLK=6, MOSI=7, MISO=14, CS=23, RESET=18, BUSY=19, DIO1=20)
    if any(config.get(f"CURA_SX1262_{name}_GPIO") != pin for name, pin in pins.items()):
        raise ValueError("resolved C6 radio pins differ")
    if config.get("ESP_CONSOLE_UART_NUM") != 0 or config.get("ESP_CONSOLE_UART_BAUDRATE") != 115200:
        raise ValueError("wrong resolved UART console")
    return {name: digest(build / name) for name in (*expected.values(), "cura_radio_component.elf",
              "flasher_args.json", "config/sdkconfig.json", "compile_commands.json", "project_description.json")}


def seal_build(build):
    build = Path(build).resolve()
    value = dict(schema=1, dependencies=firmware_sources(build), files=check_flash(build))
    write_json(build / "rf-build.json", value)
    return value


def verify_build(build):
    build = Path(build).resolve()
    value = json.loads((build / "rf-build.json").read_text())
    if value != dict(schema=1, dependencies=firmware_sources(build), files=check_flash(build)):
        raise ValueError("source/build seal mismatch; rebuild and seal before device access")
    return value


def source_manifest():
    return dict(schema=1, files=tree_sources(), head=subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=REPO, check=True, capture_output=True, text=True).stdout.strip())


def qualify_prior(prior, manifest, run, build_file, applicability=None):
    """Reverify a retained prerequisite before staging or accessing either DUT."""
    from verify import verify_applicability, verify_run
    prior = Path(prior)
    old = verify_run(prior)
    if any(old["fixture"][key] != run["fixture"][key] for key in ("c6_dut", "pi_board_id")):
        raise ValueError("prior prerequisite belongs to different devices")
    identity = dict(run=old["run"], source=old["source"], elf=old["elf"],
                    archive=digest(prior / "SHA256SUMS.json"), build=digest(prior / "build.json"))
    current = dict(source=run["source"], elf=run["elf"], build=digest(build_file))
    if identity["elf"] != current["elf"] or identity["build"] != current["build"]:
        raise ValueError("prior prerequisite evidence belongs to a different firmware build")
    review = json.loads(Path(applicability).read_text()) if applicability else None
    if applicability:
        verify_applicability(review, json.loads((prior / "source-manifest.json").read_text()),
                             manifest, identity, current)
    elif old["source"] != run["source"]:
        raise ValueError("prior prerequisite source changed; explicit reviewed applicability is required")
    return old, dict(path=str(prior), identity=identity), review


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seal-build", type=Path, required=True)
    seal_build(parser.parse_args().seal_build)
