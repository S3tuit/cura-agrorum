# SX1262 component hardware procedure

These cases use the production Linux adapter, command backend and owner. They
do not run receiver end-to-end orchestration, spend durable airtime, or submit
`SetTx`. On 2026-09-17 the operator reported unpowered continuity checks with
no apparent issue. The first nominal attempt failed during initialization;
its fixture records powered/wiring confirmations without numeric measurements.
The captured post-reset status and lost cleanup result now have host
regressions. The corrected run passed device/GPIO configuration and
initialization/readback; finite RX timeout/rearm still failed on the status/IRQ
confirmation path. All three teardowns confirmed safety. Preserve both runs;
the approved runtime status/IRQ correction now has host coverage and awaits
a fresh nominal run.

Follow the [carrier schematic](../../hardware/TEST_CARRIER.md#proposed-sx1262-extension)
for the Waveshare EU868 board without a Pico. The operator must confirm the
actual board/revision, wiring, supply and inactive RESET/NSS levels. Stop the
receiver service and other users of the same GPIO/SPI devices. Run as the
actual non-root receiver service user, with its deployed device permissions.
Do not use root to turn a permission failure into a pass.
The approved supply is one shared rail from Pi physical pin 1 (3.3 V) and one
ground rail from physical pin 6. Both modules use these rails, with one 100 nF
and one 10 uF capacitor in parallel across them. Keep both RTC fault shunts
open. The radio keeps its 10 kohm RESET and CS pull-ups to the same 3.3 V rail.

RF peer strategy is deferred to a real-node fixture. The available multimeter
can support supply/static-level checks; it cannot qualify BUSY, DIO1, CS or
RESET waveforms, kernel timestamp accuracy or RF airtime. Those obligations
remain pending. The finite RX-timeout case below is a functional IRQ/rearm
check, not independent timestamp or timing acceptance. TX-adjacent physical
teardown and alternating RF profile acceptance remain with the peer stage.

## Stage current sources

Use a new isolated directory on `cura@cura-receiver`, with SSH/SCP option
`-F /dev/null`. Package the current local `receiver/` and
`protocol/protocol-v2-lora/` trees, including untracked implementation/test
files; a committed-only archive is insufficient during development. Exclude
virtual environments, caches and old test output. Record the local archive's
SHA-256, copy it, verify the identical SHA-256 on the Pi, and only then extract
and run from that new directory. Retain the archive hash and exact command
line beside the results. Do not assume any existing Pi checkout is current.

Run these two blocks in the same **local Bash terminal**. Avoid editing the
source trees while packaging. `git ls-files` supplies tracked and nonignored
untracked paths; `tar` reads their current working-tree contents. Git-ignored
local identities/notes and the explicit output exclusions are not packaged.
The radio cases require no receiver-group identity or keys.

```bash
set -euo pipefail
cd $HOME/devspace/cura-agrorum
radio_stage=$(mktemp -d /tmp/cura-radio-stage.XXXXXXXX)

git ls-files -z --cached --others --exclude-standard -- \
  receiver/ protocol/protocol-v2-lora/ > "$radio_stage/candidate-files.nul"

package_command=(tar
  --exclude=results --exclude=evidence --exclude=test-results
  --exclude=.venv --exclude=venv --exclude=.tox
  --exclude=__pycache__ --exclude=.pytest_cache --exclude=.hypothesis
  --exclude=.mypy_cache --exclude=.ruff_cache --exclude=.cache
  --exclude=.fuzz-corpus --exclude=build --exclude=dist
  '--exclude=*.egg-info' '--exclude=*.py[co]' '--exclude=.coverage*'
  --exclude=htmlcov '--exclude=*.log' '--exclude=*junit*.xml'
  --exclude=receiver-group.json --exclude=.env
  -czf "$radio_stage/source.tar.gz"
  --null --no-recursion -T "$radio_stage/candidate-files.nul")
{
  printf 'cd %q\n' "$PWD"
  printf '%q ' "${package_command[@]}"
  printf '\n'
} > "$radio_stage/package-command.txt"
"${package_command[@]}"
(cd "$radio_stage" && sha256sum source.tar.gz > SHA256SUMS)
cat "$radio_stage/SHA256SUMS"
```

The next block creates a fresh directory below the remote user's home, copies
the archive and provenance, checks the hash, and only then extracts it. A
failed command stops the block; an existing remote directory is not reused.
No receiver service, GPIO/SPI operation or hardware test is started.

```bash
remote_stage="receiver-radio-${radio_stage##*.}"
sshpass -p cura ssh -F /dev/null cura@cura-receiver "mkdir -- '$remote_stage'"
sshpass -p cura scp -F /dev/null \
  "$radio_stage/source.tar.gz" "$radio_stage/SHA256SUMS" \
  "$radio_stage/package-command.txt" "$radio_stage/candidate-files.nul" \
  "cura@cura-receiver:$remote_stage/"

sshpass -p cura ssh -F /dev/null cura@cura-receiver bash -s -- "$remote_stage" <<'REMOTE'
set -euo pipefail
cd "$1"
mkdir results
cp SHA256SUMS package-command.txt candidate-files.nul results/
sha256sum --check SHA256SUMS | tee results/archive-verification.log
mkdir src
printf 'cd %q\ntar -xzf source.tar.gz -C src\n' "$PWD" > results/extract-command.txt
tar -xzf source.tar.gz -C src
printf '\nStaged source: %s/src\nEvidence directory: %s/results\n' "$PWD" "$PWD"
REMOTE

printf "\nConnect with: ssh -F /dev/null cura@cura-receiver\nThen: cd ~/%s/src\n" "$remote_stage"
```

Require `source.tar.gz: OK` before using the printed source directory. Keep the
archive and its sibling `results/` directory; authentication credentials are
not written into the retained command files. The packaging command's original
candidate path list is retained as `results/candidate-files.nul`.

On the Pi, install the native build prerequisites once. For the recorded
Debian 13 / Python 3.13 target:

```sh
sudo apt update
sudo apt install build-essential python3.13-dev python3-venv
```

`spidev` may build a C extension locally. The
[Python 3.13 development package](https://packages.debian.org/trixie/python3.13-dev)
provides its required headers; a venv alone does not provide `Python.h`.
The headers must match the interpreter used to create the venv.

Enter the printed `src/` directory, create an isolated virtual environment and
install:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r receiver/requirements-test.txt \
  -r receiver/requirements-radio.txt \
  -r protocol/protocol-v2-lora/requirements-test.txt
.venv/bin/python -m pip freeze > ../results/dependencies.txt
```

If an existing venv's `spidev` build fails with `fatal error: Python.h: No such
file or directory`, install the matching development package above and rerun
the same pip install in that venv; rebuilding the source archive or recreating
the venv is unnecessary. An import-only check does not open radio devices:

```sh
.venv/bin/python -c 'import spidev, gpiod; print("Radio dependencies import OK")'
```

The fixture writes a SHA-256 source manifest, exact operator input and target
metadata before any device operation. Retain `dependencies.txt`, archive hash,
source manifest, JUnit and original stdout/stderr with every run, including
failures. Keep configuration/credentials for production receivers out of the
test archive; these component tests require no receiver identity or keys.

## Explicit fixture input

Create an absolute-path JSON file outside production configuration. Replace
the board identity and service account, and change confirmations to `true`
only after the operator has performed those checks:

```json
{
  "schema": 2,
  "board_id": "record actual board, revision and oscillator population",
  "service_user": "cura",
  "wiring_checked": false,
  "power_checked": false,
  "no_pico_fitted": false,
  "receiver_service_stopped": false,
  "fixture_state": "radio_nominal",
  "busy_selector_checked": false,
  "configuration": {
    "spi_device": "/dev/spidev0.0",
    "gpio_chip": "/dev/gpiochip0",
    "reset_line": 22,
    "dio1_line": 23,
    "busy_line": 24,
    "spi_speed_hz": 1000000
  }
}
```

`busy_selector_checked: true` confirms exactly one shunt in the position
declared by `fixture_state`, changed and checked with external power removed:

| `fixture_state` | Selector | Connection |
|---|---|---|
| `radio_nominal` | 1-2 | Radio BUSY to Pi GPIO24, physical pin 18 |
| `radio_busy_held` | 2-3 | Pi GPIO24 to shared 3.3 V; radio BUSY disconnected |

Never join the radio's BUSY output to 3.3 V. All other radio wiring remains
fitted. Schema 1 and the former `busy_fault_gate_fitted` field are rejected;
they describe a different selector connection and cannot authorize this one.

Select nominal cases with absolute fixture/output paths. The evidence directory
must not exist; its parent must exist. Place JUnit/logs alongside that directory:

```sh
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 .venv/bin/python -m pytest \
  -c receiver/pytest.ini receiver/tests/hardware/test_radio.py \
  --receiver-hardware -m 'radio and not destructive' \
  --receiver-radio-fixture /absolute/operator.json \
  --receiver-radio-evidence /absolute/evidence/nominal-new \
  --junitxml=/absolute/evidence/nominal-new.junit.xml \
  > /absolute/evidence/nominal-new.log 2>&1
```

Selected missing/inaccessible hardware fails. There are no runtime skips.
Ordinary receiver hardware targets include these obligations; while the carrier
is absent, explicitly select `hardware and not radio` when testing other
components rather than interpreting unrun radio cases as passing.

## Manual held-BUSY startup case

First establish the nominal baseline above. Shut down Linux, remove external
Pi/module power, move the single shunt to 2-3, and verify the radio BUSY contact
is isolated from both GPIO24 and 3.3 V. Reboot with the receiver service stopped.
Create a fresh operator file selecting `radio_busy_held` and confirming those
checks. The JSON records the fixture; it never changes the physical wiring.

Run only this case, using the existing dedicated root bearing
`.cura-receiver-test-root` with exact contents `CURA AGRORUM RECEIVER TEST ROOT`
followed by a newline:

```sh
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 .venv/bin/python -m pytest \
  -c receiver/pytest.ini receiver/tests/hardware/test_radio.py \
  --receiver-hardware -m radio_busy_held \
  --confirm-receiver-destructive \
  --receiver-test-root /absolute/dedicated-test-root \
  --receiver-radio-fixture /absolute/operator-held.json \
  --receiver-radio-evidence /absolute/evidence/held-new \
  --junitxml=/absolute/evidence/held-new.junit.xml \
  > /absolute/evidence/held-new.log 2>&1
```

Collection rejects any other selected test in this run, including nominal
radio cases. It also rejects a nominal fixture file for a held case and vice
versa. The case requires `INITIALIZATION_FAILED`, fatal INITIALIZE /
BUSY_TIMEOUT and CLEANUP / BUSY_TIMEOUT episodes, only HIGH BUSY samples,
released device handles and no SPI transfer, RX entry or TX attempt. It records elapsed monotonic time and
checks the 2 s startup limit with the existing 50 ms late-only service allowance;
this is functional deadline evidence, not waveform/timing qualification.

`held-busy-observation.json` is written only after those assertions succeed.
**The session still exits nonzero (1) because safe standby is unconfirmed.**
The held input prevents confirmation (`safe_shutdown=false`); terminal-instance
shutdown cannot restart the failed owner. `manual-restoration-required.json` and the teardown
result retain that incomplete status. Preserve the complete log, trace and
JUnit: an exit code alone does not distinguish the expected restoration stop
from an earlier assertion/device failure, and a matching fault is not a safe
teardown pass.

After the run, shut down Linux, remove external power and restore the one shunt
to 1-2. Verify nominal continuity and no rail tie to BUSY. Reboot, confirm the
service remains stopped, and run the nominal command with a fresh nominal
operator file and evidence directory. Retain both runs, their boot/source
identities and the operator's restoration confirmation together. Later
success does not relabel the held run's unconfirmed cleanup. These separate
runs establish startup failure and manual restoration, not runtime recovery.

## Deferred controlled fault cases

The existing `radio_fault` soft/hard recovery cases require the unavailable
SN74LVC1G32 gate. Collection rejects their selection before GPIO/SPI access.
No field in the manual fixture input enables them. Adding that gate later
requires a revised schematic and operator input; the current selector pin 3
is directly connected to 3.3 V and must not be joined to a gate output.

The deferred fixture programs a finite receive timeout to create a real IRQ
without an RF peer. It then forces only the Pi's observed BUSY high. One case releases the
gate before soft recovery; another keeps it high through the failed soft wait
and physically releases it when the production reset is asserted. Both require
confirmed RX restoration. The gate is returned LOW in `finally` and released.
This is component fault injection; production idle RX still uses `SetRx(0)`.

Every case retains raw JSONL command/GPIO activity, initialization and teardown
results. Nominal finalization requires confirmed standby, disabled IRQ routing
and handle release. Unconfirmed safe teardown aborts all subsequent hardware
cases; preserve the original failure and restore the fixture before a fresh
run. Software traces do not replace independent waveform measurements.
